package com.example.hungerguard.builder;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdatePlayerAbilitiesC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Строитель v2: устойчивый план, проверка результата и работа с 3D-шаблонами. */
public class BuilderBot {
    public static final BuilderBot INSTANCE = new BuilderBot();
    public enum State { IDLE, RUNNING, DONE, ERROR }

    private State state=State.IDLE;
    private BuilderTemplate template;
    private List<BuilderTemplate.Block> plan=new ArrayList<>();
    private int planIndex, placed, cooldown, failTicks;
    private String error="";
    private BlockPos pendingVerify;
    private String pendingId;
    private Vec3d stuckRef;
    private int stuckTicks;
    private float smoothYaw, smoothPitch;
    private boolean lookInit;

    private BuilderBot() {}
    public State getState(){return state;}
    public int getPlaced(){return placed;}
    public int getTotal(){return plan.size();}
    public String getError(){return error;}

    public void start(){
        MinecraftClient c=MinecraftClient.getInstance();
        String name=HungerGuardConfig.get().builderTemplate;
        if(name==null||name.isBlank()){fail("Шаблон не выбран");return;}
        template=TemplateStore.load(name);
        if(template==null){fail("Шаблон не найден: "+name);return;}
        if(!HungerGuardConfig.get().builderAnchorSet){fail("Точка привязки не задана");return;}
        plan=new ArrayList<>(template.blocks);
        // Низ -> верх. Внутри слоя ближе к уже построенному центру сначала.
        plan.sort(Comparator.comparingInt((BuilderTemplate.Block b)->b.y)
                .thenComparingInt(b->b.x+b.z).thenComparingInt(b->b.x));
        planIndex=0; placed=0; cooldown=0; failTicks=0; error="";
        pendingVerify=null; stuckRef=null; stuckTicks=0; lookInit=false;
        state=State.RUNNING;
        if(c.player!=null){smoothYaw=c.player.getYaw();smoothPitch=c.player.getPitch();}
        if(c.player!=null && c.player.isCreative()){
            c.player.getAbilities().flying=true; c.player.getAbilities().allowFlying=true;
            if(c.getNetworkHandler()!=null)c.getNetworkHandler().sendPacket(new UpdatePlayerAbilitiesC2SPacket(c.player.getAbilities()));
        }
        notify("§b[Строитель] Старт: "+plan.size()+" блоков");
    }

    public void stop(){
        if(state==State.RUNNING||state==State.DONE){state=State.IDLE;releaseKeys();notify("§c[Строитель] Остановлен (построено: "+placed+")");}
    }

    public void tick(MinecraftClient c){
        if(state!=State.RUNNING||c.player==null||c.world==null||c.interactionManager==null||c.currentScreen!=null)return;
        if(cooldown>0){cooldown--;return;}
        if(pendingVerify!=null){
            String now=idAt(c,pendingVerify);
            if(now!=null&&now.equals(pendingId)){placed++;planIndex++;pendingVerify=null;failTicks=0;cooldown=HungerGuardConfig.get().builderDelayTicks;return;}
            if(now!=null){ // не тот блок: аккуратно ломаем только его
                c.interactionManager.attackBlock(pendingVerify,Direction.UP);
                if(!c.player.isCreative()){c.interactionManager.updateBlockBreakingProgress(pendingVerify,Direction.UP);}
                cooldown=2;
                return;
            }
            // воздух — сервер ещё не успел прислать состояние, ждём пару тиков
            if(++failTicks<8)return;
            pendingVerify=null;failTicks=0;
        }
        if(planIndex>=plan.size()){state=State.DONE;releaseKeys();notify("§a[Строитель] Готово! Построено "+placed+" блоков");return;}

        BuilderTemplate.Block b=plan.get(planIndex);
        BlockPos target=worldPos(b);
        String current=idAt(c,target);
        if(current!=null&&current.equals(b.id)){placed++;planIndex++;return;}
        if(c.world.getBlockState(target).isReplaceable() || c.world.getBlockState(target).isAir()){
            // нормально; ищем реальную опору
        }
        BlockHitResult hit=findPreciseHit(c,target);
        double reach=c.player.isCreative()?5.0:4.5;
        if(hit==null||c.player.getEyePos().distanceTo(hit.getPos())>reach-0.15){
            if(++failTicks>220){notify("§e[Строитель] Не удалось достать блок "+b.x+","+b.y+","+b.z);failTicks=0;planIndex++;}
            else moveToward(c,hit!=null?hit.getPos():Vec3d.ofCenter(target));
            return;
        }
        failTicks=0;releaseKeys();lookAt(c,hit.getPos());
        if(!ensureBlockInHand(c,b)){failTicks=0;planIndex++;return;}
        try{
            c.interactionManager.interactBlock(c.player,Hand.MAIN_HAND,hit);
            pendingVerify=target;pendingId=b.id;cooldown=1;
        }catch(Exception e){fail("Ошибка постановки: "+e.getMessage());}
    }

    private BlockPos worldPos(BuilderTemplate.Block b){
        HungerGuardConfig c=HungerGuardConfig.get();
        int ox,oy,oz;
        if(c.builderAnchorCorner){ox=c.builderAnchorX;oy=c.builderAnchorY;oz=c.builderAnchorZ;}
        else {ox=c.builderAnchorX-template.dx/2;oy=c.builderAnchorY-template.dy/2;oz=c.builderAnchorZ-template.dz/2;}
        return new BlockPos(ox+b.x,oy+b.y,oz+b.z);
    }

    private String idAt(MinecraftClient c,BlockPos p){Block b=c.world.getBlockState(p).getBlock();return b==null||b==Blocks.AIR?null:Registries.BLOCK.getId(b).toString();}

    /** Перебирает соседние блоки и возвращает hit именно по грани, которая ставит target. */
    private BlockHitResult findPreciseHit(MinecraftClient c,BlockPos target){
        Vec3d eye=c.player.getEyePos();
        for(Direction side:Direction.values()){
            BlockPos support=target.offset(side.getOpposite());
            if(c.world.getBlockState(support).isAir()||c.world.getBlockState(support).isReplaceable())continue;
            Vec3d face=Vec3d.ofCenter(support).add(side.getOffsetX()*0.49,side.getOffsetY()*0.49,side.getOffsetZ()*0.49);
            Vec3d dir=face.subtract(eye);double d=dir.length();if(d<0.05)continue;
            Vec3d end=face;
            try{
                BlockHitResult hit=c.world.raycast(new RaycastContext(eye,end,RaycastContext.ShapeType.OUTLINE,RaycastContext.FluidHandling.NONE,c.player));
                if(hit!=null&&hit.getType()==HitResult.Type.BLOCK&&hit.getBlockPos().equals(support)&&hit.getSide()==side)return hit;
            }catch(Exception ignored){}
        }
        return null;
    }

    private boolean ensureBlockInHand(MinecraftClient c,BuilderTemplate.Block b){
        Item item=blockToItem(b.id);if(item==null){notify("§e[Строитель] Неизвестный блок: "+b.id);return false;}
        PlayerInventory inv=c.player.getInventory();
        if(c.player.isCreative()){
            inv.setSelectedSlot(0);
            try{if(c.getNetworkHandler()!=null)c.getNetworkHandler().sendPacket(new CreativeInventoryActionC2SPacket(36,new ItemStack(item)));}catch(Exception ignored){}
            return true;
        }
        int found=-1;for(int i=0;i<36;i++){ItemStack s=inv.getStack(i);if(!s.isEmpty()&&s.getItem()==item){found=i;break;}}
        if(found<0){notify("§e[Строитель] Не хватает: "+item.getName().getString());return false;}
        if(found<9){inv.setSelectedSlot(found);return true;}
        // Нормальный обмен с первым хотбар-слотом через screen handler.
        try{
            int sync=c.player.playerScreenHandler.syncId;
            c.interactionManager.clickSlot(sync,found,0,SlotActionType.PICKUP,c.player);
            c.interactionManager.clickSlot(sync,36,0,SlotActionType.PICKUP,c.player);
            inv.setSelectedSlot(0);return true;
        }catch(Exception e){return false;}
    }
    private Item blockToItem(String id){try{Block b=Registries.BLOCK.get(Identifier.of(id));if(b==null||b==Blocks.AIR)return null;Item i=b.asItem();return i instanceof BlockItem?i:null;}catch(Exception e){return null;}}

    private void moveToward(MinecraftClient c,Vec3d p){
        if(c.player.isCreative()){
            Vec3d eye=c.player.getEyePos(),to=p.subtract(eye);double len=to.length();if(len<0.01)return;
            double step=Math.min(0.6*Math.max(.2,HungerGuardConfig.get().builderMoveSpeed),Math.max(.12,len-2.2));
            Vec3d n=to.normalize().multiply(step);double off=eye.y-c.player.getY();c.player.setPosition(eye.x+n.x,eye.y+n.y-off,eye.z+n.z);c.player.setVelocity(Vec3d.ZERO);
        }else{
            double dx=p.x-c.player.getX(),dz=p.z-c.player.getZ();setLook(c,(float)Math.toDegrees(Math.atan2(-dx,dz)),c.player.getPitch());c.options.forwardKey.setPressed(true);
            if(c.player.horizontalCollision)c.options.jumpKey.setPressed(true);
            Vec3d pos=c.player.getPos();if(stuckRef==null)stuckRef=pos;else if(pos.squaredDistanceTo(stuckRef)<.04){if(++stuckTicks%10==0)c.options.jumpKey.setPressed(true);}else{stuckRef=pos;stuckTicks=0;}
        }
        lookAt(c,p);
    }
    private void lookAt(MinecraftClient c,Vec3d p){Vec3d e=c.player.getEyePos();double dx=p.x-e.x,dy=p.y-e.y,dz=p.z-e.z;double h=Math.sqrt(dx*dx+dz*dz);setLook(c,(float)Math.toDegrees(Math.atan2(-dx,dz)),(float)-Math.toDegrees(Math.atan2(dy,h)));}
    private void setLook(MinecraftClient c,float yaw,float pitch){
        float sharp=MathHelper.clamp(HungerGuardConfig.get().builderSharpness,0f,1f);if(!lookInit){smoothYaw=c.player.getYaw();smoothPitch=c.player.getPitch();lookInit=true;}
        if(sharp>=.95f){smoothYaw=yaw;smoothPitch=pitch;}else{float l=.18f+sharp*.65f;smoothYaw+=MathHelper.wrapDegrees(yaw-smoothYaw)*l;smoothPitch+=(pitch-smoothPitch)*l;}
        c.player.setYaw(smoothYaw);c.player.setPitch(smoothPitch);c.player.headYaw=smoothYaw;c.player.bodyYaw=smoothYaw;
    }
    private void releaseKeys(){MinecraftClient c=MinecraftClient.getInstance();c.options.forwardKey.setPressed(false);c.options.backKey.setPressed(false);c.options.leftKey.setPressed(false);c.options.rightKey.setPressed(false);c.options.jumpKey.setPressed(false);c.options.sneakKey.setPressed(false);}
    private void fail(String s){error=s==null?"Ошибка":s;state=State.ERROR;releaseKeys();notify("§c[Строитель] "+error);}
    private void notify(String s){MinecraftClient c=MinecraftClient.getInstance();if(c.player!=null)c.player.sendMessage(Text.literal(s),false);}
}
