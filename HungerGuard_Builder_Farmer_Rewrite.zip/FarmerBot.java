package com.example.hungerguard;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Надёжный авто-фермер. Посев подтверждается состоянием мира, а не одним кликом. */
public class FarmerBot {
    public static final FarmerBot INSTANCE=new FarmerBot();
    private static final Set<Block> CROPS=Set.of(Blocks.WHEAT,Blocks.CARROTS,Blocks.POTATOES,Blocks.BEETROOTS,Blocks.NETHER_WART);
    private boolean running;private int harvested,tickCount;private long shiftReleaseAt=-1;
    private BlockPos breakingPos,plantPos,depositChest;private int breakingTicks,plantWait,plantRetries;
    private Item pendingSeed,plantItem,lastHeld=Items.AIR;private int depositStep,depositTicks;private long depositCooldownUntil,lastNoChestWarn;
    private float smoothYaw,smoothPitch;private boolean lookInit;private final Map<BlockPos,Integer> skipUntil=new HashMap<>();private Vec3d stuckRef;private int stuckTicks;
    private FarmerBot(){}
    public boolean isRunning(){return running;}public int getHarvested(){return harvested;}

    public void start(){
        running=true;harvested=0;tickCount=0;breakingPos=null;breakingTicks=0;pendingSeed=null;plantPos=null;plantItem=null;plantWait=0;plantRetries=0;
        depositStep=0;depositTicks=0;depositChest=null;depositCooldownUntil=0;lastHeld=Items.AIR;lookInit=false;skipUntil.clear();stuckRef=null;stuckTicks=0;shiftReleaseAt=-1;
        notify("§a[Фермер] Запущен");
    }
    public void stop(){if(!running)return;running=false;releaseKeys();notify("§c[Фермер] Остановлен (собрано: "+harvested+")");}

    public void tick(MinecraftClient c){
        if(!running||c.player==null||c.world==null||c.interactionManager==null)return;
        HungerGuardConfig cfg=HungerGuardConfig.get();if(c.currentScreen!=null&&depositStep==0)return;tickCount++;
        autoToolSwitch(c);
        int si=cfg.farmerShiftIntervalTicks;if(si>0&&tickCount%si==0){c.options.sneakKey.setPressed(true);shiftReleaseAt=tickCount+2;}if(shiftReleaseAt>=0&&tickCount>=shiftReleaseAt){c.options.sneakKey.setPressed(false);shiftReleaseAt=-1;}
        if(cfg.farmerDeposit){if(depositStep!=0){doDeposit(c);return;}if(isInventoryFull(c)&&depositCooldownUntil<=tickCount){depositStep=1;depositChest=null;doDeposit(c);return;}}
        if(plantPos!=null){doReplant(c);return;}
        if(breakingPos!=null){continueBreaking(c);return;}
        if(tickCount%3!=0)return;
        BlockPos crop=findMatureCrop(c);if(crop==null){releaseKeys();return;}
        double reach=c.player.isCreative()?5.0:4.2;if(distTo(c,crop)>reach-.25){moveToward(c,crop);return;}
        releaseKeys();Vec3d aim=aimPointFor(c,crop);lookAt(c,aim);
        BlockHitResult hit=raycastToPoint(c,aim);
        if(cfg.farmerStrictCollection&&(hit==null||!hit.getBlockPos().equals(crop))){if(++plantRetries>15){skipUntil.put(crop,tickCount+40);plantRetries=0;}return;}
        plantRetries=0;Item seed=seedFor(c.world.getBlockState(crop).getBlock());
        if(c.interactionManager.attackBlock(crop,Direction.UP)){breakingPos=crop.toImmutable();breakingTicks=0;pendingSeed=seed;}
    }

    private void continueBreaking(MinecraftClient c){
        if(breakingPos==null)return;BlockPos done=breakingPos;BlockState st=c.world.getBlockState(done);
        if(st.isAir()){
            breakingPos=null;breakingTicks=0;harvested++;
            if(HungerGuardConfig.get().farmerAutoReplant&&pendingSeed!=null){plantPos=done.down();plantItem=pendingSeed;plantWait=3;plantRetries=0;}
            pendingSeed=null;return;
        }
        if(++breakingTicks>100){skipUntil.put(done,tickCount+50);breakingPos=null;breakingTicks=0;pendingSeed=null;releaseKeys();return;}
        lookAt(c,aimPointFor(c,done));c.interactionManager.updateBlockBreakingProgress(done,Direction.UP);
    }

    /** Главное исправление: после ПКМ не сбрасываем plantPos. Ждём реального блока и повторяем посадку. */
    private void doReplant(MinecraftClient c){
        if(plantPos==null)return;if(plantWait>0){plantWait--;return;}
        BlockPos ground=plantPos;Block b=c.world.getBlockState(ground).getBlock();if(!isPlantableGround(c,ground)){clearPlant();return;}
        if(distTo(c,ground)>3.0){moveToward(c,ground);return;}
        int slot=findItemSlot(c,plantItem);if(slot<0){if(++plantRetries>30){notify("§e[Фермер] Семена не найдены — посадка отменена");clearPlant();}return;}
        selectSlot(c,slot);releaseKeys();
        Vec3d hitPoint=plantHitPoint(c,ground);lookAt(c,hitPoint);
        BlockHitResult hit=raycastForFace(c,ground,Direction.UP);
        if(hit==null){if(++plantRetries>20){plantWait=4;plantRetries=0;}return;}
        try{c.interactionManager.interactBlock(c.player,Hand.MAIN_HAND,hit);}catch(Exception ignored){return;}
        // Проверяем несколько тиков. Только если реально появилась культура, завершаем.
        Block after=c.world.getBlockState(ground.up()).getBlock();
        if(isCropBlockForItem(after,plantItem)){clearPlant();return;}
        if(++plantRetries<12){plantWait=2;return;}
        notify("§e[Фермер] Не удалось посадить на "+ground.getX()+","+ground.getY()+","+ground.getZ());clearPlant();
    }
    private void clearPlant(){plantPos=null;plantItem=null;plantRetries=0;plantWait=0;}
    private boolean isCropBlockForItem(Block b,Item item){return item==Items.WHEAT_SEEDS&&b==Blocks.WHEAT||item==Items.CARROT&&b==Blocks.CARROTS||item==Items.POTATO&&b==Blocks.POTATOES||item==Items.BEETROOT_SEEDS&&b==Blocks.BEETROOTS||item==Items.NETHER_WART&&b==Blocks.NETHER_WART;}
    private Vec3d plantHitPoint(MinecraftClient c,BlockPos p){return new Vec3d(p.getX()+.5,p.getY()+1.0,p.getZ()+.5);}
    private BlockHitResult raycastForFace(MinecraftClient c,BlockPos p,Direction side){Vec3d eye=c.player.getEyePos(),target=plantHitPoint(c,p);try{return c.world.raycast(new RaycastContext(eye,target,RaycastContext.ShapeType.OUTLINE,RaycastContext.FluidHandling.NONE,c.player));}catch(Exception e){return null;}}
    private boolean isPlantableGround(MinecraftClient c,BlockPos p){Block b=c.world.getBlockState(p).getBlock();return b==Blocks.FARMLAND||b==Blocks.SOUL_SAND;}

    private BlockPos findMatureCrop(MinecraftClient c){
        int r=Math.max(2,Math.min(32,HungerGuardConfig.get().farmerRange));BlockPos center=c.player.getBlockPos();List<BlockPos> found=new ArrayList<>();
        for(int dx=-r;dx<=r;dx++)for(int dz=-r;dz<=r;dz++)for(int dy=-2;dy<=2;dy++){BlockPos p=center.add(dx,dy,dz);Integer u=skipUntil.get(p);if(u!=null&&u>tickCount)continue;if(isHarvestable(c,p,c.world.getBlockState(p)))found.add(p);}
        found.sort(Comparator.comparingDouble(p->c.player.squaredDistanceTo(p.getX()+.5,p.getY()+.5,p.getZ()+.5)));if(found.isEmpty())return null;
        BlockPos p=found.get(0);Block b=c.world.getBlockState(p).getBlock();if(b==Blocks.SUGAR_CANE||b==Blocks.CACTUS){while(p.getY()>c.world.getBottomY()){Block below=c.world.getBlockState(p.down()).getBlock();if(below!=b)break;p=p.down();}}return p;
    }
    private boolean isHarvestable(MinecraftClient c,BlockPos p,BlockState st){Block b=st.getBlock();if(b==Blocks.SUGAR_CANE)return c.world.getBlockState(p.up()).isAir();if(b==Blocks.CACTUS)return c.world.getBlockState(p.up()).isAir();if(b==Blocks.PUMPKIN||b==Blocks.MELON)return true;if(!CROPS.contains(b))return false;var props=st.getProperties();for(var prop:props){if(prop instanceof net.minecraft.state.property.IntProperty ip){try{return st.get(ip)>=ip.getValues().stream().max(Integer::compareTo).orElse(0);}catch(Exception ignored){}}}return false;}
    private Item seedFor(Block b){if(b==Blocks.WHEAT)return Items.WHEAT_SEEDS;if(b==Blocks.CARROTS)return Items.CARROT;if(b==Blocks.POTATOES)return Items.POTATO;if(b==Blocks.BEETROOTS)return Items.BEETROOT_SEEDS;if(b==Blocks.NETHER_WART)return Items.NETHER_WART;return null;}

    private void autoToolSwitch(MinecraftClient c){Item held=c.player.getMainHandStack().getItem();if(held!=lastHeld&&lastHeld!=Items.AIR&&held==Items.AIR){int slot=findBestTool(c);if(slot>=0)selectSlot(c,slot);}lastHeld=held;}
    private int findBestTool(MinecraftClient c){PlayerInventory inv=c.player.getInventory();for(int i=0;i<9;i++){ItemStack s=inv.getStack(i);if(!s.isEmpty()&&s.isDamageable()&&s.getDamage()<s.getMaxDamage()-1)return i;}return -1;}
    private int findItemSlot(MinecraftClient c,Item item){if(item==null)return -1;PlayerInventory inv=c.player.getInventory();for(int i=0;i<36;i++){ItemStack s=inv.getStack(i);if(!s.isEmpty()&&s.getItem()==item)return i;}return -1;}
    private void selectSlot(MinecraftClient c,int slot){PlayerInventory inv=c.player.getInventory();if(slot<9){inv.setSelectedSlot(slot);return;}try{int sync=c.player.playerScreenHandler.syncId;c.interactionManager.clickSlot(sync,slot,0,SlotActionType.PICKUP,c.player);c.interactionManager.clickSlot(sync,36,0,SlotActionType.PICKUP,c.player);inv.setSelectedSlot(0);}catch(Exception ignored){}}

    private boolean isInventoryFull(MinecraftClient c){PlayerInventory inv=c.player.getInventory();for(int i=9;i<36;i++)if(inv.getStack(i).isEmpty())return false;return true;}
    private void doDeposit(MinecraftClient c){
        if(depositStep==1){if(depositChest==null)depositChest=findNearestChest(c);if(depositChest==null){if(tickCount-lastNoChestWarn>200){lastNoChestWarn=tickCount;notify("§e[Фермер] Сундук не найден рядом");}depositStep=0;depositCooldownUntil=tickCount+200;return;}if(distTo(c,depositChest)>4){moveToward(c,depositChest);return;}releaseKeys();lookAt(c,Vec3d.ofCenter(depositChest));BlockHitResult hit=raycastToPoint(c,Vec3d.ofCenter(depositChest));if(hit==null){depositStep=0;depositChest=null;return;}c.interactionManager.interactBlock(c.player,Hand.MAIN_HAND,hit);depositStep=2;depositTicks=8;return;}
        if(depositStep==2){if(depositTicks-->0)return;ScreenHandler sh=c.player.currentScreenHandler;if(sh==null||sh==c.player.playerScreenHandler){depositStep=0;depositChest=null;depositCooldownUntil=tickCount+60;return;}int start=Math.max(0,sh.slots.size()-36);for(int i=start;i<sh.slots.size();i++){ItemStack s=sh.getSlot(i).getStack();if(!s.isEmpty()&&shouldDeposit(s.getItem()))c.interactionManager.clickSlot(sh.syncId,i,0,SlotActionType.QUICK_MOVE,c.player);}c.setScreen(null);depositStep=0;depositChest=null;depositCooldownUntil=tickCount+100;}
    }
    private BlockPos findNearestChest(MinecraftClient c){int r=Math.max(2,HungerGuardConfig.get().farmerChestRadius);BlockPos o=c.player.getBlockPos(),best=null;double bd=Double.MAX_VALUE;for(int x=-r;x<=r;x++)for(int y=-2;y<=2;y++)for(int z=-r;z<=r;z++){BlockPos p=o.add(x,y,z);Block b=c.world.getBlockState(p).getBlock();if(b==Blocks.CHEST||b==Blocks.TRAPPED_CHEST){double d=c.player.squaredDistanceTo(Vec3d.ofCenter(p));if(d<bd){bd=d;best=p;}}}return best;}
    private boolean shouldDeposit(Item item){List<String> ids=HungerGuardConfig.get().farmerDepositItemIds;return ids!=null&&!ids.isEmpty()&&ids.contains(Registries.ITEM.getId(item).toString());}
    private BlockHitResult raycastToPoint(MinecraftClient c,Vec3d target){try{return c.world.raycast(new RaycastContext(c.player.getEyePos(),target,RaycastContext.ShapeType.OUTLINE,RaycastContext.FluidHandling.NONE,c.player));}catch(Exception e){return null;}}
    private Vec3d aimPointFor(MinecraftClient c,BlockPos p){try{Box box=c.world.getBlockState(p).getOutlineShape(c.world,p).getBoundingBox();return new Vec3d(p.getX()+box.getCenter().x,p.getY()+box.getCenter().y,p.getZ()+box.getCenter().z);}catch(Exception e){return Vec3d.ofCenter(p);}}
    private double distTo(MinecraftClient c,BlockPos p){return c.player.getEyePos().distanceTo(Vec3d.ofCenter(p));}
    private void moveToward(MinecraftClient c,BlockPos p){moveToward(c,Vec3d.ofCenter(p));}
    private void moveToward(MinecraftClient c,Vec3d target){if(c.player.isCreative()){Vec3d e=c.player.getEyePos(),d=target.subtract(e);if(d.length()<.01)return;double step=Math.min(.5*Math.max(.2,HungerGuardConfig.get().farmerMoveSpeed),Math.max(.12,d.length()-1.8));Vec3d n=d.normalize().multiply(step);double off=e.y-c.player.getY();c.player.setPosition(e.x+n.x,e.y+n.y-off,e.z+n.z);c.player.setVelocity(Vec3d.ZERO);}else{double dx=target.x-c.player.getX(),dz=target.z-c.player.getZ();setLook(c,(float)Math.toDegrees(Math.atan2(-dx,dz)),c.player.getPitch());c.options.forwardKey.setPressed(true);if(c.player.horizontalCollision)c.options.jumpKey.setPressed(true);Vec3d p=c.player.getPos();if(stuckRef==null)stuckRef=p;else if(p.squaredDistanceTo(stuckRef)<.04){if(++stuckTicks%12==0)c.options.jumpKey.setPressed(true);}else{stuckRef=p;stuckTicks=0;}}lookAt(c,target);}
    private void lookAt(MinecraftClient c,Vec3d p){Vec3d e=c.player.getEyePos();double dx=p.x-e.x,dy=p.y-e.y,dz=p.z-e.z,h=Math.sqrt(dx*dx+dz*dz);setLook(c,(float)Math.toDegrees(Math.atan2(-dx,dz)),(float)-Math.toDegrees(Math.atan2(dy,h)));}
    private void setLook(MinecraftClient c,float yaw,float pitch){float s=MathHelper.clamp(HungerGuardConfig.get().farmerSharpness,0f,1f);if(!lookInit){smoothYaw=c.player.getYaw();smoothPitch=c.player.getPitch();lookInit=true;}if(s>=.95f){smoothYaw=yaw;smoothPitch=pitch;}else{float l=.16f+s*.68f;smoothYaw+=MathHelper.wrapDegrees(yaw-smoothYaw)*l;smoothPitch+=(pitch-smoothPitch)*l;}c.player.setYaw(smoothYaw);c.player.setPitch(smoothPitch);c.player.headYaw=smoothYaw;c.player.bodyYaw=smoothYaw;}
    private void releaseKeys(){MinecraftClient c=MinecraftClient.getInstance();c.options.forwardKey.setPressed(false);c.options.backKey.setPressed(false);c.options.leftKey.setPressed(false);c.options.rightKey.setPressed(false);c.options.jumpKey.setPressed(false);c.options.sneakKey.setPressed(false);}
    private void notify(String s){MinecraftClient c=MinecraftClient.getInstance();if(c.player!=null)c.player.sendMessage(Text.literal(s),false);}
}
