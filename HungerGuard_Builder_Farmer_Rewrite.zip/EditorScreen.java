package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import com.example.hungerguard.builder.BuilderTemplate;
import com.example.hungerguard.builder.TemplateStore;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Рабочий voxel-редактор. Строение хранится в 3 координатах X/Y/Z.
 * Редактирование идёт по слоям Y: на каждом слое можно рисовать целую конструкцию,
 * а кнопки «слой -/+» позволяют собрать многоэтажный дом, башню, стены и т.п.
 */
public class EditorScreen extends Screen {
    private final Screen parent;
    private final String templateName;
    private BuilderTemplate template;
    private int layer=0;
    private int cell=18;
    private int gridX,gridY;
    private TextFieldWidget blockId;
    private String status="";
    private boolean erase=false;

    public EditorScreen(Screen parent,String templateName){super(Text.literal("3D Редактор"));this.parent=parent;this.templateName=templateName;}

    @Override protected void init(){
        template=TemplateStore.load(templateName);
        if(template==null){close();return;}
        layer=Math.max(0,Math.min(layer,template.dy-1));
        cell=Math.max(10,Math.min(22,(this.height-110)/Math.max(1,Math.max(template.dx,template.dz))));
        int side=Math.min(520,Math.max(260,Math.min(this.width-250,this.height-90)));
        gridX=24;gridY=64;
        blockId=new TextFieldWidget(textRenderer,24,40,250,18,Text.literal("minecraft:stone"));
        blockId.setMaxLength(120);blockId.setText("minecraft:stone");addDrawableChild(blockId);
        addDrawableChild(ButtonWidget.builder(Text.literal("Слой −"),b->{layer=Math.max(0,layer-1);}).dimensions(282,40,70,18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Слой +"),b->{layer=Math.min(template.dy-1,layer+1);}).dimensions(356,40,70,18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Кисть"),b->{erase=false;}).dimensions(430,40,58,18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Ластик"),b->{erase=true;}).dimensions(492,40,64,18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Заполнить слой"),b->fillLayer()).dimensions(24,this.height-38,120,18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Очистить слой"),b->clearLayer()).dimensions(148,this.height-38,110,18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Сохранить"),b->save()).dimensions(this.width-190,this.height-38,80,18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Назад"),b->close()).dimensions(this.width-104,this.height-38,80,18).build());
    }

    @Override public void render(DrawContext c,int mouseX,int mouseY,float delta){
        c.fill(0,0,width,height,0xF010141A);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal("§b§l3D ШАБЛОН: "+templateName),width/2,10,0xFFFFFF);
        c.drawTextWithShadow(textRenderer,Text.literal("§7Слой Y: §f"+layer+" / "+(template.dy-1)),24,26,0xFFFFFF);
        c.drawTextWithShadow(textRenderer,Text.literal("§7ЛКМ — поставить · ПКМ — удалить · Колесо — сменить слой"),24,height-60,0xAAB4BE);
        int maxX=Math.min(template.dx,24),maxZ=Math.min(template.dz,24);
        for(int z=0;z<maxZ;z++) for(int x=0;x<maxX;x++){
            int px=gridX+x*cell,py=gridY+z*cell;
            BuilderTemplate.Block b=template.getBlock(x,layer,z);
            int fill=b==null?0xFF18212A:colorFor(b.id);
            c.fill(px,py,px+cell-1,py+cell-1,fill);
            c.drawBorder(px,py,px+cell-1,py+cell-1,0xFF34404C);
            if(b!=null&&cell>=15)c.drawText(textRenderer,Text.literal(shortName(b.id)),px+2,py+5,0xFFFFFFFF,false);
        }
        // Простая боковая 3D-подсказка: структура действительно трёхмерная, слой только выбирает Y.
        int sx=width-205,sy=70;
        c.drawTextWithShadow(textRenderer,Text.literal("§b3D-сцена"),sx,sy,0xFFFFFF);
        c.drawTextWithShadow(textRenderer,Text.literal("§7Размер: "+template.dx+"×"+template.dy+"×"+template.dz),sx,sy+18,0xFFFFFF);
        c.drawTextWithShadow(textRenderer,Text.literal("§7Блоков: "+template.blockCount()),sx,sy+34,0xFFFFFF);
        c.drawTextWithShadow(textRenderer,Text.literal("§8Каждый слой Y сохраняется"),sx,sy+56,0xFF888888);
        c.drawTextWithShadow(textRenderer,Text.literal("§8отдельно — можно делать"),sx,sy+70,0xFF888888);
        c.drawTextWithShadow(textRenderer,Text.literal("§8стены, полы и башни."),sx,sy+84,0xFF888888);
        super.render(c,mouseX,mouseY,delta);
    }

    @Override public boolean mouseClicked(double mx,double my,int button){
        if(super.mouseClicked(mx,my,button))return true;
        int x=(int)((mx-gridX)/cell),z=(int)((my-gridY)/cell);
        if(x<0||z<0||x>=template.dx||z>=template.dz||x>=24||z>=24)return false;
        if(button==0){
            String id=blockId.getText().trim();
            if(erase)template.setBlock(x,layer,z,null);
            else if(validBlock(id))template.setBlock(x,layer,z,id);
            else status="Неизвестный block id";
            return true;
        }
        if(button==1){template.setBlock(x,layer,z,null);return true;}
        return false;
    }

    @Override public boolean mouseScrolled(double mx,double my,double amount){
        if(amount>0)layer=Math.min(template.dy-1,layer+1);else if(amount<0)layer=Math.max(0,layer-1);return true;
    }
    private void fillLayer(){String id=blockId.getText().trim();if(!validBlock(id))return;for(int x=0;x<template.dx;x++)for(int z=0;z<template.dz;z++)template.setBlock(x,layer,z,id);}
    private void clearLayer(){for(int x=0;x<template.dx;x++)for(int z=0;z<template.dz;z++)template.setBlock(x,layer,z,null);}
    private boolean validBlock(String id){try{return Registries.BLOCK.containsId(Identifier.of(id));}catch(Exception e){return false;}}
    private int colorFor(String id){int h=Math.abs(id.hashCode());return 0xFF20252B|((h&0x3F)<<16)|(((h>>6)&0x3F)<<8)|(h>>12&0x3F);}
    private String shortName(String id){int p=id.indexOf(':');String s=p>=0?id.substring(p+1):id;return s.length()>7?s.substring(0,7):s;}
    private void save(){TemplateStore.save(template);HungerGuardConfig.get().builderTemplate=templateName;HungerGuardConfig.save();status="Сохранено";notify("§a[Строитель] Шаблон сохранён");}
    private void notify(String s){if(client!=null&&client.player!=null)client.player.sendMessage(Text.literal(s),false);}
    @Override public void close(){if(client!=null)client.setScreen(parent);}
    @Override public boolean shouldPause(){return false;}
}
