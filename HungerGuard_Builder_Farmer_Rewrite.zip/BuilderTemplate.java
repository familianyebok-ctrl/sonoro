package com.example.hungerguard.builder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

/** Шаблон постройки. Хранит не только id блока, но и его состояние (свойства). */
public class BuilderTemplate {
    public String name = "";
    public int dx = 16, dy = 16, dz = 16;
    public List<Block> blocks = new ArrayList<>();

    public static class Block {
        public int x, y, z;
        public String id;
        /** JSON-совместимая строка свойств: facing=north;half=bottom;axis=x */
        public String state = "";

        public Block() {}
        public Block(int x, int y, int z, String id) { this(x, y, z, id, ""); }
        public Block(int x, int y, int z, String id, String state) {
            this.x=x; this.y=y; this.z=z; this.id=id; this.state=state == null ? "" : state;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static BuilderTemplate createEmpty(String name, int dx, int dy, int dz) {
        BuilderTemplate t = new BuilderTemplate();
        t.name = name;
        t.dx = Math.max(1, dx); t.dy = Math.max(1, dy); t.dz = Math.max(1, dz);
        return t;
    }

    public String getBlockId(int x, int y, int z) {
        for (Block b : blocks) if (b.x==x && b.y==y && b.z==z) return b.id;
        return null;
    }

    public Block getBlock(int x, int y, int z) {
        for (Block b : blocks) if (b.x==x && b.y==y && b.z==z) return b;
        return null;
    }

    public void setBlock(int x, int y, int z, String id) { setBlock(x,y,z,id,""); }

    public void setBlock(int x, int y, int z, String id, String state) {
        if (x<0 || y<0 || z<0 || x>=dx || y>=dy || z>=dz) return;
        blocks.removeIf(b -> b.x==x && b.y==y && b.z==z);
        if (id != null && !id.isEmpty()) blocks.add(new Block(x,y,z,id,state));
    }

    public void clear() { blocks.clear(); }
    public int blockCount() { return blocks.size(); }
    public String toJson() { return GSON.toJson(this); }

    public static BuilderTemplate fromJson(String json) {
        BuilderTemplate t = GSON.fromJson(json, BuilderTemplate.class);
        if (t == null) t = new BuilderTemplate();
        if (t.blocks == null) t.blocks = new ArrayList<>();
        if (t.dx < 1) t.dx=16; if (t.dy < 1) t.dy=16; if (t.dz < 1) t.dz=16;
        return t;
    }
}
