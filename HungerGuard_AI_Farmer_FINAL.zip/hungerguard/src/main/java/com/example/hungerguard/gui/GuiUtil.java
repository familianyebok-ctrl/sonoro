package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Хелперы отрисовки: скруглённые панели, тумблеры, круги + кэш списка предметов.
 */
public final class GuiUtil {

    private GuiUtil() {
    }

    // === Общие цвета панелей — одинаковые для всех тем ===
    public static final int COLOR_PANEL_BG = 0xE60E141C;
    public static final int COLOR_ROW_BG = 0xFF141C26;
    public static final int COLOR_ROW_HOVER = 0xFF1B2733;
    public static final int COLOR_TEXT_MUTED = 0xFF8CA0A8;

    // === Цвета нового премиум-меню ===
    public static final int COLOR_WINDOW_BG = 0xF20C1118;   // фон главного окна
    public static final int COLOR_BLOCK_BG = 0xFF141C26;    // фон блоков (Interface/Elements)
    public static final int COLOR_SEPARATOR = 0xFF232B36;    // тонкие разделители
    public static final int COLOR_TOGGLE_OFF = 0xFF3A4048;   // выключенный тумблер

    /** Один цветовой пресет темы: обычный акцент и приглушённый (для выключенного состояния). */
    public record Theme(String name, int accent, int accentDim) {
    }

    /** Пастельные цветовые темы меню. Переключаются квадратиками в блоке Themes. */
    public static final Theme[] THEMES = new Theme[]{
            new Theme("Бирюза", 0xFF3ED6C4, 0xFF1E6F64),
            new Theme("Фиолет", 0xFFB27EFF, 0xFF5B4085),
            new Theme("Янтарь", 0xFFFFA83E, 0xFF8A5A22),
            new Theme("Роза", 0xFFFF6E97, 0xFF80384C),
            new Theme("Лайм", 0xFF8CE04A, 0xFF4C6F28),
            new Theme("Голубой", 0xFF7EC8FF, 0xFF3E6C9E),
            new Theme("Мята", 0xFF8CE6B4, 0xFF3E7A5A),
            new Theme("Сирень", 0xFFC9A6FF, 0xFF6B5585),
            new Theme("Персик", 0xFFFFB98A, 0xFF8A5A3E),
            new Theme("Розовый", 0xFFFFA6D5, 0xFF855170)
    };

    private static Theme theme() {
        int idx = HungerGuardConfig.get().themeIndex;
        if (idx < 0 || idx >= THEMES.length) idx = 0;
        return THEMES[idx];
    }

    /** Текущий акцентный цвет выбранной темы (для включённых элементов). */
    public static int accent() {
        return theme().accent();
    }

    /** Приглушённый вариант акцента (для выключенных/неактивных элементов). */
    public static int accentDim() {
        return theme().accentDim();
    }

    /** Название текущей темы. */
    public static String themeName() {
        return theme().name();
    }

    /** Переключить на следующую тему по кругу и сохранить выбор в конфиг. */
    public static void cycleTheme() {
        HungerGuardConfig cfg = HungerGuardConfig.get();
        cfg.themeIndex = (cfg.themeIndex + 1) % THEMES.length;
        HungerGuardConfig.save();
    }

    /** Установить конкретную тему по индексу. */
    public static void setTheme(int index) {
        if (index < 0 || index >= THEMES.length) return;
        HungerGuardConfig cfg = HungerGuardConfig.get();
        cfg.themeIndex = index;
        HungerGuardConfig.save();
    }

    /** Закрашенный круг через горизонтальные полосы. */
    public static void fillCircle(DrawContext context, int cx, int cy, int radius, int color) {
        if (radius <= 0) return;
        for (int dy = -radius; dy <= radius; dy++) {
            int dx = (int) Math.sqrt((double) radius * radius - (double) dy * dy);
            context.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, color);
        }
    }

    /** "Таблетка" (rounded rect) — прямоугольник с круглыми краями, как трек тумблера. */
    public static void fillPill(DrawContext context, int x, int y, int width, int height, int color) {
        int radius = height / 2;
        fillCircle(context, x + radius, y + radius, radius, color);
        fillCircle(context, x + width - radius, y + radius, radius, color);
        context.fill(x + radius, y, x + width - radius, y + height, color);
    }

    /** Полноценный скруглённый прямоугольник с заданным радиусом. */
    public static void fillRoundRect(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        if (width <= 0 || height <= 0) return;
        if (radius <= 0) {
            context.fill(x, y, x + width, y + height, color);
            return;
        }
        int r = Math.min(radius, Math.min(width, height) / 2);
        fillCircle(context, x + r, y + r, r, color);
        fillCircle(context, x + width - r - 1, y + r, r, color);
        fillCircle(context, x + r, y + height - r - 1, r, color);
        fillCircle(context, x + width - r - 1, y + height - r - 1, r, color);
        context.fill(x + r, y, x + width - r, y + height, color);
        context.fill(x, y + r, x + width, y + height - r, color);
    }

    /** Панель с лёгкой подсветкой по верхнему и левому краю — простой эффект объёма. */
    public static void fillPanel(DrawContext context, int x, int y, int width, int height, int color) {
        context.fill(x, y, x + width, y + height, color);
        context.fill(x, y, x + width, y + 1, 0x33FFFFFF);
        context.fill(x, y, x + 1, y + height, 0x22FFFFFF);
        context.fill(x, y + height - 1, x + width, y + height, 0x33000000);
    }

    /** Линейная интерполяция между двумя ARGB-цветами. */
    public static int lerpColor(int colorA, int colorB, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aA = (colorA >> 24) & 0xFF, rA = (colorA >> 16) & 0xFF, gA = (colorA >> 8) & 0xFF, bA = colorA & 0xFF;
        int aB = (colorB >> 24) & 0xFF, rB = (colorB >> 16) & 0xFF, gB = (colorB >> 8) & 0xFF, bB = colorB & 0xFF;
        int a = (int) (aA + (aB - aA) * t);
        int r = (int) (rA + (rB - rA) * t);
        int g = (int) (gA + (gB - gA) * t);
        int b = (int) (bA + (bB - bA) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // === Кэш предметов и их названий ===

    private static List<Item> cachedItems = null;
    private static final Map<Item, String> cachedNames = new HashMap<>();

    /** Все предметы (без AIR) — собирается один раз, но с защитой от пустого кэша на титульном экране. */
    public static synchronized List<Item> allItems() {
        if (cachedItems == null || cachedItems.isEmpty() || cachedItems.size() < 50) {
            List<Item> list = new ArrayList<>();
            for (Item item : Registries.ITEM) {
                if (item == Items.AIR) continue;
                // ИСПРАВЛЕНО: не фильтруем по ItemStack.isEmpty() — на титульном экране стаки могут быть пустыми и тогда палитра пустая (только камень)
                list.add(item);
            }
            // Кэшируем только если список достаточно полный (>100), иначе оставляем возможность пересобрать при входе в мир
            if (list.size() > 100) cachedItems = list;
            else if (cachedItems == null || cachedItems.isEmpty()) cachedItems = list;
            // Если список маленький но не пустой — вернём его, но не кэшируем навсегда чтобы не застрять на неполном
            if (list.size() > 100) return cachedItems;
            return list;
        }
        return cachedItems;
    }
    /** Принудительно пересобрать кэш (вызывать при входе в мир). */
    public static synchronized void invalidateItemCache() { cachedItems = null; cachedNames.clear(); }

    /** Локализованное название предмета (кэшируется). */
    public static String itemName(Item item) {
        return cachedNames.computeIfAbsent(item, i -> {
            try {
                return new ItemStack(i).getName().getString();
            } catch (Exception e) {
                return Registries.ITEM.getId(i).getPath();
            }
        });
    }
}
