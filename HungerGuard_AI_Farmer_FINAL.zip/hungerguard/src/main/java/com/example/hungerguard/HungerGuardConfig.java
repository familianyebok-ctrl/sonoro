package com.example.hungerguard;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class HungerGuardConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("hungerguard.json");

    public static final int MAX_MACRO_COOLDOWN_TICKS = 600;

    private static HungerGuardConfig instance = new HungerGuardConfig();

    public boolean hungerEnabled = true;
    public int foodThreshold = 6;
    public List<String> actionLines = new ArrayList<>(List.of("#stop", "/home"));
    /** Пауза между строками-действиями при голоде (в тиках). 10 тиков = 0.5 сек. */
    public int hungerActionDelayTicks = 10;

    public boolean macroEnabled = true;
    public boolean macroLoop = false;
    public int macroCooldownTicks = 0;

    public boolean macroRestoreInventory = true;
    public boolean macroAutoTakeFromInventory = true;
    public boolean macroLogToChat = true;
    public List<String> macroInventoryItemIds = new ArrayList<>();

    public int macroLegitLevel = 0;
    public boolean macroGcdFix = false;
    public boolean macroAimJitter = false;
    public float macroAimJitterBase = 0.05f;
    public float macroAimFatigueStress = 0.12f;
    public boolean macroOvershoot = false;
    public float macroOvershootChance = 0.03f;
    public float macroOvershootMax = 0.8f;
    public float macroOvershootCorrection = 0.4f;
    public boolean macroTimingJitter = false;
    public int macroTimingJitterMax = 2;
    public float macroFrameSkipChance = 0.015f;
    public float macroExtraPauseChance = 0.02f;
    public boolean macroClickRandom = false;
    public float macroClickSkipChance = 0.04f;
    public float macroClickDoubleChance = 0.01f;
    public boolean macroBlink = false;
    public float macroBlinkChance = 0.002f;
    public boolean macroHumanError = false;
    public boolean macroMoveJitter = false;
    public float macroMoveJitterChance = 0.03f;

    public float macroPlaybackSpeed = 1.0f;
    public float macroSharpness = 1.0f;
    /** Доп. плавность камеры в «Точном» режиме: 0 = как раньше, 1 = максимально мягко. */
    public float macroSmoothness = 0f;

    public int themeIndex = 0;

    public boolean autoSellEnabled = false;
    public int autoSellDelayMs = 500;
    public String autoSellCommand = "/market sell 400";
    public List<String> autoSellItemIds = new ArrayList<>();

    // === Строитель ===
    public boolean builderEnabled = true;
    public String builderTemplate = "";
    public boolean builderAnchorCorner = false; // false = центр постройки, true = угол (мин. угол)
    public boolean builderAnchorSet = false;
    public int builderAnchorX = 0;
    public int builderAnchorY = 0;
    public int builderAnchorZ = 0;
    public int builderDelayTicks = 2; // пауза между блоками (0 = каждый тик)
    // Захват региона из мира (импорт готовой постройки): два противоположных угла
    public boolean builderCornerASet = false;
    public int builderCornerAX = 0;
    public int builderCornerAY = 0;
    public int builderCornerAZ = 0;
    public boolean builderCornerBSet = false;
    public int builderCornerBX = 0;
    public int builderCornerBY = 0;
    public int builderCornerBZ = 0;

    // === Строитель: редактор и бот ===
    public boolean editorShowGrid = true;   // сетка в 3D-редакторе (как в Blender)
    public int editorVisualMode = 0;        // 0 обычный, 1 обводка, 2 переливание, 3 плазма, 4 пульсация
    public float builderMoveSpeed = 1.0f;   // множитель скорости движения бота
    public float builderSharpness = 0.6f;   // резкость поворота бота (0 плавно, 1 мгновенно)
    public boolean builderVerify = true;    // проверять блок: промахнулся — ломает и ставит заново

    // === Авто-ферма ===
    public boolean farmerEnabled = true;
    public boolean farmerReplant = true;
    public boolean farmerDeposit = true;
    public int farmerRange = 8;              // дальность сканирования, 3..15
    public int farmerChestRadius = 6;        // радиус поиска сундука, 2..16
    public int farmerShiftIntervalTicks = 600; // интервал шифта (30 сек)
    public float farmerMoveSpeed = 1.0f;
    public float farmerSharpness = 0.6f;
    public boolean farmerToolSwitch = true;
    public boolean farmerStrict = true;
    public boolean farmerSprint = false;
    public boolean farmerAutoJump = true;
    public int farmerScanIntervalTicks = 3;
    public int farmerMaxTurnAngle = 75;
    public float farmerMaxTurnPerTick = 18.0f;
    public int farmerToolReservePercent = 12;
    public int farmerStuckTicks = 35;
    public int farmerRetryDelayTicks = 100;
    public float farmerClusterWeight = 4.0f;
    public List<String> farmerCropIds = new ArrayList<>();
    public List<String> farmerDepositItemIds = new ArrayList<>();

    public static HungerGuardConfig get() { return instance; }

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                String json = Files.readString(PATH);
                HungerGuardConfig loaded = GSON.fromJson(json, HungerGuardConfig.class);
                instance = (loaded != null) ? loaded : new HungerGuardConfig();
            } else {
                instance = new HungerGuardConfig();
                save();
            }
        } catch (IOException e) {
            instance = new HungerGuardConfig();
        }

        instance.foodThreshold = clamp(instance.foodThreshold);
        instance.hungerActionDelayTicks = Math.max(0, Math.min(100, instance.hungerActionDelayTicks));
        if (instance.actionLines == null || instance.actionLines.isEmpty()) {
            instance.actionLines = new ArrayList<>(List.of("#stop", "/home"));
        }
        instance.macroCooldownTicks = clampCooldown(instance.macroCooldownTicks);

        int themeCount = com.example.hungerguard.gui.GuiUtil.THEMES.length;
        if (instance.themeIndex < 0 || instance.themeIndex >= themeCount) {
            instance.themeIndex = 0;
        }

        instance.macroLegitLevel = Math.max(0, Math.min(3, instance.macroLegitLevel));
        instance.macroTimingJitterMax = Math.max(0, Math.min(5, instance.macroTimingJitterMax));
        instance.macroPlaybackSpeed = Math.max(0.5f, Math.min(5.0f, instance.macroPlaybackSpeed));
        instance.macroSharpness = Math.max(0.05f, Math.min(1.0f, instance.macroSharpness));
        instance.macroSmoothness = Math.max(0f, Math.min(1f, instance.macroSmoothness));

        if (instance.macroInventoryItemIds == null) instance.macroInventoryItemIds = new ArrayList<>();
        if (instance.autoSellItemIds == null) instance.autoSellItemIds = new ArrayList<>();
        instance.autoSellDelayMs = Math.max(100, Math.min(5000, instance.autoSellDelayMs));
        if (instance.autoSellCommand == null) instance.autoSellCommand = "/market sell 400";

        if (instance.builderTemplate == null) instance.builderTemplate = "";
        instance.builderDelayTicks = Math.max(0, Math.min(20, instance.builderDelayTicks));
        instance.editorVisualMode = Math.max(0, Math.min(4, instance.editorVisualMode));
        instance.builderMoveSpeed = Math.max(0.2f, Math.min(3f, instance.builderMoveSpeed));
        instance.builderSharpness = Math.max(0f, Math.min(1f, instance.builderSharpness));

        instance.farmerRange = Math.max(3, Math.min(15, instance.farmerRange));
        instance.farmerChestRadius = Math.max(2, Math.min(16, instance.farmerChestRadius));
        instance.farmerShiftIntervalTicks = Math.max(40, Math.min(2400, instance.farmerShiftIntervalTicks));
        instance.farmerMoveSpeed = Math.max(0.2f, Math.min(3f, instance.farmerMoveSpeed));
        instance.farmerSharpness = Math.max(0f, Math.min(1f, instance.farmerSharpness));
        instance.farmerScanIntervalTicks = Math.max(1, Math.min(20, instance.farmerScanIntervalTicks));
        instance.farmerMaxTurnAngle = Math.max(15, Math.min(180, instance.farmerMaxTurnAngle));
        instance.farmerMaxTurnPerTick = Math.max(2f, Math.min(45f, instance.farmerMaxTurnPerTick));
        instance.farmerToolReservePercent = Math.max(1, Math.min(50, instance.farmerToolReservePercent));
        instance.farmerStuckTicks = Math.max(10, Math.min(200, instance.farmerStuckTicks));
        instance.farmerRetryDelayTicks = Math.max(20, Math.min(600, instance.farmerRetryDelayTicks));
        instance.farmerClusterWeight = Math.max(0f, Math.min(20f, instance.farmerClusterWeight));
        if (instance.farmerCropIds == null) instance.farmerCropIds = new ArrayList<>();

        if (instance.farmerDepositItemIds == null) {
            instance.farmerDepositItemIds = new ArrayList<>(List.of(
                    "minecraft:carrot", "minecraft:potato", "minecraft:wheat", "minecraft:wheat_seeds",
                    "minecraft:beetroot", "minecraft:beetroot_seeds", "minecraft:sugar_cane", "minecraft:cactus",
                    "minecraft:pumpkin", "minecraft:melon", "minecraft:nether_wart", "minecraft:bamboo", "minecraft:kelp"));
        }
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(instance));
        } catch (IOException ignored) {}
    }

    public static int clamp(int value) {
        if (value < 0) return 0;
        if (value > 20) return 20;
        return value;
    }

    public static int clampCooldown(int ticks) {
        if (ticks < 0) return 0;
        if (ticks > MAX_MACRO_COOLDOWN_TICKS) return MAX_MACRO_COOLDOWN_TICKS;
        return ticks;
    }

    public static List<Item> getAutoSellItems() {
        List<Item> result = new ArrayList<>();
        if (instance.autoSellItemIds == null) return result;
        for (String id : instance.autoSellItemIds) {
            try {
                Item item = Registries.ITEM.get(Identifier.of(id));
                if (item != null && item != Items.AIR) result.add(item);
            } catch (Exception ignored) {}
        }
        return result;
    }

    public static List<Item> getMacroInventoryItems() {
        List<Item> result = new ArrayList<>();
        if (instance.macroInventoryItemIds == null) return result;
        for (String id : instance.macroInventoryItemIds) {
            try {
                Item item = Registries.ITEM.get(Identifier.of(id));
                if (item != null && item != Items.AIR) result.add(item);
            } catch (Exception ignored) {}
        }
        return result;
    }
}
