package com.example.hungerguard.gui;

import com.example.hungerguard.FarmerBot;
import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * Полное меню AI-фермера.
 * Страницы: Движение/Камера, AI/Сканирование, Инвентарь.
 */
public class FarmerScreen extends Screen {
    private static final int MAX_W = 460;
    private static final int MAX_H = 430;

    private final Screen parent;
    private int panelX, panelY, panelW, panelH;
    private int page = 0;

    public FarmerScreen(Screen parent) {
        super(Text.literal("AI Фермер"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearChildren();
        panelW = Math.min(MAX_W, width - 10);
        panelH = Math.min(MAX_H, height - 10);
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;

        int x = panelX + 16;
        int w = panelW - 32;
        int y = panelY + 56;

        if (page == 0) {
            addDrawableChild(new SpeedSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new SharpnessSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new TurnAngleSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new TurnTickSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new ToggleSwitch(x, y, w, "Прыгать через препятствия",
                    () -> HungerGuardConfig.get().farmerAutoJump,
                    v -> { HungerGuardConfig.get().farmerAutoJump = v; HungerGuardConfig.save(); }));
            y += 24;
            addDrawableChild(new ToggleSwitch(x, y, w, "Бег при перемещении",
                    () -> HungerGuardConfig.get().farmerSprint,
                    v -> { HungerGuardConfig.get().farmerSprint = v; HungerGuardConfig.save(); }));
        } else if (page == 1) {
            addDrawableChild(new RangeSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new ChestSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new ScanSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new ClusterSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new StuckSlider(x, y, w, 18)); y += 25;
            addDrawableChild(new RetrySlider(x, y, w, 18));
        } else {
            addDrawableChild(new DurabilitySlider(x, y, w, 18)); y += 25;
            addDrawableChild(new ToggleSwitch(x, y, w, "Не доводить инструмент до поломки",
                    () -> HungerGuardConfig.get().farmerToolSwitch,
                    v -> { HungerGuardConfig.get().farmerToolSwitch = v; HungerGuardConfig.save(); }));
            y += 24;
            addDrawableChild(new ToggleSwitch(x, y, w, "Авто-посев после сбора",
                    () -> HungerGuardConfig.get().farmerReplant,
                    v -> { HungerGuardConfig.get().farmerReplant = v; HungerGuardConfig.save(); }));
            y += 24;
            addDrawableChild(new ToggleSwitch(x, y, w, "Автоматически складывать урожай",
                    () -> HungerGuardConfig.get().farmerDeposit,
                    v -> { HungerGuardConfig.get().farmerDeposit = v; HungerGuardConfig.save(); }));
            y += 24;
            addDrawableChild(new ToggleSwitch(x, y, w, "Точный луч при сборе",
                    () -> HungerGuardConfig.get().farmerStrict,
                    v -> { HungerGuardConfig.get().farmerStrict = v; HungerGuardConfig.save(); }));
            y += 27;
            int n = HungerGuardConfig.get().farmerDepositItemIds == null ? 0 :
                    HungerGuardConfig.get().farmerDepositItemIds.size();
            addDrawableChild(ButtonWidget.builder(Text.literal("📦 Склад: " + n + " предметов"),
                    b -> { if (client != null) client.setScreen(new FarmerDepositScreen(this)); })
                    .dimensions(x, y, w, 20).build());
            y += 24;
            int crops = HungerGuardConfig.get().farmerCropIds == null ||
                    HungerGuardConfig.get().farmerCropIds.isEmpty() ? 11 :
                    HungerGuardConfig.get().farmerCropIds.size();
            addDrawableChild(ButtonWidget.builder(Text.literal("🌾 Что собирать: " + crops),
                    b -> { if (client != null) client.setScreen(new FarmerCropScreen(this)); })
                    .dimensions(x, y, w, 20).build());
        }

        int navY = panelY + panelH - 66;
        int bw = (w - 8) / 3;
        addDrawableChild(ButtonWidget.builder(Text.literal(page == 0 ? "Движение" : "← Движение"),
                b -> { page = 0; rebuild(); }).dimensions(x, navY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("AI / Скан"),
                b -> { page = 1; rebuild(); }).dimensions(x + bw + 4, navY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Инвентарь"),
                b -> { page = 2; rebuild(); }).dimensions(x + 2 * (bw + 4), navY, bw, 20).build());

        int actionY = panelY + panelH - 40;
        addDrawableChild(ButtonWidget.builder(Text.literal("§a▶ Старт"),
                b -> FarmerBot.INSTANCE.start()).dimensions(x, actionY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§c■ Стоп"),
                b -> FarmerBot.INSTANCE.stop()).dimensions(x + bw + 4, actionY, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"),
                b -> close()).dimensions(x + 2 * (bw + 4), actionY, bw, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        GuiUtil.fillRoundRect(ctx, panelX, panelY, panelW, panelH, 12, GuiUtil.COLOR_WINDOW_BG);
        String title = page == 0 ? "🌾 Фермер AI • Движение и камера" :
                page == 1 ? "🌾 Фермер AI • Мозг и сканирование" :
                        "🌾 Фермер AI • Инвентарь и урожай";
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§a§l" + title),
                panelX + panelW / 2, panelY + 10, 0xFFFFFF);

        String status = FarmerBot.INSTANCE.isRunning()
                ? "§a● Работает  •  собрано: " + FarmerBot.INSTANCE.getHarvested()
                : "§7○ Остановлен";
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(status),
                panelX + panelW / 2, panelY + 30, 0xFFFFFF);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override public void close() {
        if (client != null) client.setScreen(parent);
    }
    @Override public boolean shouldPause() { return false; }

    private static class RangeSlider extends SliderWidget {
        RangeSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerRange-3)/12.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal("Радиус сканирования: "+(3+(int)Math.round(value*12))+" блоков"));}
        protected void applyValue(){HungerGuardConfig.get().farmerRange=3+(int)Math.round(value*12);HungerGuardConfig.save();}
    }
    private static class ChestSlider extends SliderWidget {
        ChestSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerChestRadius-2)/14.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal("Радиус поиска сундука: "+(2+(int)Math.round(value*14))+" блоков"));}
        protected void applyValue(){HungerGuardConfig.get().farmerChestRadius=2+(int)Math.round(value*14);HungerGuardConfig.save();}
    }
    private static class SpeedSlider extends SliderWidget {
        SpeedSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerMoveSpeed-.2)/2.8);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal(String.format("Скорость движения: %.1fx",.2+value*2.8)));}
        protected void applyValue(){HungerGuardConfig.get().farmerMoveSpeed=(float)(.2+value*2.8);HungerGuardConfig.save();}
    }
    private static class SharpnessSlider extends SliderWidget {
        SharpnessSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                HungerGuardConfig.get().farmerSharpness);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal(String.format("Плавность/резкость камеры: %.2f",value)));}
        protected void applyValue(){HungerGuardConfig.get().farmerSharpness=(float)value;HungerGuardConfig.save();}
    }
    private static class TurnAngleSlider extends SliderWidget {
        TurnAngleSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerMaxTurnAngle-15)/165.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal("Макс. угол смены цели: "+(15+(int)Math.round(value*165))+"°"));}
        protected void applyValue(){HungerGuardConfig.get().farmerMaxTurnAngle=15+(int)Math.round(value*165);HungerGuardConfig.save();}
    }
    private static class TurnTickSlider extends SliderWidget {
        TurnTickSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerMaxTurnPerTick-2)/43.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal(String.format("Макс. поворот за тик: %.0f°",2+value*43)));}
        protected void applyValue(){HungerGuardConfig.get().farmerMaxTurnPerTick=(float)(2+value*43);HungerGuardConfig.save();}
    }
    private static class ScanSlider extends SliderWidget {
        ScanSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerScanIntervalTicks-1)/19.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal("Интервал сканирования: "+(1+(int)Math.round(value*19))+" тиков"));}
        protected void applyValue(){HungerGuardConfig.get().farmerScanIntervalTicks=1+(int)Math.round(value*19);HungerGuardConfig.save();}
    }
    private static class ClusterSlider extends SliderWidget {
        ClusterSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                HungerGuardConfig.get().farmerClusterWeight/20.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal(String.format("Вес соседних культур: %.1f",value*20)));}
        protected void applyValue(){HungerGuardConfig.get().farmerClusterWeight=(float)(value*20);HungerGuardConfig.save();}
    }
    private static class StuckSlider extends SliderWidget {
        StuckSlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerStuckTicks-10)/190.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal("Застрял → сменить цель через: "+(10+(int)Math.round(value*190))+" тиков"));}
        protected void applyValue(){HungerGuardConfig.get().farmerStuckTicks=10+(int)Math.round(value*190);HungerGuardConfig.save();}
    }
    private static class RetrySlider extends SliderWidget {
        RetrySlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerRetryDelayTicks-20)/580.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal("Повтор заблокированной цели через: "+(20+(int)Math.round(value*580))+" тиков"));}
        protected void applyValue(){HungerGuardConfig.get().farmerRetryDelayTicks=20+(int)Math.round(value*580);HungerGuardConfig.save();}
    }
    private static class DurabilitySlider extends SliderWidget {
        DurabilitySlider(int x,int y,int w,int h){super(x,y,w,h,Text.empty(),
                (HungerGuardConfig.get().farmerToolReservePercent-1)/49.0);updateMessage();}
        protected void updateMessage(){setMessage(Text.literal("Менять инструмент при запасе: "+(1+(int)Math.round(value*49))+"%"));}
        protected void applyValue(){HungerGuardConfig.get().farmerToolReservePercent=1+(int)Math.round(value*49);HungerGuardConfig.save();}
    }
}
