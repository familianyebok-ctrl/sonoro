package com.example.hungerguard.builder;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Хранилище шаблонов: список/загрузка/сохранение/удаление
 * в .minecraft/config/hungerguard_templates/<имя>.json
 */
public final class TemplateStore {

    private TemplateStore() {}

    private static Path dir() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("hungerguard_templates");
        try {
            Files.createDirectories(p);
        } catch (IOException ignored) {}
        return p;
    }

    private static Path file(String name) {
        return dir().resolve(name + ".json");
    }

    public static List<String> list() {
        try (Stream<Path> s = Files.list(dir())) {
            return s.filter(p -> p.toString().endsWith(".json"))
                    .map(p -> p.getFileName().toString().replace(".json", ""))
                    .sorted()
                    .collect(Collectors.toList());
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static BuilderTemplate load(String name) {
        try {
            return BuilderTemplate.fromJson(Files.readString(file(name)));
        } catch (IOException e) {
            return null;
        }
    }

    public static boolean save(BuilderTemplate t) {
        try {
            Files.writeString(file(t.name), t.toJson());
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean delete(String name) {
        try {
            return Files.deleteIfExists(file(name));
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean exists(String name) {
        return Files.exists(file(name));
    }
}
