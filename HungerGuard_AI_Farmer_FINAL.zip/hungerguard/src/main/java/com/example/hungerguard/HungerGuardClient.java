package com.example.hungerguard;

import com.example.hungerguard.gui.ClientMenuScreen;
import com.example.hungerguard.builder.BuilderBot;
import net.fabricmc.api.ClientModInitializer;import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class HungerGuardClient implements ClientModInitializer {

    public static final String MOD_ID = "hungerguard";

    private KeyBinding openMenuKey;
    private KeyBinding macroRecordStartKey;
    private KeyBinding macroRecordStopKey;
    private KeyBinding macroPlayKey;
    private KeyBinding macroStopKey;

    private boolean armed = true;

    /** Очередь строк-действий при голоде (отправляются по одной с паузой). */
    private final List<String> pendingHungerActions = new ArrayList<>();
    private int hungerActionCooldown = 0;

    @Override
    public void onInitializeClient() {
        HungerGuardConfig.load();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hungerguard.openmenu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.hungerguard"
        ));

        macroRecordStartKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hungerguard.macro_record_start",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_KP_1,
                "category.hungerguard"
        ));

        macroRecordStopKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hungerguard.macro_record_stop",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_KP_2,
                "category.hungerguard"
        ));

        macroPlayKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hungerguard.macro_play",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_KP_3,
                "category.hungerguard"
        ));

        macroStopKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hungerguard.macro_stop",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_KP_0,
                "category.hungerguard"
        ));

        ClientSendMessageEvents.CHAT.register(message -> MacroRecorder.INSTANCE.recordChat(message, false));
        ClientSendMessageEvents.COMMAND.register(command -> MacroRecorder.INSTANCE.recordChat(command, true));

        // END — вызывается ПОСЛЕ обновления игрока (тут двигаются клавиши и действия макроса)
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        // HUD + камера макроса. Рендер-фаза идёт ПОСЛЕ тика, поэтому здесь есть реальный
        // tickDelta (прогресс внутри текущего тика 0..1) — именно он нужен для плавной
        // интерполяции камеры в «Точном» режиме (раньше вызывалось из START_CLIENT_TICK
        // с tickDelta = 1.0, из-за чего камера дёргалась 20 раз в секунду).
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null
                    && MacroRecorder.INSTANCE.getState() == MacroRecorder.State.PLAYING) {
                MacroRecorder.INSTANCE.onRenderFrame(client, tickCounter.getTickProgress(false));
            }
            renderHud(context);
        });
    }

    private void onTick(MinecraftClient client) {
        while (openMenuKey.wasPressed()) {
            if (client.currentScreen == null) {
                client.setScreen(new ClientMenuScreen());
            }
        }

        checkHunger(client);
        tickHungerActions(client);
        handleMacroKeys(client);

        boolean singleplayer = client.isIntegratedServerRunning();
        boolean macroBlocked = MacroRecorder.REQUIRE_SINGLEPLAYER_FOR_MACRO && !singleplayer;
        if (!macroBlocked) {
            MacroRecorder.INSTANCE.onTick(client);
        } else if (MacroRecorder.INSTANCE.getState() != MacroRecorder.State.IDLE) {
            MacroRecorder.INSTANCE.stopPlayback(client);
        }

        if (HungerGuardConfig.get().autoSellEnabled && AutoSell.INSTANCE.isRunning()) {
            AutoSell.INSTANCE.onTick(client);
        }

        if (HungerGuardConfig.get().builderEnabled) {
            BuilderBot.INSTANCE.tick(client);
        }

        if (HungerGuardConfig.get().farmerEnabled) {
            FarmerBot.INSTANCE.tick(client);
        }
    }

    private void handleMacroKeys(MinecraftClient client) {
        boolean macroEnabled = HungerGuardConfig.get().macroEnabled;
        boolean singleplayer = client.isIntegratedServerRunning();
        boolean macroBlocked = MacroRecorder.REQUIRE_SINGLEPLAYER_FOR_MACRO && !singleplayer;

        while (macroRecordStartKey.wasPressed()) {
            if (!macroEnabled) { notify(client, "§cФункция Macro выключена"); continue; }
            if (macroBlocked) { notify(client, "§cМакрос работает только в одиночном мире!"); continue; }
            if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.RECORDING) continue;
            if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.PLAYING) MacroRecorder.INSTANCE.stopPlayback(client);
            MacroRecorder.INSTANCE.startRecording();
            notify(client, "§a[Макрос] Запись начата");
        }

        while (macroRecordStopKey.wasPressed()) {
            if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.RECORDING) {
                MacroRecorder.INSTANCE.stopRecording();
                notify(client, "§a[Макрос] Запись остановлена (" + MacroRecorder.INSTANCE.getFrameCount() + " тиков)");
            }
        }

        while (macroPlayKey.wasPressed()) {
            if (!macroEnabled) { notify(client, "§cФункция Macro выключена"); continue; }
            if (macroBlocked) { notify(client, "§cМакрос работает только в одиночном мире!"); continue; }
            if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.PLAYING) continue;
            if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.RECORDING) MacroRecorder.INSTANCE.stopRecording();
            if (MacroRecorder.INSTANCE.getFrameCount() == 0) {
                notify(client, "§cНечего воспроизводить");
            } else {
                MacroRecorder.INSTANCE.startPlayback();
                notify(client, "§b[Макрос] Воспроизведение начато");
            }
        }

        while (macroStopKey.wasPressed()) {
            if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.PLAYING) {
                MacroRecorder.INSTANCE.stopPlayback(client);
                notify(client, "§b[Макрос] Воспроизведение остановлено");
            }
        }
    }

    private void notify(MinecraftClient client, String message) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(message), false);
        }
    }

    private void renderHud(net.minecraft.client.gui.DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.currentScreen != null) return;

        int y = 6;

        if (HungerGuardConfig.get().hungerEnabled) {
            int food = client.player.getHungerManager().getFoodLevel();
            int threshold = HungerGuardConfig.get().foodThreshold;
            String hgLabel = (food <= threshold)
                    ? "§c● HungerGuard: " + food + "/" + threshold + " — сработало!"
                    : "§a● HungerGuard: " + food + " (порог " + threshold + ")";
            context.drawTextWithShadow(client.textRenderer, Text.literal(hgLabel), 6, y, 0xFFFFFF);
            y += 10;
        }

        MacroRecorder.State state = MacroRecorder.INSTANCE.getState();
        if (state != MacroRecorder.State.IDLE) {
            String label = switch (state) {
                case RECORDING -> "§4● REC  (" + MacroRecorder.INSTANCE.getFrameCount() + ")";
                case PLAYING -> "§b▶ PLAY";
                default -> "";
            };
            context.drawTextWithShadow(client.textRenderer, Text.literal(label), 6, y, 0xFFFFFF);
            y += 10;

            int cooldown = MacroRecorder.INSTANCE.getCooldownRemainingTicks();
            if (state == MacroRecorder.State.PLAYING && cooldown > 0) {
                context.drawTextWithShadow(client.textRenderer,
                        Text.literal(String.format("§e⏳ кулдаун: %.1fс", cooldown / 20.0)), 6, y, 0xFFFFFF);
            }
        }

        if (AutoSell.INSTANCE.isRunning()) {
            context.drawTextWithShadow(client.textRenderer,
                    Text.literal("§a● AutoSell: " + AutoSell.INSTANCE.getSoldCount()), 6, y, 0xFFFFFF);
            y += 10;
        }

        if (BuilderBot.INSTANCE.getState() == BuilderBot.State.RUNNING) {
            context.drawTextWithShadow(client.textRenderer,
                    Text.literal("§b● Строитель: " + BuilderBot.INSTANCE.getPlaced() + "/" + BuilderBot.INSTANCE.getTotal()),
                    6, y, 0xFFFFFF);
            y += 10;
        }

        if (FarmerBot.INSTANCE.isRunning()) {
            context.drawTextWithShadow(client.textRenderer,
                    Text.literal("§a● Фермер: " + FarmerBot.INSTANCE.getHarvested() + " собрано"),
                    6, y, 0xFFFFFF);
        }
    }

    private void checkHunger(MinecraftClient client) {
        if (!HungerGuardConfig.get().hungerEnabled) return;
        if (client.player == null || client.getNetworkHandler() == null || client.world == null) return;

        int food = client.player.getHungerManager().getFoodLevel();
        int threshold = HungerGuardConfig.get().foodThreshold;

        boolean below = food <= threshold;

        if (below && armed) {
            armed = false;
            notify(client, "§c[HungerGuard] Голод наступил! (" + food + " ≤ " + threshold + ")");

            // Кладём все строки в очередь — отправятся по одной с паузой
            pendingHungerActions.clear();
            for (String line : HungerGuardConfig.get().actionLines) {
                if (line == null || line.isBlank()) continue;
                pendingHungerActions.add(line);
            }
            hungerActionCooldown = 0;
        } else if (!below) {
            armed = true;
        }
    }

    /** Отправляет строки-действия по очереди: сначала первая, через паузу — вторая, и т.д. */
    private void tickHungerActions(MinecraftClient client) {
        if (pendingHungerActions.isEmpty()) return;
        if (client.player == null || client.getNetworkHandler() == null) return;

        if (hungerActionCooldown > 0) {
            hungerActionCooldown--;
            return;
        }

        String line = pendingHungerActions.remove(0);
        MacroRecorder.INSTANCE.runWithoutRecording(() -> {
            if (line.startsWith("/")) {
                client.getNetworkHandler().sendChatCommand(line.substring(1));
            } else {
                client.getNetworkHandler().sendChatMessage(line);
            }
        });

        // Пауза перед следующей строкой (берётся из настроек)
        hungerActionCooldown = Math.max(0, HungerGuardConfig.get().hungerActionDelayTicks);
    }
}
