package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import com.example.hungerguard.builder.BuilderBot;
import com.example.hungerguard.builder.BuilderTemplate;
import com.example.hungerguard.builder.TemplateStore;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/**
 * Вкладка «Строитель» (компактная, адаптивная):
 *  - список шаблонов (клик — выбрать), создать/удалить/редактировать;
 *  - точка привязки: центр или угол + мировые координаты;
 *  - ЗАХВАТ РЕГИОНА: встать в два противоположных угла постройки и сохранить её
 *    как шаблон (так можно «скопировать» любую готовую постройку, включая реактор);
 *  - запуск/остановка строительного бота.
 */
public class BuilderScreen extends Screen {

    private static final int MAX_W = 470;
    private static final int MAX_H = 330;
    private static final int LIST_TOP_OFF = 64;
    private static final int LIST_MAX = 6;
    private static final int ROW_H = 17;

    private final Screen parent;
    private int winX, winY, winW, winH;
    private List<String> templates = List.of();
    private String selected = "";
    private TextFieldWidget nameField;

    public BuilderScreen(Screen parent) {
        super(Text.literal("Строитель"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        winW = Math.min(MAX_W, this.width - 16);
        winH = Math.min(MAX_H, this.height - 16);
        winW = Math.max(400, winW);
        winH = Math.max(300, winH);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;
        this.clearChildren();
        // Строитель на тех.работах — показываем заглушку
        if (BuilderBot.UNDER_MAINTENANCE) {
            this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                    .dimensions(winX + winW/2 - 50, winY + winH - 30, 100, 18).build());
            return;
        }

        templates = TemplateStore.list();
        selected = HungerGuardConfig.get().builderTemplate;
        if (selected.isEmpty() && !templates.isEmpty()) selected = templates.get(0);

        int gap = 10;
        int colW = (winW - 14*2 - gap) / 2;
        int lx = winX + 14;
        int rx = winX + 14 + colW + gap;
        int lw = colW;

        // Строка: имя + Новый (адаптивно)
        int nameW = Math.max(90, colW - 65);
        nameField = new TextFieldWidget(this.textRenderer, lx, winY + 26, nameW, 16, Text.literal("Имя..."));
        nameField.setMaxLength(32);
        this.addDrawableChild(nameField);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Новый"), b -> createNew())
                .dimensions(lx + nameW + 4, winY + 26, colW - nameW - 4, 16).build());

        // Удалить / Редактировать
        int halfW = (colW - 4) / 2;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Удалить"), b -> deleteSelected())
                .dimensions(lx, winY + 44, halfW, 16).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("✏ Редактировать"), b -> openEditor())
                .dimensions(lx + halfW + 4, winY + 44, colW - halfW - 4, 16).build());

        // Настройки бота (левая колонка, низ)
        this.addDrawableChild(new ToggleSwitch(lx, winY + 188, lw, "Проверять блоки",
                () -> HungerGuardConfig.get().builderVerify,
                v -> { HungerGuardConfig.get().builderVerify = v; HungerGuardConfig.save(); }));
        this.addDrawableChild(new MoveSpeedSlider(lx, winY + 208, lw, 16));
        this.addDrawableChild(new SharpnessSlider(lx, winY + 228, lw, 16));

        this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                .dimensions(lx, winY + winH - 28, 100, 18).build());

        // Правая колонка: привязка + захват региона + запуск
        HungerGuardConfig c = HungerGuardConfig.get();
        int rightBtnW = colW;
        int smallW = (colW - 4) / 2;
        this.addDrawableChild(ButtonWidget.builder(
                        Text.literal("Режим: " + (c.builderAnchorCorner ? "Угол" : "Центр")), b -> {
                    c.builderAnchorCorner = !c.builderAnchorCorner;
                    HungerGuardConfig.save();
                    this.init();
                }).dimensions(rx, winY + 26, rightBtnW, 16).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Точка = здесь"), b -> setAnchorPlayer())
                .dimensions(rx, winY + 46, smallW, 16).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Точка = прицел"), b -> setAnchorTarget())
                .dimensions(rx + smallW + 4, winY + 46, smallW, 16).build());

        // Захват региона (импорт готовой постройки)
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Угол 1 = здесь"), b -> setCornerA())
                .dimensions(rx, winY + 92, smallW, 16).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Угол 2 = здесь"), b -> setCornerB())
                .dimensions(rx + smallW + 4, winY + 92, smallW, 16).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§a📥 Записать регион"), b -> captureRegion())
                .dimensions(rx, winY + 112, rightBtnW, 16).build());

        // Запуск
        int startW = (colW * 2) / 3;
        int stopW = colW - startW - 4;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§a▶ Начать строить"), b -> BuilderBot.INSTANCE.start())
                .dimensions(rx, winY + 156, startW, 18).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§c■ Стоп"), b -> BuilderBot.INSTANCE.stop())
                .dimensions(rx + startW + 4, winY + 156, stopW, 18).build());
    }

    private static class MoveSpeedSlider extends SliderWidget {
        MoveSpeedSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), (HungerGuardConfig.get().builderMoveSpeed - 0.2f) / 2.8f);
            updateMessage();
        }
        @Override protected void updateMessage() {
            float s = 0.2f + (float) (this.value * 2.8f);
            setMessage(Text.literal(String.format("Скорость: %.1fx", s)));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().builderMoveSpeed = 0.2f + (float) (this.value * 2.8f);
            HungerGuardConfig.save();
        }
    }

    private static class SharpnessSlider extends SliderWidget {
        SharpnessSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), HungerGuardConfig.get().builderSharpness);
            updateMessage();
        }
        @Override protected void updateMessage() {
            setMessage(Text.literal(String.format("Резкость: %.2f", this.value)));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().builderSharpness = (float) this.value;
            HungerGuardConfig.save();
        }
    }

    private void createNew() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) name = "шаблон_" + (templates.size() + 1);
        if (TemplateStore.exists(name)) {
            notify("§cТакой шаблон уже есть");
            return;
        }
        BuilderTemplate t = BuilderTemplate.createEmpty(name, 16, 16, 16);
        TemplateStore.save(t);
        HungerGuardConfig.get().builderTemplate = name;
        HungerGuardConfig.save();
        this.init();
    }

    private void deleteSelected() {
        if (selected.isEmpty()) {
            notify("§cВыбери шаблон для удаления");
            return;
        }
        TemplateStore.delete(selected);
        if (HungerGuardConfig.get().builderTemplate.equals(selected)) {
            HungerGuardConfig.get().builderTemplate = "";
            HungerGuardConfig.save();
        }
        selected = "";
        this.init();
    }

    private void openEditor() {
        if (selected.isEmpty()) {
            notify("§cВыбери шаблон для редактирования");
            return;
        }
        if (this.client != null) {
            this.client.setScreen(new EditorScreen(this, selected));
        }
    }

    private void setAnchorPlayer() {
        if (this.client == null || this.client.player == null) return;
        BlockPos p = this.client.player.getBlockPos();
        setAnchor(p.getX(), p.getY(), p.getZ());
    }

    private void setAnchorTarget() {
        if (this.client == null || this.client.player == null) return;
        if (this.client.crosshairTarget != null && this.client.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            BlockHitResult bhr = (BlockHitResult) this.client.crosshairTarget;
            BlockPos p = bhr.getBlockPos().offset(bhr.getSide());
            setAnchor(p.getX(), p.getY(), p.getZ());
        } else {
            notify("§cНаведись на блок, куда ставить постройку");
        }
    }

    private void setAnchor(int x, int y, int z) {
        HungerGuardConfig c = HungerGuardConfig.get();
        c.builderAnchorX = x;
        c.builderAnchorY = y;
        c.builderAnchorZ = z;
        c.builderAnchorSet = true;
        HungerGuardConfig.save();
        notify("§a[Строитель] Точка привязки: " + x + ", " + y + ", " + z);
    }

    /** Угол 1 региона (противоположный угол захвата). */
    private void setCornerA() {
        if (this.client == null || this.client.player == null) return;
        BlockPos p = this.client.player.getBlockPos();
        HungerGuardConfig c = HungerGuardConfig.get();
        c.builderCornerASet = true;
        c.builderCornerAX = p.getX();
        c.builderCornerAY = p.getY();
        c.builderCornerAZ = p.getZ();
        HungerGuardConfig.save();
        notify("§aУгол 1: " + p.getX() + ", " + p.getY() + ", " + p.getZ());
    }

    /** Угол 2 региона (противоположный угол захвата). */
    private void setCornerB() {
        if (this.client == null || this.client.player == null) return;
        BlockPos p = this.client.player.getBlockPos();
        HungerGuardConfig c = HungerGuardConfig.get();
        c.builderCornerBSet = true;
        c.builderCornerBX = p.getX();
        c.builderCornerBY = p.getY();
        c.builderCornerBZ = p.getZ();
        HungerGuardConfig.save();
        notify("§aУгол 2: " + p.getX() + ", " + p.getY() + ", " + p.getZ());
    }

    /** Захват региона между углами 1 и 2 → новый шаблон (копия постройки из мира). */
    private void captureRegion() {
        MinecraftClient mc = this.client;
        if (mc == null || mc.world == null) return;
        HungerGuardConfig c = HungerGuardConfig.get();
        if (!c.builderCornerASet || !c.builderCornerBSet) {
            notify("§cСначала встань в два противоположных угла и нажми «Угол 1/2 = здесь»");
            return;
        }
        int x1 = Math.min(c.builderCornerAX, c.builderCornerBX);
        int y1 = Math.min(c.builderCornerAY, c.builderCornerBY);
        int z1 = Math.min(c.builderCornerAZ, c.builderCornerBZ);
        int x2 = Math.max(c.builderCornerAX, c.builderCornerBX);
        int y2 = Math.max(c.builderCornerAY, c.builderCornerBY);
        int z2 = Math.max(c.builderCornerAZ, c.builderCornerBZ);
        int dx = x2 - x1 + 1, dy = y2 - y1 + 1, dz = z2 - z1 + 1;
        long vol = (long) dx * dy * dz;
        if (vol > 1000000) {
            notify("§cРегион слишком большой: " + dx + "×" + dy + "×" + dz);
            return;
        }

        String name = nameField.getText().trim();
        if (name.isEmpty()) name = "region_" + (System.currentTimeMillis() % 100000);
        BuilderTemplate t = BuilderTemplate.createEmpty(name, dx, dy, dz);
        int count = 0;
        for (int x = x1; x <= x2; x++) {
            for (int y = y1; y <= y2; y++) {
                for (int z = z1; z <= z2; z++) {
                    BlockState st = mc.world.getBlockState(new BlockPos(x, y, z));
                    if (st.isAir()) continue;
                    String id = Registries.BLOCK.getId(st.getBlock()).toString();
                    t.setBlock(x - x1, y - y1, z - z1, id);
                    count++;
                }
            }
        }
        if (count == 0) {
            notify("§cРегион пустой");
            return;
        }
        if (count > 200000) {
            notify("§cСлишком много блоков: " + count);
            return;
        }
        if (TemplateStore.save(t)) {
            HungerGuardConfig.get().builderTemplate = name;
            HungerGuardConfig.save();
            this.init();
            notify("§a[Строитель] Постройка сохранена: «" + name + "» — " + count + " блоков, " + dx + "×" + dy + "×" + dz);
        } else {
            notify("§c[Строитель] Ошибка сохранения региона");
        }
    }

    private int listTop() { return winY + LIST_TOP_OFF; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        GuiUtil.fillRoundRect(context, winX, winY, winW, winH, 12, GuiUtil.COLOR_WINDOW_BG);
        if (BuilderBot.UNDER_MAINTENANCE) {
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§b§lСтроитель"),
                    winX + winW / 2, winY + 8, 0xFFFFFF);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§c⛔ На долгих технических работах"),
                    winX + winW / 2, winY + 40, 0xFF5555);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§7Поле шаблона не регает — чиним"),
                    winX + winW / 2, winY + 58, 0xAAAAAA);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§7Фермер работает в штатном режиме"),
                    winX + winW / 2, winY + 74, 0x55FF55);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§8Строитель вернётся после починки"),
                    winX + winW / 2, winY + 92, 0x808080);
            super.render(context, mouseX, mouseY, delta);
            return;
        }
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§b§lСтроитель"),
                winX + winW / 2, winY + 8, 0xFFFFFF);

        int gap = 10;
        int colW = (winW - 14*2 - gap) / 2;
        int lx = winX + 14;

        // Список шаблонов — ширина адаптивная (colW вместо 200)
        int y = listTop();
        for (String name : templates) {
            if (y > listTop() + (LIST_MAX - 1) * ROW_H) break;
            boolean sel = name.equals(selected);
            boolean hovered = mouseX >= lx && mouseX <= lx + colW && mouseY >= y && mouseY < y + ROW_H;
            if (hovered || sel) {
                context.fill(lx, y, lx + colW, y + ROW_H - 1, sel ? GuiUtil.COLOR_ROW_HOVER : 0xFF1B2733);
            }
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal((sel ? "§a► §f" : "§7  ") + name),
                    lx + 6, y + 4, sel ? 0xFFFFFF : 0xFFB9C0C8);
            y += ROW_H;
        }
        if (templates.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, Text.literal("§8(пусто — создай новый или запиши регион)"),
                    lx + 6, y, GuiUtil.COLOR_TEXT_MUTED);
        }

        context.drawTextWithShadow(this.textRenderer, Text.literal("§7Настройки бота:"),
                lx, winY + 178, GuiUtil.COLOR_TEXT_MUTED);

        // Правая колонка — адаптивная
        int rx = winX + 14 + colW + gap;
        HungerGuardConfig c = HungerGuardConfig.get();

        context.drawTextWithShadow(this.textRenderer, Text.literal("§7Точка привязки:"),
                rx, winY + 16, GuiUtil.COLOR_TEXT_MUTED);

        String anchorText = c.builderAnchorSet
                ? c.builderAnchorX + ", " + c.builderAnchorY + ", " + c.builderAnchorZ
                : "не задана";
        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§fКоординаты: " + anchorText),
                rx, winY + 132, 0xFFFFFF);

        // Статус бота
        String status = switch (BuilderBot.INSTANCE.getState()) {
            case RUNNING -> "§a● Строит: " + BuilderBot.INSTANCE.getPlaced() + "/" + BuilderBot.INSTANCE.getTotal();
            case DONE -> "§b✔ Готово: " + BuilderBot.INSTANCE.getPlaced();
            case ERROR -> "§c✖ " + BuilderBot.INSTANCE.getError();
            default -> "§7○ Остановлен";
        };
        context.drawTextWithShadow(this.textRenderer, Text.literal(status),
                rx, winY + 180, 0xFFFFFF);

        // Инфо о выбранном шаблоне
        String info = "Шаблон: " + (selected.isEmpty() ? "—" : selected);
        if (!selected.isEmpty()) {
            BuilderTemplate t = TemplateStore.load(selected);
            if (t != null) info += "  ·  " + t.dx + "×" + t.dy + "×" + t.dz + "  ·  блоков: " + t.blockCount();
        }
        context.drawTextWithShadow(this.textRenderer, Text.literal("§8" + info),
                rx, winY + 200, GuiUtil.COLOR_TEXT_MUTED);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (BuilderBot.UNDER_MAINTENANCE) return super.mouseClicked(mouseX, mouseY, button);
        if (button == 0) {
            int gap = 10;
            int colW = (winW - 14*2 - gap) / 2;
            int lx = winX + 14;
            int y = listTop();
            for (String name : templates) {
                if (y > listTop() + (LIST_MAX - 1) * ROW_H) break;
                if (mouseX >= lx && mouseX <= lx + colW && mouseY >= y && mouseY < y + ROW_H) {
                    selected = name;
                    HungerGuardConfig.get().builderTemplate = name;
                    HungerGuardConfig.save();
                    return true;
                }
                y += ROW_H;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void notify(String msg) {
        if (this.client != null && this.client.player != null) {
            this.client.player.sendMessage(Text.literal(msg), false);
        }
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
