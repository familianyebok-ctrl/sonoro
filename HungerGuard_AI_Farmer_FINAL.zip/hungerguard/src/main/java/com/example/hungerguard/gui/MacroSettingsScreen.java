package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class MacroSettingsScreen extends Screen {

    private static final int CONTENT_TOP_OFF = 50;
    private static final int CONTENT_BOTTOM_OFF = 40;

    private final Screen parent;

    private int panelX, panelY, panelW, panelH;
    private int scrollOffset = 0;
    private int maxScroll = 0;

    private final List<ClickableWidget> contentWidgets = new ArrayList<>();
    private final List<ClickableWidget> fixedWidgets = new ArrayList<>();

    public MacroSettingsScreen(Screen parent) {
        super(Text.literal("Macro Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.clearChildren();
        contentWidgets.clear();
        fixedWidgets.clear();

        // Компактное окно по центру (со скроллом внутри), а не на весь экран
        panelW = Math.min(420, this.width - 8);
        panelH = Math.min(400, this.height - 8);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        int contentTop = panelY + CONTENT_TOP_OFF;
        int contentBottom = panelY + panelH - CONTENT_BOTTOM_OFF;

        int y = contentTop - scrollOffset;
        int x = panelX + 16;
        int w = panelW - 32;

        // 📦 Предметы для макроса — по центру
        int itemsBtnW = 260;
        int itemsBtnX = panelX + (panelW - itemsBtnW) / 2;
        addContent(ButtonWidget.builder(Text.literal("§e📦 Предметы для макроса..."), b ->
                        this.client.setScreen(new ItemPickerScreenForMacro(this)))
                .dimensions(itemsBtnX, y, itemsBtnW, 22).build());
        y += 30;

        // Профили — по центру
        int profBtnW = 140, profGap = 10;
        int profStartX = panelX + (panelW - (profBtnW * 2 + profGap)) / 2;
        addContent(ButtonWidget.builder(Text.literal("§b🎯 Точный"), b -> applyExactPreset())
                .dimensions(profStartX, y, profBtnW, 22).build());
        addContent(ButtonWidget.builder(Text.literal("§a🎮 Легит"), b -> applyLegitPreset())
                .dimensions(profStartX + profBtnW + profGap, y, profBtnW, 22).build());
        y += 34;

        // Слайдеры
        addContent(new LegitLevelSlider(x, y, w, 18)); y += 24;
        addContent(new SpeedSlider(x, y, w, 18)); y += 24;
        addContent(new SharpnessSlider(x, y, w, 18)); y += 24;
        addContent(new SmoothnessSlider(x, y, w, 18)); y += 30;

        // Тумблеры
        HungerGuardConfig c = HungerGuardConfig.get();
        y = addToggle(y, "Зациклить", "повтор", () -> c.macroLoop, v -> { c.macroLoop = v; save(); });
        y = addToggle(y, "Сетка GCD", "клики ровно", () -> c.macroGcdFix, v -> { c.macroGcdFix = v; save(); });
        y = addToggle(y, "Дрожь прицела", "естественно", () -> c.macroAimJitter, v -> { c.macroAimJitter = v; save(); });
        y = addToggle(y, "Перелёт", "промах мимо", () -> c.macroOvershoot, v -> { c.macroOvershoot = v; save(); });
        y = addToggle(y, "Случайные паузы", "между кликами", () -> c.macroTimingJitter, v -> { c.macroTimingJitter = v; save(); });
        y = addToggle(y, "Случайные клики", "пропуск/двойной", () -> c.macroClickRandom, v -> { c.macroClickRandom = v; save(); });
        y = addToggle(y, "Моргание", "прицела", () -> c.macroBlink, v -> { c.macroBlink = v; save(); });
        y = addToggle(y, "Человеческие ошибки", "неточность", () -> c.macroHumanError, v -> { c.macroHumanError = v; save(); });
        y = addToggle(y, "Дрожь движения", "ходьбы", () -> c.macroMoveJitter, v -> { c.macroMoveJitter = v; save(); });
        y = addToggle(y, "Восстановить инвентарь", "как было", () -> c.macroRestoreInventory, v -> { c.macroRestoreInventory = v; save(); });
        y = addToggle(y, "Авто-взятие", "из инвентаря", () -> c.macroAutoTakeFromInventory, v -> { c.macroAutoTakeFromInventory = v; save(); });
        y = addToggle(y, "Лог в чат", "сообщения", () -> c.macroLogToChat, v -> { c.macroLogToChat = v; save(); });

        // Высота контента и максимум скролла (не зависит от scrollOffset)
        int contentHeight = (y + scrollOffset) - contentTop;
        int visibleH = contentBottom - contentTop;
        maxScroll = Math.max(0, contentHeight - visibleH);
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;

        // Кнопки внизу — фиксированы
        int bottomY = panelY + panelH - 30;
        addFixed(ButtonWidget.builder(Text.literal("§7Сброс"), b -> {
            scrollOffset = 0;
            this.init();
        }).dimensions(panelX + 16, bottomY, 100, 22).build());
        addFixed(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                .dimensions(panelX + panelW - 116, bottomY, 100, 22).build());

        // Стрелки скролла — фиксированы
        int scrollBtnX = panelX + panelW - 30;
        addFixed(ButtonWidget.builder(Text.literal("▲"), b -> {
            scrollOffset = Math.max(0, scrollOffset - 40);
            this.init();
        }).dimensions(scrollBtnX, panelY + 52, 20, 20).build());
        addFixed(ButtonWidget.builder(Text.literal("▼"), b -> {
            scrollOffset = Math.min(maxScroll, scrollOffset + 40);
            this.init();
        }).dimensions(scrollBtnX, panelY + panelH - 80, 20, 20).build());
    }

    private void save() { HungerGuardConfig.save(); }

    private int addToggle(int y, String label, String hint, BooleanSupplier getter, Consumer<Boolean> setter) {
        addContent(new ToggleSwitch(panelX + 16, y, panelW - 32, label, hint, getter, setter));
        return y + 22;
    }

    private void addContent(ClickableWidget widget) {
        this.addDrawableChild(widget);
        contentWidgets.add(widget);
    }

    private void addFixed(ClickableWidget widget) {
        this.addDrawableChild(widget);
        fixedWidgets.add(widget);
    }

    private boolean inContentRange(ClickableWidget w) {
        int contentTop = panelY + CONTENT_TOP_OFF;
        int contentBottom = panelY + panelH - CONTENT_BOTTOM_OFF;
        return w.getY() + w.getHeight() > contentTop && w.getY() < contentBottom;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        GuiUtil.fillPanel(context, panelX, panelY, panelW, panelH, GuiUtil.COLOR_PANEL_BG);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§b§lMacro Settings"), panelX + panelW / 2, panelY + 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§7Точный или Легит режим"), panelX + panelW / 2, panelY + 24, GuiUtil.COLOR_TEXT_MUTED);

        // Контент — с обрезкой по скролл-области (не наезжает на заголовок и кнопки)
        int contentTop = panelY + CONTENT_TOP_OFF;
        int contentBottom = panelY + panelH - CONTENT_BOTTOM_OFF;
        context.enableScissor(panelX, contentTop, panelX + panelW, contentBottom);
        for (ClickableWidget w : contentWidgets) {
            if (inContentRange(w)) w.render(context, mouseX, mouseY, delta);
        }
        context.disableScissor();

        // Фиксированные виджеты — поверх
        for (ClickableWidget w : fixedWidgets) {
            w.render(context, mouseX, mouseY, delta);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Фиксированные кнопки имеют приоритет
        for (ClickableWidget w : fixedWidgets) {
            if (w.isMouseOver(mouseX, mouseY) && w.mouseClicked(mouseX, mouseY, button)) return true;
        }
        // Скроллируемый контент — только если виджет в видимой области
        for (ClickableWidget w : contentWidgets) {
            if (inContentRange(w) && w.isMouseOver(mouseX, mouseY) && w.mouseClicked(mouseX, mouseY, button)) return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (maxScroll <= 0) return false;
        if (verticalAmount < 0) {
            scrollOffset = Math.min(maxScroll, scrollOffset + 20);
        } else if (verticalAmount > 0) {
            scrollOffset = Math.max(0, scrollOffset - 20);
        }
        this.init();
        return true;
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    private void applyExactPreset() {
        HungerGuardConfig c = HungerGuardConfig.get();
        c.macroLegitLevel = 0;
        c.macroGcdFix = false; c.macroAimJitter = false; c.macroOvershoot = false;
        c.macroTimingJitter = false; c.macroClickRandom = false; c.macroBlink = false;
        c.macroHumanError = false; c.macroMoveJitter = false;
        c.macroPlaybackSpeed = 1.0f; c.macroSharpness = 1.0f;
        HungerGuardConfig.save();
        rebuild();
    }

    private void applyLegitPreset() {
        HungerGuardConfig c = HungerGuardConfig.get();
        c.macroLegitLevel = 2;
        c.macroGcdFix = false; c.macroAimJitter = false; c.macroOvershoot = false;
        c.macroTimingJitter = true; c.macroTimingJitterMax = 2;
        c.macroClickRandom = false; c.macroBlink = false;
        c.macroHumanError = false; c.macroMoveJitter = false;
        c.macroPlaybackSpeed = 1.0f; c.macroSharpness = 0.5f;
        HungerGuardConfig.save();
        rebuild();
    }

    private void rebuild() {
        this.clearChildren();
        this.init();
    }

    private static class LegitLevelSlider extends SliderWidget {
        LegitLevelSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), HungerGuardConfig.get().macroLegitLevel / 3.0);
            updateMessage();
        }
        @Override protected void updateMessage() {
            int lvl = (int) Math.round(this.value * 3);
            String n = switch (lvl) { case 0 -> "Точный"; case 1 -> "Мягкий"; case 2 -> "Легит"; case 3 -> "Параноик"; default -> "?"; };
            setMessage(Text.literal("Legit Level: " + lvl + " (" + n + ")"));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().macroLegitLevel = (int) Math.round(this.value * 3);
            HungerGuardConfig.save();
        }
    }

    private static class SpeedSlider extends SliderWidget {
        SpeedSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), (HungerGuardConfig.get().macroPlaybackSpeed - 0.5f) / 4.5f);
            updateMessage();
        }
        @Override protected void updateMessage() {
            setMessage(Text.literal(String.format("Скорость: %.2fx", 0.5f + (float) (this.value * 4.5f))));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().macroPlaybackSpeed = 0.5f + (float) (this.value * 4.5f);
            HungerGuardConfig.save();
        }
    }

    private static class SharpnessSlider extends SliderWidget {
        SharpnessSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), (HungerGuardConfig.get().macroSharpness - 0.05f) / 0.95f);
            updateMessage();
        }
        @Override protected void updateMessage() {
            float sh = 0.05f + (float) (this.value * 0.95f);
            String l = sh < 0.3f ? "Очень плавно" : (sh < 0.6f ? "Плавно" : (sh < 0.85f ? "Норм" : "Мгновенно"));
            setMessage(Text.literal(String.format("Резкость: %.2f (%s)", sh, l)));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().macroSharpness = 0.05f + (float) (this.value * 0.95f);
            HungerGuardConfig.save();
        }
    }

    private static class SmoothnessSlider extends SliderWidget {
        SmoothnessSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), HungerGuardConfig.get().macroSmoothness);
            updateMessage();
        }
        @Override protected void updateMessage() {
            float s = (float) this.value;
            String l = s < 0.01f ? "Выкл" : (s < 0.4f ? "Лёгкая" : (s < 0.7f ? "Средняя" : "Макс"));
            setMessage(Text.literal(String.format("Плавность: %.2f (%s)", s, l)));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().macroSmoothness = (float) this.value;
            HungerGuardConfig.save();
        }
    }
}
