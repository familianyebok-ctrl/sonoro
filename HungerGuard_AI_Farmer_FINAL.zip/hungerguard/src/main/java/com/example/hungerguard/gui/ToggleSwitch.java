package com.example.hungerguard.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Тумблер с подписью СЛЕВА и переключателем СПРАВА.
 * Занимает всю ширину строки — подпись всегда прижата к левому краю,
 * а «пилюля» — к правому, поэтому ничего не разъезжается при скролле.
 */
public class ToggleSwitch extends ClickableWidget {

    private static final int COLOR_OFF = 0xFF55565C;
    private static final int TRACK_W = 34;
    private static final int TRACK_H = 16;

    private final BooleanSupplier getter;
    private final Consumer<Boolean> setter;
    private final String label;
    private final String hint;
    private float progress;

    public ToggleSwitch(int x, int y, int width, String label, BooleanSupplier getter, Consumer<Boolean> setter) {
        this(x, y, width, label, null, getter, setter);
    }

    public ToggleSwitch(int x, int y, int width, String label, String hint, BooleanSupplier getter, Consumer<Boolean> setter) {
        super(x, y, width, TRACK_H + 4, Text.literal(label == null ? "" : label));
        this.label = label;
        this.hint = hint;
        this.getter = getter;
        this.setter = setter;
        this.progress = getter.getAsBoolean() ? 1f : 0f;
    }

    @Override
    public void onClick(double mouseX, double mouseY) {
        setter.accept(!getter.getAsBoolean());
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        float target = getter.getAsBoolean() ? 1f : 0f;
        progress += (target - progress) * 0.35f;
        if (Math.abs(target - progress) < 0.01f) progress = target;

        boolean on = progress > 0.5f;
        var font = MinecraftClient.getInstance().textRenderer;
        int textY = getY() + (height - font.fontHeight) / 2 + 1;

        // Подпись слева — всегда белая, с цветной точкой-индикатором состояния
        if (label != null) {
            String dot = on ? "§a● " : "§8○ ";
            Text labelText = Text.literal(dot + "§f" + label);
            context.drawTextWithShadow(font, labelText, getX(), textY, 0xFFFFFF);
        }

        // Подсказка рядом с подписью
        if (hint != null) {
            int lw = label == null ? 0 : font.getWidth(Text.literal((on ? "§a● " : "§8○ ") + label));
            context.drawTextWithShadow(font, Text.literal("§8" + hint), getX() + lw + 6, textY, 0x808080);
        }

        // Переключатель справа
        int trackX = getX() + width - TRACK_W;
        int trackY = getY() + (height - TRACK_H) / 2;
        GuiUtil.fillPill(context, trackX, trackY, TRACK_W, TRACK_H, GuiUtil.lerpColor(COLOR_OFF, GuiUtil.accent(), progress));

        int radius = TRACK_H / 2 - 2;
        int knobX = (int) (trackX + radius + 2 + (TRACK_W - TRACK_H) * progress);
        int knobY = trackY + TRACK_H / 2;
        GuiUtil.fillCircle(context, knobX, knobY, radius, 0xFFFFFFFF);
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        this.appendDefaultNarrations(builder);
    }
}
