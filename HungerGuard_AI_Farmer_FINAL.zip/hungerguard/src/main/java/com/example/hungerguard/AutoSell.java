package com.example.hungerguard;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Random;

public class AutoSell {

    public static final AutoSell INSTANCE = new AutoSell();

    private boolean running = false;
    private int soldCount = 0;
    private long lastActionTime = 0L;
    private final Random random = new Random();
    private boolean inventorySearchMode = false;
    private long inventorySearchStart = 0L;

    private AutoSell() {}

    public boolean isRunning() { return running; }
    public int getSoldCount() { return soldCount; }

    public void start() {
        if (running) return;
        running = true;
        soldCount = 0;
        inventorySearchMode = false;
        lastActionTime = System.currentTimeMillis();
        notifyClient("§a[AutoSell] Запущен");
    }

    public void stop() {
        running = false;
        inventorySearchMode = false;
        notifyClient("§c[AutoSell] Остановлен (продано: " + soldCount + ")");
    }

    public void onTick(MinecraftClient client) {
        if (!running) return;
        if (client.player == null || client.getNetworkHandler() == null) return;

        List<Item> targets = HungerGuardConfig.getAutoSellItems();
        if (targets.isEmpty()) {
            stop();
            notifyClient("§c[AutoSell] Список предметов пуст — выбери в настройках");
            return;
        }

        long now = System.currentTimeMillis();
        int delayMs = HungerGuardConfig.get().autoSellDelayMs;

        // ±15% рандомизация задержки
        int jitter = Math.max(1, (int) (delayMs * 0.15));
        int actualDelay = delayMs + random.nextInt(jitter * 2 + 1) - jitter;

        if (now - lastActionTime < actualDelay) return;
        lastActionTime = now;

        PlayerInventory inv = client.player.getInventory();

        // Ищем предмет в хотбаре (слоты 0-8)
        int foundSlot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty() && targets.contains(stack.getItem())) {
                foundSlot = i;
                break;
            }
        }

        if (foundSlot == -1) {
            if (!inventorySearchMode) {
                inventorySearchMode = true;
                inventorySearchStart = now;
                notifyClient("§e[AutoSell] Ищу предметы в инвентаре...");
            }

            // Таймаут: предметов нет — закрываем инвентарь и выходим
            if (now - inventorySearchStart > 3000) {
                inventorySearchMode = false;
                closeInventory(client);
                notifyClient("§c[AutoSell] Предметы не найдены в инвентаре");
                return;
            }

            // Открываем инвентарь
            if (client.currentScreen == null) {
                client.setScreen(new InventoryScreen(client.player));
                return;
            }

            // Ищем в слотах 9-35 (основной инвентарь)
            int invSlot = -1;
            for (int i = 9; i < 36; i++) {
                ItemStack stack = inv.getStack(i);
                if (!stack.isEmpty() && targets.contains(stack.getItem())) {
                    invSlot = i;
                    break;
                }
            }

            if (invSlot != -1) {
                int emptyHotbar = -1;
                for (int i = 0; i < 9; i++) {
                    if (inv.getStack(i).isEmpty()) {
                        emptyHotbar = i;
                        break;
                    }
                }
                if (emptyHotbar == -1) {
                    inventorySearchMode = false;
                    closeInventory(client);
                    notifyClient("§c[AutoSell] Хотбар полон — некуда класть предметы");
                    return;
                }
                try {
                    // QUICK_MOVE переносит предмет в первый свободный слот хотбара
                    client.interactionManager.clickSlot(
                            client.player.playerScreenHandler.syncId,
                            invSlot, 0, SlotActionType.QUICK_MOVE, client.player);
                } catch (Exception ignored) {}
            }
            return;
        }

        // Предмет найден в хотбаре
        inventorySearchMode = false;
        closeInventory(client);

        // Микродвижение мыши
        float yawJitter = (random.nextFloat() - 0.5f) * 1.0f;
        float pitchJitter = (random.nextFloat() - 0.5f) * 0.5f;
        client.player.setYaw(client.player.getYaw() + yawJitter);
        client.player.setPitch(Math.max(-90f, Math.min(90f, client.player.getPitch() + pitchJitter)));

        // Берём предмет в руку
        inv.setSelectedSlot(foundSlot);

        // Отправляем команду (не записывая её в макрос)
        String command = HungerGuardConfig.get().autoSellCommand;
        if (command == null || command.isBlank()) {
            stop();
            notifyClient("§c[AutoSell] Команда не задана");
            return;
        }

        final String cmd = command;
        MacroRecorder.INSTANCE.runWithoutRecording(() -> {
            if (cmd.startsWith("/")) {
                client.getNetworkHandler().sendChatCommand(cmd.substring(1));
            } else {
                client.getNetworkHandler().sendChatMessage(cmd);
            }
        });

        soldCount++;
    }

    private void closeInventory(MinecraftClient client) {
        if (client.currentScreen instanceof InventoryScreen) {
            client.setScreen(null);
        }
    }

    private void notifyClient(String message) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(Text.literal(message), false);
        }
    }
}
