package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Выбор культур, которые AI-фермер имеет право искать и собирать. */
public class FarmerCropScreen extends Screen {
    private final Screen parent;
    private final List<Entry> entries = new ArrayList<>();
    private int x, y, w, h;

    private record Entry(String id, String name, Block block) {}

    public FarmerCropScreen(Screen parent) {
        super(Text.literal("Культуры фермы"));
        this.parent = parent;
        add("minecraft:wheat", "Пшеница", Blocks.WHEAT);
        add("minecraft:carrots", "Морковь", Blocks.CARROTS);
        add("minecraft:potatoes", "Картофель", Blocks.POTATOES);
        add("minecraft:beetroots", "Свёкла", Blocks.BEETROOTS);
        add("minecraft:nether_wart", "Нарост", Blocks.NETHER_WART);
        add("minecraft:pumpkin", "Тыква", Blocks.PUMPKIN);
        add("minecraft:melon", "Арбуз", Blocks.MELON);
        add("minecraft:sugar_cane", "Тростник", Blocks.SUGAR_CANE);
        add("minecraft:cactus", "Кактус", Blocks.CACTUS);
        add("minecraft:bamboo", "Бамбук", Blocks.BAMBOO);
        add("minecraft:kelp", "Ламинария", Blocks.KELP);
    }

    private void add(String id, String name, Block block) { entries.add(new Entry(id, name, block)); }

    @Override protected void init() {
        w = Math.min(420, width - 12);
        h = Math.min(330, height - 12);
        x = (width - w) / 2;
        y = (height - h) / 2;
        clearChildren();

        int rowY = y + 44;
        int bw = (w - 44) / 2;
        for (int i = 0; i < entries.size(); i++) {
            int col = i % 2, row = i / 2;
            Entry e = entries.get(i);
            addDrawableChild(ButtonWidget.builder(Text.literal(label(e)),
                    b -> toggle(e.id)).dimensions(x + 16 + col * (bw + 8), rowY + row * 30, bw, 24).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("§7Все / по умолчанию"),
                b -> { HungerGuardConfig.get().farmerCropIds.clear(); HungerGuardConfig.save(); init(); })
                .dimensions(x + 16, y + h - 28, w - 132, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"),
                b -> close()).dimensions(x + w - 108, y + h - 28, 92, 20).build());
    }

    private String label(Entry e) {
        List<String> ids = HungerGuardConfig.get().farmerCropIds;
        boolean on = ids == null || ids.isEmpty() || ids.contains(e.id);
        return (on ? "§a✓ " : "§7○ ") + e.name;
    }

    private void toggle(String id) {
        HungerGuardConfig c = HungerGuardConfig.get();
        if (c.farmerCropIds == null) c.farmerCropIds = new ArrayList<>();
        if (c.farmerCropIds.isEmpty()) {
            c.farmerCropIds = new ArrayList<>();
            for (Entry e : entries) if (!e.id.equals(id)) c.farmerCropIds.add(e.id);
        } else if (c.farmerCropIds.contains(id)) {
            c.farmerCropIds.remove(id);
        } else {
            c.farmerCropIds.add(id);
        }
        HungerGuardConfig.save();
        init();
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        GuiUtil.fillRoundRect(ctx, x, y, w, h, 12, GuiUtil.COLOR_WINDOW_BG);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§a§l🌾 Какие культуры собирать"),
                x + w / 2, y + 10, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§8Пустой список = все поддерживаемые культуры"),
                x + w / 2, y + 27, GuiUtil.COLOR_TEXT_MUTED);
        super.render(ctx, mx, my, delta);
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
