package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Настройки Hunger Guard: список действий при голоде (чат-сообщения/команды),
 * которые отправляются по одному с настраиваемой паузой.
 * Клик по строке удаляет её; поле ввода + кнопка добавляют новую.
 * Компактное адаптивное окно по центру (не на весь экран).
 */
public class HungerGuardSettingsScreen extends Screen {

    private static final int MAX_W = 400;
    private static final int MAX_H = 330;
    private static final int ROW_HEIGHT = 18;
    private static final int MAX_VISIBLE = 8;

    private final Screen parent;
    private final List<String> actions = new ArrayList<>();

    private int panelX, panelY, panelW, panelH;
    private int scrollOffset = 0;
    private TextFieldWidget inputField;

    public HungerGuardSettingsScreen(Screen parent) {
        super(Text.literal("Hunger Guard"));
        this.parent = parent;
        if (HungerGuardConfig.get().actionLines != null) {
            actions.addAll(HungerGuardConfig.get().actionLines);
        }
    }

    @Override
    protected void init() {
        panelW = Math.min(MAX_W, this.width - 8);
        panelH = Math.min(MAX_H, this.height - 8);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        this.clearChildren();
        int w = panelW - 32;

        // Поле ввода новой строки
        inputField = new TextFieldWidget(this.textRenderer, panelX + 16, panelY + 34, w - 68, 16,
                Text.literal("/home"));
        inputField.setMaxLength(128);
        this.addDrawableChild(inputField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("+ Добавить"), b -> addAction())
                .dimensions(panelX + 16 + (w - 64), panelY + 34, 64, 16).build());

        // Порог голода + пауза между строками
        this.addDrawableChild(new ThresholdSlider(panelX + 16, panelY + panelH - 64, w, 16));
        this.addDrawableChild(new DelaySlider(panelX + 16, panelY + panelH - 44, w, 16));

        this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                .dimensions(panelX + 16, panelY + panelH - 22, 100, 16).build());
    }

    private void addAction() {
        String s = inputField.getText() == null ? "" : inputField.getText().trim();
        if (s.isEmpty()) return;
        actions.add(s);
        save();
        inputField.setText("");
    }

    private void save() {
        HungerGuardConfig.get().actionLines = new ArrayList<>(actions);
        HungerGuardConfig.save();
    }

    private int listTop() { return panelY + 56; }
    private int listBottom() { return panelY + panelH - 76; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        GuiUtil.fillRoundRect(context, panelX, panelY, panelW, panelH, 12, GuiUtil.COLOR_WINDOW_BG);

        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§c§lHunger Guard"),
                panelX + panelW / 2, panelY + 8, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§7Действия при голоде (клик по строке — удалить):"),
                panelX + 16, panelY + 24, GuiUtil.COLOR_TEXT_MUTED);

        int lTop = listTop();
        int lBottom = listBottom();
        GuiUtil.fillRoundRect(context, panelX + 12, lTop - 2, panelX + panelW - 12, lBottom + 2, 6, GuiUtil.COLOR_BLOCK_BG);

        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= actions.size()) break;
            String a = actions.get(idx);
            int rowY = lTop + i * ROW_HEIGHT;
            if (rowY + ROW_HEIGHT > lBottom) break;

            boolean hovered = mouseX >= panelX + 16 && mouseX <= panelX + panelW - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;
            if (hovered) {
                context.fill(panelX + 16, rowY, panelX + panelW - 16, rowY + ROW_HEIGHT - 1, GuiUtil.COLOR_ROW_HOVER);
            }
            String label = a.startsWith("/") ? "§b" : "§f";
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal(String.format("%s%d. %s%s", "§8", idx + 1, label, a)),
                    panelX + 22, rowY + 5, 0xFFFFFF);
        }

        if (actions.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("§7Пусто — добавь команду (например /home)"),
                    panelX + panelW / 2, lTop + 30, GuiUtil.COLOR_TEXT_MUTED);
        }

        // Индикатор скролла
        if (actions.size() > MAX_VISIBLE) {
            int trackX = panelX + panelW - 8;
            int trackH = MAX_VISIBLE * ROW_HEIGHT;
            context.fill(trackX, lTop, trackX + 3, lTop + trackH, 0xFF2A3038);
            float ratio = (float) scrollOffset / Math.max(1, actions.size() - MAX_VISIBLE);
            int thumbH = Math.max(10, trackH * MAX_VISIBLE / actions.size());
            int thumbY = lTop + (int) ((trackH - thumbH) * ratio);
            context.fill(trackX, thumbY, trackX + 3, thumbY + thumbH, GuiUtil.accent());
        }

        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§8Начинай с «/» для команды. Строки идут по очереди с паузой."),
                panelX + 16, panelY + panelH - 80, GuiUtil.COLOR_TEXT_MUTED);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int lTop = listTop();
        int lBottom = listBottom();
        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= actions.size()) break;
            int rowY = lTop + i * ROW_HEIGHT;
            if (rowY + ROW_HEIGHT > lBottom) break;
            if (mouseX >= panelX + 16 && mouseX <= panelX + panelW - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                actions.remove(idx);
                save();
                if (scrollOffset > 0 && scrollOffset >= actions.size()) scrollOffset--;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            scrollOffset = Math.min(scrollOffset + 1, Math.max(0, actions.size() - MAX_VISIBLE));
        } else if (verticalAmount > 0) {
            scrollOffset = Math.max(scrollOffset - 1, 0);
        }
        return true;
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static class ThresholdSlider extends SliderWidget {
        ThresholdSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), HungerGuardConfig.get().foodThreshold / 20.0);
            updateMessage();
        }
        @Override protected void updateMessage() {
            int v = (int) Math.round(this.value * 20);
            setMessage(Text.literal("Порог голода: " + v + "/20"));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().foodThreshold = (int) Math.round(this.value * 20);
            HungerGuardConfig.save();
        }
    }

    private static class DelaySlider extends SliderWidget {
        DelaySlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), HungerGuardConfig.get().hungerActionDelayTicks / 100.0);
            updateMessage();
        }
        @Override protected void updateMessage() {
            int t = (int) Math.round(this.value * 100);
            setMessage(Text.literal(String.format("Пауза между строками: %.1f сек", t * 0.05)));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().hungerActionDelayTicks = (int) Math.round(this.value * 100);
            HungerGuardConfig.save();
        }
    }
}
