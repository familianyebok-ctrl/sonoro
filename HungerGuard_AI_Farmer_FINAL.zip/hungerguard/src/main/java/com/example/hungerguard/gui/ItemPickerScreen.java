package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class ItemPickerScreen extends Screen {

    private static final int PANEL_WIDTH = 360;
    private static final int PANEL_HEIGHT = 280;
    private static final int ROW_HEIGHT = 18;
    private static final int MAX_VISIBLE = 8;

    private final Screen parent;
    private final List<Item> filtered = new ArrayList<>();
    private final List<Item> selected = new ArrayList<>();

    private int panelX, panelY;
    private int scrollOffset = 0;
    private String searchQuery = "";
    private TextFieldWidget searchField;

    public ItemPickerScreen(Screen parent) {
        super(Text.literal("Item Picker"));
        this.parent = parent;

        for (String id : HungerGuardConfig.get().autoSellItemIds) {
            try {
                Item item = Registries.ITEM.get(Identifier.of(id));
                if (item != null && item != Items.AIR) {
                    this.selected.add(item);
                }
            } catch (Exception ignored) {}
        }

        this.filtered.addAll(GuiUtil.allItems());
    }

    @Override
    protected void init() {
        panelX = (this.width - PANEL_WIDTH) / 2;
        panelY = (this.height - PANEL_HEIGHT) / 2;

        searchField = new TextFieldWidget(this.textRenderer, panelX + 16, panelY + 34,
                PANEL_WIDTH - 32, 18, Text.literal("Поиск..."));
        searchField.setMaxLength(64);
        searchField.setChangedListener(s -> {
            searchQuery = s.toLowerCase();
            applyFilter();
            scrollOffset = 0;
        });
        this.addDrawableChild(searchField);

        int y = panelY + PANEL_HEIGHT - 30;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                .dimensions(panelX + 16, y, 100, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> {
            List<String> ids = new ArrayList<>();
            for (Item item : selected) {
                ids.add(Registries.ITEM.getId(item).toString());
            }
            HungerGuardConfig.get().autoSellItemIds = ids;
            HungerGuardConfig.save();
            close();
        }).dimensions(panelX + PANEL_WIDTH - 116, y, 100, 20).build());
    }

    private void applyFilter() {
        filtered.clear();
        if (searchQuery.isEmpty()) {
            filtered.addAll(GuiUtil.allItems());
            return;
        }
        for (Item item : GuiUtil.allItems()) {
            String name = GuiUtil.itemName(item).toLowerCase();
            String id = Registries.ITEM.getId(item).toString().toLowerCase();
            if (name.contains(searchQuery) || id.contains(searchQuery)) {
                filtered.add(item);
            }
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        GuiUtil.fillPanel(context, panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT, GuiUtil.COLOR_PANEL_BG);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§b§lВыбор предметов"),
                panelX + PANEL_WIDTH / 2, panelY + 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§7Выбрано: " + selected.size()),
                panelX + PANEL_WIDTH / 2, panelY + 20, GuiUtil.COLOR_TEXT_MUTED);

        int listTop = panelY + 58;

        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= filtered.size()) break;

            Item item = filtered.get(idx);
            int rowY = listTop + i * ROW_HEIGHT;
            boolean hovered = mouseX >= panelX + 16 && mouseX <= panelX + PANEL_WIDTH - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;

            int rowColor = hovered ? GuiUtil.COLOR_ROW_HOVER : GuiUtil.COLOR_ROW_BG;
            context.fill(panelX + 16, rowY, panelX + PANEL_WIDTH - 16, rowY + ROW_HEIGHT - 1, rowColor);

            String name = GuiUtil.itemName(item);

            boolean isSelected = selected.contains(item);
            String prefix = isSelected ? "§a[+] " : "§7[ ] ";

            context.drawTextWithShadow(this.textRenderer,
                    Text.literal(prefix + "§f" + name),
                    panelX + 22, rowY + 5, 0xFFFFFF);

            try {
                ItemStack stack = new ItemStack(item);
                context.drawItem(stack, panelX + PANEL_WIDTH - 30, rowY + 1);
            } catch (Exception ignored) {}
        }

        if (filtered.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("§7Ничего не найдено"),
                    panelX + PANEL_WIDTH / 2, listTop + 30, GuiUtil.COLOR_TEXT_MUTED);
        }

        if (filtered.size() > MAX_VISIBLE) {
            int trackX = panelX + PANEL_WIDTH - 8;
            int trackY = listTop;
            int trackH = MAX_VISIBLE * ROW_HEIGHT;
            context.fill(trackX, trackY, trackX + 3, trackY + trackH, 0xFF2A3038);

            float ratio = (float) scrollOffset / Math.max(1, filtered.size() - MAX_VISIBLE);
            int thumbH = Math.max(10, trackH * MAX_VISIBLE / filtered.size());
            int thumbY = trackY + (int) ((trackH - thumbH) * ratio);
            context.fill(trackX, thumbY, trackX + 3, thumbY + thumbH, GuiUtil.accent());
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int listTop = panelY + 58;
        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= filtered.size()) break;

            int rowY = listTop + i * ROW_HEIGHT;
            if (mouseX >= panelX + 16 && mouseX <= panelX + PANEL_WIDTH - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                Item item = filtered.get(idx);
                if (selected.contains(item)) {
                    selected.remove(item);
                } else {
                    selected.add(item);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            scrollOffset = Math.min(scrollOffset + 1, Math.max(0, filtered.size() - MAX_VISIBLE));
        } else if (verticalAmount > 0) {
            scrollOffset = Math.max(scrollOffset - 1, 0);
        }
        return true;
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
