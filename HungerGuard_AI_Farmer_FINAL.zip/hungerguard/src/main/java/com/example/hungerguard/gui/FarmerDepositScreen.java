package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Выбор предметов, которые фермер складывает в сундук.
 * Сетка ячеек (до 12) + поиск по всем предметам Minecraft.
 * Компактное адаптивное окно по центру (не на весь экран).
 */
public class FarmerDepositScreen extends Screen {

    private static final int MAX_W = 400;
    private static final int MAX_H = 340;
    private static final int MAX_SELECTED = 12;
    private static final int SLOT_SIZE = 30;
    private static final int SLOT_GAP = 5;
    private static final int ROW_HEIGHT = 18;
    private static final int MAX_VISIBLE = 8;

    private final Screen parent;
    private final List<Item> selected = new ArrayList<>();
    private final List<Item> filtered = new ArrayList<>();

    private int panelX, panelY, panelW, panelH;
    private int scrollOffset = 0;
    private String searchQuery = "";
    private TextFieldWidget searchField;

    public FarmerDepositScreen(Screen parent) {
        super(Text.literal("Предметы в сундук"));
        this.parent = parent;
        for (String id : HungerGuardConfig.get().farmerDepositItemIds) {
            try {
                Item item = Registries.ITEM.get(Identifier.of(id));
                if (item != null && item != Items.AIR && selected.size() < MAX_SELECTED) {
                    selected.add(item);
                }
            } catch (Exception ignored) {}
        }
        filtered.addAll(GuiUtil.allItems());
    }

    @Override
    protected void init() {
        panelW = Math.min(MAX_W, this.width - 8);
        panelH = Math.min(MAX_H, this.height - 8);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        this.clearChildren();
        int w = panelW - 32;

        searchField = new TextFieldWidget(this.textRenderer, panelX + 16, panelY + 122, w - 74, 16,
                Text.literal("Поиск предмета..."));
        searchField.setMaxLength(64);
        searchField.setChangedListener(s -> {
            searchQuery = s.toLowerCase();
            applyFilter();
            scrollOffset = 0;
        });
        this.addDrawableChild(searchField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Сброс"), b -> clearSelection())
                .dimensions(panelX + 16 + w - 68, panelY + 122, 68, 16).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                .dimensions(panelX + 16, panelY + panelH - 24, 100, 16).build());
    }

    private void clearSelection() {
        selected.clear();
        saveSelection();
    }

    private void saveSelection() {
        List<String> ids = new ArrayList<>();
        for (Item item : selected) ids.add(Registries.ITEM.getId(item).toString());
        HungerGuardConfig.get().farmerDepositItemIds = ids;
        HungerGuardConfig.save();
    }

    private void applyFilter() {
        filtered.clear();
        if (searchQuery.isEmpty()) {
            filtered.addAll(GuiUtil.allItems());
            return;
        }
        for (Item item : GuiUtil.allItems()) {
            String name = GuiUtil.itemName(item).toLowerCase();
            String id = Registries.ITEM.getId(item).toString().toLowerCase();
            if (name.contains(searchQuery) || id.contains(searchQuery)) {
                filtered.add(item);
            }
        }
    }

    private int slotY(int row) { return panelY + 44 + row * (SLOT_SIZE + SLOT_GAP); }
    private int listTop() { return panelY + 146; }
    private int listBottom() { return panelY + panelH - 38; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        GuiUtil.fillRoundRect(context, panelX, panelY, panelW, panelH, 12, GuiUtil.COLOR_WINDOW_BG);

        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§a§l📦 Предметы в сундук"),
                panelX + panelW / 2, panelY + 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§8Только эти предметы фермер будет складывать"),
                panelX + panelW / 2, panelY + 22, GuiUtil.COLOR_TEXT_MUTED);

        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§7Выбрано (" + selected.size() + "/" + MAX_SELECTED + "):"),
                panelX + 16, panelY + 32, GuiUtil.COLOR_TEXT_MUTED);

        // Сетка ячеек 2 ряда × 6
        for (int i = 0; i < MAX_SELECTED; i++) {
            int col = i % 6;
            int row = i / 6;
            int sx = panelX + 16 + col * (SLOT_SIZE + SLOT_GAP);
            int sy = slotY(row);
            boolean filled = i < selected.size();
            boolean hovered = mouseX >= sx && mouseX <= sx + SLOT_SIZE && mouseY >= sy && mouseY <= sy + SLOT_SIZE;
            int bg = hovered ? GuiUtil.COLOR_ROW_HOVER : GuiUtil.COLOR_BLOCK_BG;
            GuiUtil.fillRoundRect(context, sx, sy, SLOT_SIZE, SLOT_SIZE, 6, bg);
            if (filled) {
                Item item = selected.get(i);
                try {
                    context.drawItem(new ItemStack(item), sx + (SLOT_SIZE - 16) / 2, sy + (SLOT_SIZE - 16) / 2);
                } catch (Exception ignored) {}
            } else {
                context.drawTextWithShadow(this.textRenderer, Text.literal("§8+"),
                        sx + SLOT_SIZE / 2 - 3, sy + SLOT_SIZE / 2 - 4, GuiUtil.COLOR_TEXT_MUTED);
            }
        }

        // Список предметов
        int lTop = listTop();
        int lBottom = listBottom();
        GuiUtil.fillRoundRect(context, panelX + 12, lTop - 2, panelX + panelW - 12, lBottom + 2, 6, GuiUtil.COLOR_BLOCK_BG);

        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= filtered.size()) break;
            Item item = filtered.get(idx);
            int rowY = lTop + i * ROW_HEIGHT;
            if (rowY + ROW_HEIGHT > lBottom) break;

            boolean hovered = mouseX >= panelX + 16 && mouseX <= panelX + panelW - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;
            if (hovered) {
                context.fill(panelX + 16, rowY, panelX + panelW - 16, rowY + ROW_HEIGHT - 1, GuiUtil.COLOR_ROW_HOVER);
            }

            boolean isSel = selected.contains(item);
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal((isSel ? "§a[+] " : "§7[ ] ") + "§f" + GuiUtil.itemName(item)),
                    panelX + 22, rowY + 5, 0xFFFFFF);
            try {
                context.drawItem(new ItemStack(item), panelX + panelW - 30, rowY + 1);
            } catch (Exception ignored) {}
        }

        if (filtered.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§7Ничего не найдено"),
                    panelX + panelW / 2, lTop + 30, GuiUtil.COLOR_TEXT_MUTED);
        }

        // Индикатор скролла
        if (filtered.size() > MAX_VISIBLE) {
            int trackX = panelX + panelW - 8;
            int trackH = MAX_VISIBLE * ROW_HEIGHT;
            context.fill(trackX, lTop, trackX + 3, lTop + trackH, 0xFF2A3038);
            float ratio = (float) scrollOffset / Math.max(1, filtered.size() - MAX_VISIBLE);
            int thumbH = Math.max(10, trackH * MAX_VISIBLE / filtered.size());
            int thumbY = lTop + (int) ((trackH - thumbH) * ratio);
            context.fill(trackX, thumbY, trackX + 3, thumbY + thumbH, GuiUtil.accent());
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        // Клик по ячейке — убрать предмет
        for (int i = 0; i < MAX_SELECTED; i++) {
            int sx = panelX + 16 + (i % 6) * (SLOT_SIZE + SLOT_GAP);
            int sy = slotY(i / 6);
            if (mouseX >= sx && mouseX <= sx + SLOT_SIZE && mouseY >= sy && mouseY <= sy + SLOT_SIZE) {
                if (i < selected.size()) {
                    selected.remove(i);
                    saveSelection();
                }
                return true;
            }
        }

        // Клик по списку — добавить/убрать
        int lTop = listTop();
        int lBottom = listBottom();
        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= filtered.size()) break;
            int rowY = lTop + i * ROW_HEIGHT;
            if (rowY + ROW_HEIGHT > lBottom) break;
            if (mouseX >= panelX + 16 && mouseX <= panelX + panelW - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                Item item = filtered.get(idx);
                if (selected.contains(item)) {
                    selected.remove(item);
                } else if (selected.size() >= MAX_SELECTED) {
                    notify("§cМаксимум " + MAX_SELECTED + " предметов");
                } else {
                    selected.add(item);
                }
                saveSelection();
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            scrollOffset = Math.min(scrollOffset + 1, Math.max(0, filtered.size() - MAX_VISIBLE));
        } else if (verticalAmount > 0) {
            scrollOffset = Math.max(scrollOffset - 1, 0);
        }
        return true;
    }

    private void notify(String msg) {
        if (this.client != null && this.client.player != null) {
            this.client.player.sendMessage(Text.literal(msg), false);
        }
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
