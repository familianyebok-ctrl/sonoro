package com.example.hungerguard;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * AI-фермер. Работает обычными клиентскими действиями: ходьба, прицеливание,
 * attackBlock/updateBlockBreakingProgress и interactBlock. Обход античита отсутствует.
 */
public final class FarmerBot {
    public static final FarmerBot INSTANCE = new FarmerBot();

    private static final Set<Block> CROPS = Set.of(
            Blocks.WHEAT, Blocks.CARROTS, Blocks.POTATOES, Blocks.BEETROOTS,
            Blocks.NETHER_WART, Blocks.PUMPKIN, Blocks.MELON, Blocks.SUGAR_CANE,
            Blocks.CACTUS, Blocks.BAMBOO, Blocks.KELP);

    private boolean running;
    private int tick;
    private int harvested;
    private int scanCursor;
    private BlockPos breaking;
    private Item pendingSeed;
    private BlockPos planting;
    private Item plantingItem;
    private int plantWait;
    private int plantRetries;
    private BlockPos chest;
    private int depositStep;
    private int depositWait;
    private int depositCooldown;
    private int stuckTicks;
    private Vec3d lastMovePos;
    private final Map<BlockPos, Integer> blockedUntil = new HashMap<>();
    private final Map<BlockPos, Integer> recentTargets = new HashMap<>();
    private final Set<BlockPos> targetCache = new HashSet<>();
    private final Set<BlockPos> knownChests = new HashSet<>();

    private float smoothYaw;
    private float smoothPitch;
    private boolean lookInitialized;
    private int aimTicks;
    private long shiftRelease = -1;

    private FarmerBot() {}

    public boolean isRunning() { return running; }
    public int getHarvested() { return harvested; }

    public void start() {
        running = true;
        tick = 0;
        harvested = 0;
        scanCursor = 0;
        breaking = null;
        planting = null;
        plantingItem = null;
        pendingSeed = null;
        chest = null;
        depositStep = 0;
        depositWait = 0;
        depositCooldown = 0;
        stuckTicks = 0;
        lastMovePos = null;
        blockedUntil.clear();
        recentTargets.clear();
        targetCache.clear();
        knownChests.clear();
        lookInitialized = false;
        aimTicks = 0;
        shiftRelease = -1;
        notify("§a[Фермер AI] Запущен");
    }

    public void stop() {
        if (!running) return;
        running = false;
        releaseKeys();
        notify("§c[Фермер AI] Остановлен (собрано: " + harvested + ")");
    }

    public void tick(MinecraftClient client) {
        if (!running) return;
        if (client.player == null || client.world == null || client.interactionManager == null) {
            releaseKeys();
            return;
        }
        if (client.player.isDead()) {
            stop();
            return;
        }
        HungerGuardConfig cfg = HungerGuardConfig.get();
        tick++;

        if (client.currentScreen != null && depositStep == 0) {
            releaseKeys();
            return;
        }

        updateShift(client, cfg);
        updateMemory(client, cfg);
        maintainTool(client, cfg);

        if (depositCooldown > 0) depositCooldown--;

        if (cfg.farmerDeposit && depositStep != 0) {
            tickDeposit(client, cfg);
            return;
        }
        if (cfg.farmerDeposit && isInventoryNearlyFull(client) && depositCooldown == 0) {
            chest = chooseChest(client, cfg.farmerChestRadius);
            if (chest != null) {
                depositStep = 1;
                depositWait = 0;
                releaseKeys();
                return;
            }
        }

        if (planting != null) {
            tickPlant(client, cfg);
            return;
        }
        if (breaking != null) {
            tickBreak(client, cfg);
            return;
        }

        if (tick % 2 == 0) rebuildTargets(client, cfg);
        BlockPos target = chooseTarget(client, cfg);
        if (target == null) {
            releaseKeys();
            return;
        }

        double reach = client.player.isCreative() ? 5.0 : 4.5;
        if (distance(client, target) > reach - 0.25) {
            navigate(client, target, cfg);
            return;
        }

        releaseKeys();
        Vec3d aim = aimPoint(client, target);
        lookAt(client, aim, cfg);
        BlockHitResult hit = raycast(client, aim);

        if (cfg.farmerStrict && (hit == null || hit.getType() != HitResult.Type.BLOCK || !hit.getBlockPos().equals(target))) {
            aimTicks++;
            if (aimTicks < 12) return;
            if (distance(client, target) > 2.4) navigate(client, target, cfg);
            return;
        }
        aimTicks = 0;

        if (!isHarvestable(client, target)) {
            recentTargets.remove(target);
            return;
        }

        Item seed = seedFor(client.world.getBlockState(target).getBlock());
        client.interactionManager.attackBlock(target, Direction.UP);
        breaking = target.toImmutable();
        pendingSeed = seed;
    }

    private void updateMemory(MinecraftClient client, HungerGuardConfig cfg) {
        int interval = Math.max(1, cfg.farmerScanIntervalTicks);
        if (tick % interval != 0) return;
        int r = cfg.farmerRange;
        BlockPos base = client.player.getBlockPos();
        int total = (r * 2 + 1) * (r * 2 + 1) * 5;
        int budget = Math.min(220, total);
        for (int i = 0; i < budget; i++) {
            int idx = scanCursor++ % total;
            int side = r * 2 + 1;
            int x = idx % side - r;
            int z = (idx / side) % side - r;
            int y = (idx / (side * side)) - 2;
            BlockPos p = base.add(x, y, z);
            BlockState s = client.world.getBlockState(p);
            if (isHarvestable(client, p) && isCropEnabled(s.getBlock(), cfg)) targetCache.add(p.toImmutable());
            Block b = s.getBlock();
            if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL) knownChests.add(p.toImmutable());
        }
        pruneCaches(client, cfg);
    }

    private void rebuildTargets(MinecraftClient client, HungerGuardConfig cfg) {
        long maxDistance = (long) (cfg.farmerRange + 4) * (cfg.farmerRange + 4) * 3L;
        targetCache.removeIf(p -> p.getSquaredDistance(client.player.getBlockPos()) > maxDistance);
        targetCache.removeIf(p -> !client.world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)
                || !isCropEnabled(client.world.getBlockState(p).getBlock(), cfg)
                || !isHarvestable(client, p)
                || isBlocked(p));
    }

    private void pruneCaches(MinecraftClient client, HungerGuardConfig cfg) {
        int r = cfg.farmerRange + 3;
        targetCache.removeIf(p -> p.getSquaredDistance(client.player.getBlockPos()) > r * r * 3L);
        recentTargets.entrySet().removeIf(e -> e.getValue() <= tick);
        blockedUntil.entrySet().removeIf(e -> e.getValue() <= tick);
        knownChests.removeIf(p -> p.getSquaredDistance(client.player.getBlockPos()) > cfg.farmerChestRadius * cfg.farmerChestRadius * 3L
                || !(client.world.getBlockState(p).getBlock() == Blocks.CHEST
                || client.world.getBlockState(p).getBlock() == Blocks.TRAPPED_CHEST
                || client.world.getBlockState(p).getBlock() == Blocks.BARREL));
    }

    private BlockPos chooseTarget(MinecraftClient client, HungerGuardConfig cfg) {
        BlockPos best = null;
        double bestScore = -Double.MAX_VALUE;
        for (BlockPos p : targetCache) {
            if (isBlocked(p) || recentTargets.containsKey(p)) continue;
            double d = distance(client, p);
            if (d > cfg.farmerRange + 1.0) continue;
            int neighbors = 0;
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos n = p.add(dx, 0, dz);
                if (targetCache.contains(n)) neighbors++;
            }
            double score = 80.0 - d * 5.0 + neighbors * cfg.farmerClusterWeight;
            if (p.getY() != client.player.getBlockY()) score -= Math.abs(p.getY() - client.player.getBlockY()) * 2.0;
            if (score > bestScore) { bestScore = score; best = p; }
        }
        if (best != null) recentTargets.put(best, tick + 30);
        return best;
    }

    private void navigate(MinecraftClient client, BlockPos target, HungerGuardConfig cfg) {
        Vec3d p = client.player.getPos();
        if (lastMovePos == null) lastMovePos = p;
        else if (p.squaredDistanceTo(lastMovePos) < 0.0025) stuckTicks++; else { stuckTicks = 0; lastMovePos = p; }

        if (stuckTicks > cfg.farmerStuckTicks) {
            blockedUntil.put(target.toImmutable(), tick + cfg.farmerRetryDelayTicks);
            stuckTicks = 0;
            releaseKeys();
            return;
        }

        double dx = target.getX() + 0.5 - p.x;
        double dz = target.getZ() + 0.5 - p.z;
        float targetYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
        lookAt(client, Vec3d.ofCenter(target), cfg);
        client.options.forwardKey.setPressed(true);
        client.options.sprintKey.setPressed(cfg.farmerSprint && !client.player.isUsingItem());

        boolean obstacle = client.player.horizontalCollision || obstacleAhead(client);
        if (obstacle && cfg.farmerAutoJump && client.player.isOnGround()) {
            client.options.jumpKey.setPressed(true);
        } else {
            client.options.jumpKey.setPressed(false);
        }

        // При слишком большом развороте сначала доворачиваемся, затем идём.
        float yawDelta = Math.abs(MathHelper.wrapDegrees(targetYaw - client.player.getYaw()));
        if (yawDelta > cfg.farmerMaxTurnAngle) {
            client.options.forwardKey.setPressed(false);
        }
    }

    private boolean obstacleAhead(MinecraftClient client) {
        Vec3d f = client.player.getRotationVec(1.0f).multiply(0.8);
        BlockPos feet = client.player.getBlockPos().add((int)Math.round(f.x), 0, (int)Math.round(f.z));
        return !client.world.getBlockState(feet).getCollisionShape(client.world, feet).isEmpty()
                || !client.world.getBlockState(feet.up()).getCollisionShape(client.world, feet.up()).isEmpty();
    }

    private void tickBreak(MinecraftClient client, HungerGuardConfig cfg) {
        if (breaking == null) return;
        if (client.world.getBlockState(breaking).isAir()) {
            BlockPos done = breaking;
            Item seed = pendingSeed;
            breaking = null;
            pendingSeed = null;
            harvested++;
            targetCache.remove(done);
            if (cfg.farmerReplant && seed != null) {
                planting = done.down();
                plantingItem = seed;
                plantWait = 5;
                plantRetries = 0;
            }
            return;
        }
        if (!isHarvestable(client, breaking)) {
            breaking = null;
            pendingSeed = null;
            return;
        }
        maintainTool(client, cfg);
        lookAt(client, aimPoint(client, breaking), cfg);
        client.interactionManager.updateBlockBreakingProgress(breaking, Direction.UP);
    }

    private void tickPlant(MinecraftClient client, HungerGuardConfig cfg) {
        if (planting == null) return;
        if (plantWait > 0) { plantWait--; return; }
        if (!isPlantableGround(client, planting)) { clearPlant(); return; }
        if (distance(client, planting) > 3.0) { navigate(client, planting, cfg); return; }
        int slot = findItemSlot(client, plantingItem);
        if (slot < 0) {
            if (++plantRetries > 15) clearPlant();
            return;
        }
        if (!selectInventoryItem(client, slot)) { if (++plantRetries > 8) clearPlant(); return; }
        lookAt(client, Vec3d.ofCenter(planting), cfg);
        BlockHitResult hit = raycast(client, Vec3d.ofCenter(planting));
        if (hit != null && hit.getBlockPos().equals(planting)) {
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
            plantWait = 2;
            plantRetries++;
            if (plantedSuccessfully(client)) clearPlant();
            else if (plantRetries > 8) clearPlant();
        } else if (++plantRetries > 8) clearPlant();
    }

    private boolean plantedSuccessfully(MinecraftClient client) {
        Block b = client.world.getBlockState(planting).getBlock();
        return b == Blocks.WHEAT || b == Blocks.CARROTS || b == Blocks.POTATOES
                || b == Blocks.BEETROOTS || b == Blocks.NETHER_WART;
    }

    private void clearPlant() { planting = null; plantingItem = null; plantRetries = 0; plantWait = 0; }

    private void tickDeposit(MinecraftClient client, HungerGuardConfig cfg) {
        if (chest == null) { depositStep = 0; return; }
        if (depositStep == 1) {
            if (distance(client, chest) > 3.2) { navigate(client, chest, cfg); return; }
            releaseKeys();
            lookAt(client, Vec3d.ofCenter(chest), cfg);
            BlockHitResult hit = raycast(client, Vec3d.ofCenter(chest));
            if (hit != null && hit.getBlockPos().equals(chest)) {
                client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
                depositStep = 2;
                depositWait = 8;
            } else if (++depositWait > 20) finishDeposit();
            return;
        }
        if (depositStep == 2) {
            if (depositWait > 0) { depositWait--; return; }
            if (client.currentScreen == null) { finishDeposit(); return; }
            moveDepositItems(client);
            depositStep = 3;
            depositWait = 4;
            return;
        }
        if (depositStep == 3) {
            if (depositWait > 0) { depositWait--; return; }
            if (client.currentScreen != null) client.currentScreen.close();
            finishDeposit();
        }
    }

    private void moveDepositItems(MinecraftClient client) {
        if (client.interactionManager == null || client.player == null) return;
        List<String> ids = HungerGuardConfig.get().farmerDepositItemIds;
        if (ids == null || ids.isEmpty()) return;
        int sync = client.player.currentScreenHandler.syncId;
        for (int invIndex = 0; invIndex < 36; invIndex++) {
            ItemStack st = client.player.getInventory().getStack(invIndex);
            if (st.isEmpty() || !ids.contains(Registries.ITEM.getId(st.getItem()).toString())) continue;
            int screenSlot = invIndex < 9 ? 36 + invIndex : invIndex;
            try { client.interactionManager.clickSlot(sync, screenSlot, 0, SlotActionType.QUICK_MOVE, client.player); }
            catch (Exception ignored) {}
        }
    }

    private void finishDeposit() {
        depositStep = 0;
        chest = null;
        depositWait = 0;
        depositCooldown = 40;
    }

    private BlockPos chooseChest(MinecraftClient client, int radius) {
        BlockPos center = client.player.getBlockPos();
        return knownChests.stream()
                .filter(p -> p.getSquaredDistance(center) <= radius * radius * 3L)
                .min(Comparator.comparingDouble(p -> p.getSquaredDistance(center)))
                .orElseGet(() -> scanChest(client, radius));
    }

    private BlockPos scanChest(MinecraftClient client, int radius) {
        BlockPos c = client.player.getBlockPos();
        BlockPos best = null; double bestD = Double.MAX_VALUE;
        for (int dx=-radius; dx<=radius; dx++) for (int dz=-radius; dz<=radius; dz++) for (int dy=-3; dy<=3; dy++) {
            BlockPos p = c.add(dx,dy,dz); Block b = client.world.getBlockState(p).getBlock();
            if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL) {
                double d = p.getSquaredDistance(c); if (d < bestD) { bestD=d; best=p; }
            }
        }
        if (best != null) knownChests.add(best.toImmutable());
        return best;
    }

    private void maintainTool(MinecraftClient client, HungerGuardConfig cfg) {
        if (!cfg.farmerToolSwitch) return;
        PlayerInventory inv = client.player.getInventory();
        int selected = inv.getSelectedSlot();
        ItemStack held = inv.getStack(selected);
        if (!held.isEmpty() && held.isDamageable()) {
            int remaining = held.getMaxDamage() - held.getDamage();
            int percent = held.getMaxDamage() == 0 ? 100 : remaining * 100 / held.getMaxDamage();
            if (percent <= cfg.farmerToolReservePercent) {
                int replacement = findBestReplacement(inv, held.getItem(), selected);
                if (replacement >= 0) selectInventoryItem(client, replacement);
            }
        }
    }

    private int findBestReplacement(PlayerInventory inv, Item item, int selected) {
        int best = -1, bestRemaining = -1;
        for (int i=0;i<36;i++) {
            if (i == selected) continue;
            ItemStack s=inv.getStack(i);
            if (s.isEmpty() || s.getItem()!=item) continue;
            int rem=s.isDamageable()?s.getMaxDamage()-s.getDamage():Integer.MAX_VALUE;
            if (rem>bestRemaining) { bestRemaining=rem; best=i; }
        }
        return best;
    }

    private boolean selectInventoryItem(MinecraftClient client, int inventoryIndex) {
        PlayerInventory inv = client.player.getInventory();
        if (inventoryIndex < 9) { inv.setSelectedSlot(inventoryIndex); return true; }
        try {
            int selected = inv.getSelectedSlot();
            int sync = client.player.playerScreenHandler.syncId;
            int mainSlot = 9 + (inventoryIndex - 9);
            int hotbarSlot = 36 + selected;
            client.interactionManager.clickSlot(sync, mainSlot, 0, SlotActionType.PICKUP, client.player);
            client.interactionManager.clickSlot(sync, hotbarSlot, 0, SlotActionType.PICKUP, client.player);
            client.interactionManager.clickSlot(sync, mainSlot, 0, SlotActionType.PICKUP, client.player);
            return true;
        } catch (Exception e) { return false; }
    }

    private int findItemSlot(MinecraftClient client, Item item) {
        if (item == null) return -1;
        PlayerInventory inv=client.player.getInventory();
        for(int i=0;i<36;i++) { ItemStack s=inv.getStack(i); if(!s.isEmpty() && s.getItem()==item) return i; }
        return -1;
    }

    private boolean isInventoryNearlyFull(MinecraftClient client) {
        PlayerInventory inv=client.player.getInventory(); int empty=0;
        for(int i=0;i<36;i++) if(inv.getStack(i).isEmpty()) empty++;
        return empty <= 2;
    }

    private boolean isCropEnabled(Block b, HungerGuardConfig cfg) {
        String id=Registries.BLOCK.getId(b).toString();
        return cfg.farmerCropIds == null || cfg.farmerCropIds.isEmpty() || cfg.farmerCropIds.contains(id);
    }

    private boolean isHarvestable(MinecraftClient client, BlockPos pos) {
        BlockState s = client.world.getBlockState(pos);
        Block b = s.getBlock();
        if (b == Blocks.PUMPKIN || b == Blocks.MELON) return true;

        // Для многоуровневых культур берём верхний сегмент. Нижний оставляем как основание.
        if (b == Blocks.SUGAR_CANE || b == Blocks.CACTUS || b == Blocks.BAMBOO || b == Blocks.KELP) {
            Block above = client.world.getBlockState(pos.up()).getBlock();
            Block below = client.world.getBlockState(pos.down()).getBlock();
            return above != b && below == b;
        }
        if (!CROPS.contains(b)) return false;
        for (var property : s.getProperties()) {
            if (property instanceof net.minecraft.state.property.IntProperty ip && "age".equals(ip.getName())) {
                int max = ip.getValues().stream().mapToInt(Integer::intValue).max().orElse(0);
                return s.get(ip) == max;
            }
        }
        return b == Blocks.NETHER_WART;
    }

    private Item seedFor(Block b) {
        if(b==Blocks.WHEAT)return Items.WHEAT_SEEDS;
        if(b==Blocks.CARROTS)return Items.CARROT;
        if(b==Blocks.POTATOES)return Items.POTATO;
        if(b==Blocks.BEETROOTS)return Items.BEETROOT_SEEDS;
        if(b==Blocks.NETHER_WART)return Items.NETHER_WART;
        return null;
    }

    private boolean isPlantableGround(MinecraftClient client, BlockPos p) {
        Block b=client.world.getBlockState(p).getBlock(); return b==Blocks.FARMLAND || b==Blocks.SOUL_SAND;
    }

    private boolean isBlocked(BlockPos p) { return blockedUntil.getOrDefault(p,0)>tick; }
    private double distance(MinecraftClient c, BlockPos p) { return c.player.getEyePos().distanceTo(Vec3d.ofCenter(p)); }

    private BlockHitResult raycast(MinecraftClient c, Vec3d target) {
        try { return c.world.raycast(new RaycastContext(c.player.getEyePos(),target,RaycastContext.ShapeType.OUTLINE,RaycastContext.FluidHandling.NONE,c.player)); }
        catch(Exception e){ return null; }
    }

    private Vec3d aimPoint(MinecraftClient c, BlockPos p) { return Vec3d.ofCenter(p); }

    private void lookAt(MinecraftClient c, Vec3d point, HungerGuardConfig cfg) {
        Vec3d eye=c.player.getEyePos(); double dx=point.x-eye.x, dy=point.y-eye.y, dz=point.z-eye.z;
        double h=Math.sqrt(dx*dx+dz*dz);
        float yaw=(float)Math.toDegrees(Math.atan2(-dx,dz));
        float pitch=(float)-Math.toDegrees(Math.atan2(dy,h));
        setLook(c,yaw,pitch,cfg);
    }

    private void setLook(MinecraftClient c,float targetYaw,float targetPitch,HungerGuardConfig cfg) {
        if(!lookInitialized){smoothYaw=c.player.getYaw();smoothPitch=c.player.getPitch();lookInitialized=true;}
        float sharp=MathHelper.clamp(cfg.farmerSharpness,0f,1f);
        float factor=0.08f+sharp*0.72f;
        float dyaw=MathHelper.wrapDegrees(targetYaw-smoothYaw);
        float max=cfg.farmerMaxTurnPerTick;
        dyaw=MathHelper.clamp(dyaw,-max,max);
        float dpitch=MathHelper.clamp(targetPitch-smoothPitch,-max*0.7f,max*0.7f);
        smoothYaw+=dyaw*factor;
        smoothPitch=MathHelper.clamp(smoothPitch+dpitch*factor,-90f,90f);
        c.player.setYaw(smoothYaw); c.player.setPitch(smoothPitch); c.player.headYaw=smoothYaw; c.player.bodyYaw=smoothYaw;
    }

    private void updateShift(MinecraftClient c,HungerGuardConfig cfg){
        if(cfg.farmerShiftIntervalTicks>0 && tick%cfg.farmerShiftIntervalTicks==0){c.options.sneakKey.setPressed(true);shiftRelease=tick+2;}
        if(shiftRelease>=0&&tick>=shiftRelease){c.options.sneakKey.setPressed(false);shiftRelease=-1;}
    }

    private void releaseKeys(){MinecraftClient c=MinecraftClient.getInstance();c.options.forwardKey.setPressed(false);c.options.backKey.setPressed(false);c.options.leftKey.setPressed(false);c.options.rightKey.setPressed(false);c.options.jumpKey.setPressed(false);c.options.sprintKey.setPressed(false);c.options.sneakKey.setPressed(false);}
    private void notify(String s){MinecraftClient c=MinecraftClient.getInstance();if(c.player!=null)c.player.sendMessage(Text.literal(s),false);}
}
