package com.example.hungerguard.builder;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdatePlayerAbilitiesC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Строительный бот v2 — полностью переписан на новый формат.
 * <p>
 * Новый формат:
 * - Конечный автомат с фазами: выбор → проверка опоры → движение → прицел → постановка → подтверждение.
 * - Одно действие и один поворот камеры за тик (без конфликта move+look).
 * - Пауза между блоками по конфигу, верификация с кулдауном.
 * - Корректный Y-якорь (всегда от земли), поддержка угол/центр.
 * - Надёжный поиск грани опоры и защита от зависания.
 */
public class BuilderBot {

    public static final BuilderBot INSTANCE = new BuilderBot();

    public enum State { IDLE, RUNNING, DONE, ERROR }

    private enum Phase { SELECT, CHECK, NAVIGATE, AIM, PLACE, VERIFY }

    private State state = State.IDLE;
    private Phase phase = Phase.SELECT;

    private BuilderTemplate template;
    private List<BuilderTemplate.Block> plan = new ArrayList<>();
    private int index = 0;
    private int placed = 0;
    private int delay = 0;
    private String error = "";

    // Текущая цель
    private BlockPos targetPos = null;
    private BuilderTemplate.Block targetBlock = null;
    private BlockHitResult pendingHit = null;

    // Верификация
    private BlockPos verifyPos = null;
    private String verifyId = null;
    private int verifyWait = 0;

    // Ломание неверного блока
    private BlockPos breakingPos = null;
    private int breakingTicks = 0;

    // Камера
    private float smoothYaw = 0f, smoothPitch = 0f;
    private boolean lookInit = false;

    // Анти-застревание
    private Vec3d stuckRef = null;
    private int stuckTicks = 0;
    private int failTicks = 0;

    private BuilderBot() {}

    public State getState() { return state; }
    public int getPlaced() { return placed; }
    public int getTotal() { return plan.size(); }
    public String getError() { return error; }

    /** Строитель снят на долгие тех.работы — поле шаблона не регает. */
    public static final boolean UNDER_MAINTENANCE = true;

    public void start() {
        if (UNDER_MAINTENANCE) {
            error = "Строитель на тех.работах";
            state = State.ERROR;
            notify("§c[Строитель] ⛔ На долгих тех.работах — поле шаблона чинится. Фермер работает.");
            return;
        }
        String name = HungerGuardConfig.get().builderTemplate;
        if (name == null || name.isEmpty()) {
            error = "Шаблон не выбран";
            state = State.ERROR;
            notify("§c[Строитель] Шаблон не выбран");
            return;
        }
        template = TemplateStore.load(name);
        if (template == null) {
            error = "Шаблон не найден: " + name;
            state = State.ERROR;
            notify("§c[Строитель] Шаблон не найден: " + name);
            return;
        }
        if (!HungerGuardConfig.get().builderAnchorSet) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                BlockPos p = mc.player.getBlockPos();
                HungerGuardConfig c = HungerGuardConfig.get();
                c.builderAnchorX = p.getX();
                c.builderAnchorY = p.getY();
                c.builderAnchorZ = p.getZ();
                c.builderAnchorSet = true;
                HungerGuardConfig.save();
                notify("§e[Строитель] Точка привязки авто: " + p.getX() + "," + p.getY() + "," + p.getZ());
            } else {
                error = "Точка привязки не задана";
                state = State.ERROR;
                notify("§c[Строитель] Задай точку постройки");
                return;
            }
        }

        plan = new ArrayList<>(template.blocks);
        // Слоями по Y, внутри слоя — ближе к игроку сначала (меньше ходьбы)
        MinecraftClient mc = MinecraftClient.getInstance();
        Vec3d playerPos = mc != null && mc.player != null ? mc.player.getPos() : Vec3d.ZERO;
        plan.sort(Comparator
                .comparingInt((BuilderTemplate.Block b) -> b.y)
                .thenComparingDouble(b -> {
                    Vec3d wp = worldPosStatic(template, b);
                    return wp.squaredDistanceTo(playerPos);
                }));

        index = 0;
        placed = 0;
        delay = 0;
        error = "";
        verifyPos = null;
        verifyId = null;
        breakingPos = null;
        lookInit = false;
        stuckRef = null;
        stuckTicks = 0;
        failTicks = 0;
        phase = Phase.SELECT;
        state = State.RUNNING;

        if (mc != null && mc.player != null) {
            smoothYaw = mc.player.getYaw();
            smoothPitch = mc.player.getPitch();
            if (mc.player.isCreative()) {
                mc.player.getAbilities().flying = true;
                mc.player.getAbilities().allowFlying = true;
                if (mc.getNetworkHandler() != null) {
                    mc.getNetworkHandler().sendPacket(new UpdatePlayerAbilitiesC2SPacket(mc.player.getAbilities()));
                }
            }
        }
        notify("§b[Строитель v2] Старт: " + plan.size() + " блоков");
    }

    public void stop() {
        if (state == State.RUNNING || state == State.DONE) {
            state = State.IDLE;
            phase = Phase.SELECT;
            releaseKeys();
            notify("§c[Строитель] Остановлен (" + placed + "/" + plan.size() + ")");
        }
    }

    public void tick(MinecraftClient client) {
        if (state != State.RUNNING) return;
        if (client.player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;

        if (delay > 0) {
            delay--;
            return;
        }

        // Добиваем неверный блок
        if (breakingPos != null) {
            if (client.world.getBlockState(breakingPos).isAir() || breakingTicks > 80) {
                breakingPos = null;
                breakingTicks = 0;
            } else {
                // держим взгляд на ломаемом блоке, один поворот за тик
                lookAtSmooth(client, Vec3d.ofCenter(breakingPos), 0.45f);
                client.interactionManager.updateBlockBreakingProgress(breakingPos, Direction.UP);
                breakingTicks++;
                return;
            }
        }

        // Верификация после постановки
        if (verifyPos != null) {
            if (verifyWait > 0) {
                verifyWait--;
                return;
            }
            String now = idAt(client, verifyPos);
            if (now != null && now.equals(verifyId)) {
                placed++;
                index++;
                verifyPos = null;
                verifyId = null;
                failTicks = 0;
                stuckRef = null;
                delay = Math.max(0, HungerGuardConfig.get().builderDelayTicks);
                phase = Phase.SELECT;
                return;
            }
            if (now != null && !now.equals(verifyId)) {
                // не тот блок — ломаем
                client.interactionManager.attackBlock(verifyPos, Direction.UP);
                if (!client.player.isCreative()) {
                    breakingPos = verifyPos;
                    breakingTicks = 0;
                }
                verifyPos = null;
                delay = 3;
                return;
            }
            // всё ещё воздух — повторим
            verifyPos = null;
        }

        if (index >= plan.size()) {
            state = State.DONE;
            releaseKeys();
            notify("§a[Строитель] Готово! " + placed + " блоков");
            return;
        }

        // Машина фаз
        switch (phase) {
            case SELECT -> doSelect(client);
            case CHECK -> doCheck(client);
            case NAVIGATE -> doNavigate(client);
            case AIM -> doAim(client);
            case PLACE -> doPlace(client);
            case VERIFY -> {} // уже обработано выше
        }
    }

    private void doSelect(MinecraftClient client) {
        targetBlock = plan.get(index);
        Vec3d wp = worldPos(targetBlock);
        targetPos = new BlockPos((int) Math.floor(wp.x), (int) Math.floor(wp.y), (int) Math.floor(wp.z));

        // уже стоит нужный блок — скип
        String cur = idAt(client, targetPos);
        if (cur != null && cur.equals(targetBlock.id)) {
            placed++;
            index++;
            failTicks = 0;
            stuckRef = null;
            // без задержки — сразу к следующему
            return;
        }
        phase = Phase.CHECK;
    }

    private void doCheck(MinecraftClient client) {
        // есть ли опора
        boolean hasSupport = false;
        for (Direction d : Direction.values()) {
            BlockPos n = targetPos.offset(d.getOpposite());
            if (!client.world.getBlockState(n).isAir()) { hasSupport = true; break; }
        }
        if (!hasSupport) {
            notify("§e[Строитель] Нет опоры для " + targetBlock.x + "," + targetBlock.y + "," + targetBlock.z + " — пропуск");
            index++;
            phase = Phase.SELECT;
            return;
        }
        phase = Phase.NAVIGATE;
    }

    private void doNavigate(MinecraftClient client) {
        BlockHitResult hit = findPreciseHit(client, targetPos);
        double reach = client.player.isCreative() ? 5.0 : 4.5;

        // если хит есть и в досягаемости — идём к AIM
        if (hit != null && client.player.getEyePos().distanceTo(hit.getPos()) <= reach - 0.30) {
            pendingHit = hit;
            failTicks = 0;
            phase = Phase.AIM;
            return;
        }

        // иначе — подходим
        failTicks++;
        if (failTicks > 180) {
            notify("§e[Строитель] Пропуск блока " + targetBlock.x + "," + targetBlock.y + "," + targetBlock.z + " (недостижим)");
            index++;
            failTicks = 0;
            pendingHit = null;
            phase = Phase.SELECT;
            return;
        }
        Vec3d aim = hit != null ? hit.getPos() : Vec3d.ofCenter(targetPos);
        moveToward(client, aim);
        // один плавный поворот за тик
        lookAtSmooth(client, aim, 0.28f);
    }

    private void doAim(MinecraftClient client) {
        if (pendingHit == null) {
            phase = Phase.NAVIGATE;
            return;
        }
        // стабилизируем прицел 2 тика чтобы не дёргаться
        lookAtSmooth(client, pendingHit.getPos(), 0.65f);
        // проверяем что всё ещё попали в нужную грань
        BlockHitResult now = findPreciseHit(client, targetPos);
        if (now == null || !now.getBlockPos().equals(pendingHit.getBlockPos()) || now.getSide() != pendingHit.getSide()) {
            // цель уехала — переищем
            pendingHit = now;
            if (pendingHit == null) {
                phase = Phase.NAVIGATE;
                return;
            }
        }
        // даём камере устаканиться
        delay = 1;
        phase = Phase.PLACE;
    }

    private void doPlace(MinecraftClient client) {
        if (pendingHit == null) {
            phase = Phase.NAVIGATE;
            return;
        }
        releaseKeys();
        // финальный доворот точно в хит
        lookAt(client, pendingHit.getPos());

        if (!ensureBlockInHand(client, targetBlock)) {
            index++;
            pendingHit = null;
            phase = Phase.SELECT;
            return;
        }
        try {
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, pendingHit);
            if (HungerGuardConfig.get().builderVerify) {
                verifyPos = targetPos;
                verifyId = targetBlock.id;
                verifyWait = 2;
            } else {
                placed++;
                index++;
            }
            pendingHit = null;
            phase = Phase.SELECT;
            delay = 1;
        } catch (Exception e) {
            error = "Ошибка: " + e.getMessage();
            state = State.ERROR;
            notify("§c[Строитель] " + error);
        }
    }

    // ===== УТИЛИТЫ =====

    private String idAt(MinecraftClient client, BlockPos pos) {
        Block b = client.world.getBlockState(pos).getBlock();
        if (b == null || b.equals(Blocks.AIR)) return null;
        // воздух как null
        if (client.world.getBlockState(pos).isAir()) return null;
        return Registries.BLOCK.getId(b).toString();
    }

    private BlockHitResult findPreciseHit(MinecraftClient client, BlockPos targetPos) {
        Vec3d eye = client.player.getEyePos();
        for (Direction side : Direction.values()) {
            BlockPos neighbor = targetPos.offset(side.getOpposite());
            if (client.world.getBlockState(neighbor).isAir()) continue;
            Vec3d faceCenter = Vec3d.ofCenter(neighbor).add(side.getOffsetX()*0.5, side.getOffsetY()*0.5, side.getOffsetZ()*0.5);
            Vec3d dir = faceCenter.subtract(eye);
            double dist = dir.length();
            if (dist < 0.05) continue;
            Vec3d end = eye.add(dir.normalize().multiply(dist + 0.6));
            BlockHitResult hit;
            try {
                hit = client.world.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, client.player));
            } catch (Exception e) { continue; }
            if (hit == null || hit.getType() != HitResult.Type.BLOCK) continue;
            if (hit.getBlockPos().equals(neighbor) && hit.getSide() == side) return hit;
        }
        return null;
    }

    private Vec3d worldPos(BuilderTemplate.Block b) {
        return worldPosStatic(template, b);
    }

    private static Vec3d worldPosStatic(BuilderTemplate tmpl, BuilderTemplate.Block b) {
        HungerGuardConfig c = HungerGuardConfig.get();
        int ox, oy, oz;
        if (c.builderAnchorCorner) {
            ox = c.builderAnchorX; oy = c.builderAnchorY; oz = c.builderAnchorZ;
        } else {
            ox = c.builderAnchorX - tmpl.dx / 2;
            oy = c.builderAnchorY;
            oz = c.builderAnchorZ - tmpl.dz / 2;
        }
        return new Vec3d(ox + b.x + 0.5, oy + b.y + 0.5, oz + b.z + 0.5);
    }

    private void moveToward(MinecraftClient client, Vec3d point) {
        HungerGuardConfig c = HungerGuardConfig.get();
        float speed = c.builderMoveSpeed;
        if (client.player.isCreative()) {
            Vec3d eye = client.player.getEyePos();
            double off = eye.y - client.player.getY();
            Vec3d to = point.subtract(eye);
            double len = to.length();
            if (len < 0.05) return;
            Vec3d dir = to.normalize();
            double step = Math.min(0.55 * speed, Math.max(0.12, len - 2.2));
            Vec3d ne = eye.add(dir.multiply(step));
            client.player.setPosition(ne.x, ne.y - off, ne.z);
            client.player.setVelocity(Vec3d.ZERO);
        } else {
            double dx = point.x - client.player.getX();
            double dz = point.z - client.player.getZ();
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            // один поворот уже делается в NAVIGATE, здесь только движение
            client.options.forwardKey.setPressed(true);
            // прыжок если застряли
            Vec3d p = client.player.getPos();
            if (stuckRef == null) { stuckRef = p; stuckTicks = 0; }
            else if (p.squaredDistanceTo(stuckRef) < 0.05) {
                stuckTicks++;
                if (stuckTicks % 10 == 0) client.options.jumpKey.setPressed(true);
            } else { stuckRef = p; stuckTicks = 0; client.options.jumpKey.setPressed(false); }
            if (client.player.horizontalCollision) client.options.jumpKey.setPressed(true);
        }
    }

    private void lookAt(MinecraftClient client, Vec3d point) {
        Vec3d eye = client.player.getEyePos();
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        double h = Math.sqrt(dx*dx+dz*dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        setLook(client, yaw, pitch);
    }

    private void lookAtSmooth(MinecraftClient client, Vec3d point, float factor) {
        Vec3d eye = client.player.getEyePos();
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        double h = Math.sqrt(dx*dx+dz*dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        setLookSmooth(client, yaw, pitch, factor);
    }

    private void setLook(MinecraftClient client, float ty, float tp) {
        float sharp = HungerGuardConfig.get().builderSharpness;
        if (!lookInit) { smoothYaw = client.player.getYaw(); smoothPitch = client.player.getPitch(); lookInit = true; }
        if (sharp >= 0.95f) { smoothYaw = ty; smoothPitch = tp; }
        else {
            float lerp = 0.12f + sharp * 0.65f;
            float dy = Math.abs(MathHelper.wrapDegrees(ty - smoothYaw));
            if (dy < 4f) lerp *= 0.5f;
            smoothYaw += MathHelper.wrapDegrees(ty - smoothYaw) * lerp;
            smoothPitch += (tp - smoothPitch) * lerp;
        }
        client.player.setYaw(smoothYaw); client.player.setPitch(smoothPitch);
        client.player.headYaw = smoothYaw; client.player.bodyYaw = smoothYaw;
    }

    private void setLookSmooth(MinecraftClient client, float ty, float tp, float f) {
        if (!lookInit) { smoothYaw = client.player.getYaw(); smoothPitch = client.player.getPitch(); lookInit = true; }
        float dy = Math.abs(MathHelper.wrapDegrees(ty - smoothYaw));
        float dp = Math.abs(tp - smoothPitch);
        if (dy < 0.6f && dp < 0.6f) return;
        f = MathHelper.clamp(f, 0.05f, 1f);
        if (dy < 4f) f *= 0.55f;
        smoothYaw += MathHelper.wrapDegrees(ty - smoothYaw) * f;
        smoothPitch += (tp - smoothPitch) * f;
        client.player.setYaw(smoothYaw); client.player.setPitch(smoothPitch);
        client.player.headYaw = smoothYaw; client.player.bodyYaw = smoothYaw;
    }

    private boolean ensureBlockInHand(MinecraftClient client, BuilderTemplate.Block b) {
        Item item = blockToItem(b.id);
        if (item == null) { notify("§e[Строитель] Неизвестный блок: " + b.id); return false; }
        PlayerInventory inv = client.player.getInventory();
        if (client.player.isCreative()) {
            inv.setSelectedSlot(0);
            try { client.getNetworkHandler().sendPacket(new CreativeInventoryActionC2SPacket(36, new ItemStack(item))); } catch (Exception ignored) {}
            return true;
        }
        int found = -1;
        for (int i=0;i<36;i++){ ItemStack st=inv.getStack(i); if(!st.isEmpty()&&st.getItem()==item){found=i;break;}}
        if (found==-1){ notify("§e[Строитель] Нет блока: " + itemName(item) + " — пропуск"); return false; }
        if (found<9){ inv.setSelectedSlot(found); return true; }
        try{
            int syncId=client.player.playerScreenHandler.syncId;
            int empty=-1; for(int i=0;i<9;i++) if(inv.getStack(i).isEmpty()){empty=i;break;}
            if(empty!=-1){ client.interactionManager.clickSlot(syncId, found, 0, SlotActionType.QUICK_MOVE, client.player); inv.setSelectedSlot(empty); return true; }
            client.interactionManager.clickSlot(syncId, found, 0, SlotActionType.PICKUP, client.player);
            client.interactionManager.clickSlot(syncId, 36, 0, SlotActionType.PICKUP, client.player);
            if(!client.player.currentScreenHandler.getCursorStack().isEmpty()){
                client.interactionManager.clickSlot(syncId, found, 0, SlotActionType.PICKUP, client.player);
            }
            inv.setSelectedSlot(0);
            return true;
        }catch(Exception e){ notify("§c[Строитель] Не удалось взять блок"); return false; }
    }

    private Item blockToItem(String id){
        try{
            Block block=Registries.BLOCK.get(Identifier.of(id));
            if(block==null||Blocks.AIR.equals(block)) return null;
            Item it=block.asItem();
            if(!(it instanceof BlockItem)) return null;
            return it;
        }catch(Exception e){return null;}
    }
    private String itemName(Item it){
        try{return it.getName().getString();}catch(Exception e){return Registries.ITEM.getId(it).toString();}
    }
    private void releaseKeys(){
        var o=MinecraftClient.getInstance().options;
        o.forwardKey.setPressed(false); o.backKey.setPressed(false);
        o.leftKey.setPressed(false); o.rightKey.setPressed(false);
        o.jumpKey.setPressed(false); o.sneakKey.setPressed(false);
    }
    private void notify(String msg){
        var c=MinecraftClient.getInstance();
        if(c.player!=null) c.player.sendMessage(Text.literal(msg), false);
    }
}
