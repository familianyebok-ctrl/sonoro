package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * «Предметы для макроса» — список предметов, которые будут АВТОМАТИЧЕСКИ
 * браться из инвентаря в хотбар (слоты 1–9, по порядку) при воспроизведении
 * макроса, если в настройках включено «Авто-взятие».
 */
public class ItemPickerScreenForMacro extends Screen {

    private static final int MAX_W = 440;
    private static final int MAX_H = 340;
    private static final int ROW_HEIGHT = 22;
    private static final int MAX_VISIBLE = 7;

    private final Screen parent;
    private final List<Item> filtered = new ArrayList<>();
    private final List<Item> selected = new ArrayList<>();

    private int panelX, panelY, panelW, panelH;
    private int scrollOffset = 0;
    private String searchQuery = "";
    private TextFieldWidget searchField;

    public ItemPickerScreenForMacro(Screen parent) {
        super(Text.literal("Macro Item Picker"));
        this.parent = parent;

        for (String id : HungerGuardConfig.get().macroInventoryItemIds) {
            try {
                Item item = Registries.ITEM.get(Identifier.of(id));
                if (item != null && item != Items.AIR) this.selected.add(item);
            } catch (Exception ignored) {}
        }
        this.filtered.addAll(GuiUtil.allItems());
    }

    @Override
    protected void init() {
        panelW = Math.min(MAX_W, this.width - 8);
        panelH = Math.min(MAX_H, this.height - 8);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        searchField = new TextFieldWidget(this.textRenderer, panelX + 16, panelY + 96,
                panelW - 32, 20, Text.literal("Поиск предмета..."));
        searchField.setMaxLength(64);
        searchField.setChangedListener(s -> {
            searchQuery = s.toLowerCase();
            applyFilter();
            scrollOffset = 0;
        });
        this.addDrawableChild(searchField);

        int y = panelY + panelH - 30;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                .dimensions(panelX + 16, y, 100, 22).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§a✔ Готово"), b -> {
            List<String> ids = new ArrayList<>();
            for (Item item : selected) ids.add(Registries.ITEM.getId(item).toString());
            HungerGuardConfig.get().macroInventoryItemIds = ids;
            HungerGuardConfig.save();
            close();
        }).dimensions(panelX + panelW - 116, y, 100, 22).build());
    }

    private void applyFilter() {
        filtered.clear();
        if (searchQuery.isEmpty()) {
            filtered.addAll(GuiUtil.allItems());
            return;
        }
        for (Item item : GuiUtil.allItems()) {
            String name = GuiUtil.itemName(item).toLowerCase();
            String id = Registries.ITEM.getId(item).toString().toLowerCase();
            if (name.contains(searchQuery) || id.contains(searchQuery)) {
                filtered.add(item);
            }
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        // Шапка с объяснением
        context.fill(panelX, panelY, panelX + panelW, panelY + 90, GuiUtil.COLOR_PANEL_BG);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§b§l📦 Предметы для макроса"),
                panelX + panelW / 2, panelY + 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§7Выбрано: §f" + selected.size() + " §7(порядок = слоты 1–9)"),
                panelX + panelW / 2, panelY + 24, GuiUtil.COLOR_TEXT_MUTED);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§8При воспроизведении эти предметы сами берутся из"),
                panelX + panelW / 2, panelY + 42, 0x808080);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§8инвентаря в хотбар (нужно включить «Авто-взятие»)"),
                panelX + panelW / 2, panelY + 54, 0x808080);

        int listTop = panelY + 124;
        int listBottom = panelY + panelH - 40;

        context.fill(panelX + 12, listTop - 4, panelX + panelW - 12, listBottom + 4, GuiUtil.COLOR_PANEL_BG);

        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§7Найдено: §f" + filtered.size()),
                panelX + 18, listTop - 12, GuiUtil.COLOR_TEXT_MUTED);

        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= filtered.size()) break;

            Item item = filtered.get(idx);
            int rowY = listTop + i * ROW_HEIGHT;
            if (rowY + ROW_HEIGHT > listBottom) break;

            boolean hovered = mouseX >= panelX + 16 && mouseX <= panelX + panelW - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;

            context.fill(panelX + 16, rowY, panelX + panelW - 16, rowY + ROW_HEIGHT - 1,
                    hovered ? GuiUtil.COLOR_ROW_HOVER : GuiUtil.COLOR_ROW_BG);

            try {
                context.drawItem(new ItemStack(item), panelX + 22, rowY + 2);
            } catch (Exception ignored) {}

            boolean isSelected = selected.contains(item);
            String prefix = isSelected ? "§a✔ " : "§7  ";
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal(prefix + "§f" + GuiUtil.itemName(item)),
                    panelX + 44, rowY + 7, 0xFFFFFF);

            String idText = Registries.ITEM.getId(item).getPath();
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal("§8" + idText),
                    panelX + panelW - 16 - this.textRenderer.getWidth(idText) - 4,
                    rowY + 7, 0x808080);
        }

        if (filtered.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("§7Ничего не найдено"),
                    panelX + panelW / 2, listTop + 30, GuiUtil.COLOR_TEXT_MUTED);
        }

        if (filtered.size() > MAX_VISIBLE) {
            int barX = panelX + panelW - 8;
            int barY = listTop;
            int barH = MAX_VISIBLE * ROW_HEIGHT;
            context.fill(barX, barY, barX + 3, barY + barH, 0xFF2A3038);
            float ratio = (float) scrollOffset / Math.max(1, filtered.size() - MAX_VISIBLE);
            int thumbH = Math.max(20, barH * MAX_VISIBLE / filtered.size());
            int thumbY = barY + (int) ((barH - thumbH) * ratio);
            context.fill(barX, thumbY, barX + 3, thumbY + thumbH, GuiUtil.accent());
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int listTop = panelY + 124;
        int listBottom = panelY + panelH - 40;

        for (int i = 0; i < MAX_VISIBLE; i++) {
            int idx = scrollOffset + i;
            if (idx >= filtered.size()) break;

            int rowY = listTop + i * ROW_HEIGHT;
            if (rowY + ROW_HEIGHT > listBottom) break;

            if (mouseX >= panelX + 16 && mouseX <= panelX + panelW - 16
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                Item item = filtered.get(idx);
                if (selected.contains(item)) {
                    selected.remove(item);
                } else {
                    selected.add(item);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            scrollOffset = Math.min(scrollOffset + 1, Math.max(0, filtered.size() - MAX_VISIBLE));
        } else if (verticalAmount > 0) {
            scrollOffset = Math.max(scrollOffset - 1, 0);
        }
        return true;
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
