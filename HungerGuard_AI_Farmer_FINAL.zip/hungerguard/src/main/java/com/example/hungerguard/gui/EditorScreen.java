package com.example.hungerguard.gui;

import com.example.hungerguard.HungerGuardConfig;
import com.example.hungerguard.builder.BuilderTemplate;
import com.example.hungerguard.builder.TemplateStore;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 3D-редактор шаблонов (упрощённый Blender):
 *  - орбитальная камера: ЛКМ-драг = вращение, колесо = зум, ПКМ-драг = сдвиг;
 *  - кисть/ластик: ЛКМ по грани куба = поставить/удалить блок;
 *  - каталог блоков с поиском справа;
 *  - сохранение в TemplateStore.
 */
public class EditorScreen extends Screen {

    private static final int SIDEBAR_W = 250;
    private static final int TOOL_PAINT = 0;
    private static final int TOOL_ERASE = 1;

    private static final Vec3d LIGHT = new Vec3d(0.5, 1.0, 0.35).normalize();

    private final Screen parent;
    private final String templateName;
    private final BuilderTemplate template;

    // сетка для быстрого доступа O(1)
    private String[][][] grid;

    // камера
    private float yaw = 45f;
    private float pitch = 32f;
    private float dist = 28f;
    private int panX = 0, panY = 0;

    // взаимодействие
    private int tool = TOOL_PAINT;
    private String currentBlockId = "minecraft:stone";
    private boolean dragging = false;
    private boolean panning = false;
    private double dragStartX, dragStartY;

    // отображение (ghost-режимы)
    private boolean showGrid = true;
    private int visualMode = 0;
    private static final String[] VISUAL_NAMES = {"Обычный", "Обводка", "Перелив", "Плазма", "Пульс"};

    // проецируемые грани для отрисовки и кликов
    private final List<FaceHit> faceHits = new ArrayList<>();

    // каталог блоков
    private final List<Item> blockItems = new ArrayList<>();
    private final List<Item> filtered = new ArrayList<>();
    private String searchQuery = "";
    private int catScroll = 0;
    private TextFieldWidget searchField;

    // категории и сетка палитры блоков
    private int category = 0;
    private static final String[] CATS = {"Все", "Дерево", "Камень", "Цветное", "Природа", "Механизмы", "Свет/Инв", "Разное"};
    private static final int CELL = 24;
    private static final int CELL_GAP = 2;
    private final int[][] catRects = new int[CATS.length][];
    private int gridTop = 0;

    // данные камеры (обновляются при отрисовке, используются для пикинга лучом)
    private Vec3d camPos, camFwd, camRight, camUp;
    private float camScale;
    private int camPcx, camPcy;

    public EditorScreen(Screen parent, String templateName) {
        super(Text.literal("Редактор: " + templateName));
        this.parent = parent;
        this.templateName = templateName;
        BuilderTemplate loaded = TemplateStore.load(templateName);
        this.template = (loaded != null) ? loaded : BuilderTemplate.createEmpty(templateName, 16, 16, 16);
        rebuildGrid();

        // ИСПРАВЛЕНО: палитра блоков — если GuiUtil вернул мало (<50) пересобираем напрямую из Registries, иначе половинки/слэбы пропадают
        List<Item> src = GuiUtil.allItems();
        if (src.size() < 50) GuiUtil.invalidateItemCache();
        src = GuiUtil.allItems();
        for (Item item : src) {
            if (item instanceof BlockItem) blockItems.add(item);
        }
        // Фолбэк напрямую из регистра если всё ещё мало (титульный экран, кэш пустой)
        if (blockItems.size() < 30) {
            blockItems.clear();
            for (Item item : Registries.ITEM) {
                if (item instanceof BlockItem && item != Items.AIR) blockItems.add(item);
            }
        }
        // Сортировка по id чтобы половинки и варианты были рядом и не терялись
        blockItems.sort(Comparator.comparing(i -> Registries.ITEM.getId(i).toString()));
        rebuildFiltered();

        this.showGrid = HungerGuardConfig.get().editorShowGrid;
        this.visualMode = HungerGuardConfig.get().editorVisualMode;
    }

    private void rebuildGrid() {
        grid = new String[template.dx][template.dy][template.dz];
        for (BuilderTemplate.Block b : template.blocks) {
            if (b.x >= 0 && b.x < template.dx && b.y >= 0 && b.y < template.dy && b.z >= 0 && b.z < template.dz) {
                grid[b.x][b.y][b.z] = b.id;
            }
        }
    }

    private void paint(int x, int y, int z, String id) {
        if (x < 0 || y < 0 || z < 0 || x >= template.dx || y >= template.dy || z >= template.dz) return;
        template.setBlock(x, y, z, id);
        rebuildGrid();
    }

    private int effectiveSidebarW() {
        // ИСПРАВЛЕНО: стабильная ширина чтобы не ломалась сетка и палитра
        if (this.width < 600) return Math.max(180, Math.min(220, (int)(this.width * 0.38)));
        if (this.width < 900) return 250;
        return 260;
    }

    @Override
    protected void init() {
        this.clearChildren();

        int effW = effectiveSidebarW();
        int sx = this.width - effW + 8;

        // ИСПРАВЛЕНО: адаптивная раскладка кнопок чтобы не вылезали за экран и не были кривыми
        boolean narrow = effW < 200;
        int gap = 4;
        int btnHalfW = (effW - 16 - gap) / 2;
        if (btnHalfW < 60) btnHalfW = effW - 16;
        int y = 10;
        if (narrow) {
            // узкий экран — все кнопки в столбик на всю ширину
            int fullW = effW - 16;
            this.addDrawableChild(ButtonWidget.builder(
                            Text.literal(tool == TOOL_PAINT ? "§a🖌 Кисть" : "§c🧽 Ластик"), b -> {
                        tool = (tool == TOOL_PAINT) ? TOOL_ERASE : TOOL_PAINT;
                        this.init();
                    }).dimensions(sx, y, fullW, 18).build());
            y += 22;
            this.addDrawableChild(ButtonWidget.builder(Text.literal("§7Сохранить"), b -> save())
                    .dimensions(sx, y, fullW, 18).build());
            y += 22;
            this.addDrawableChild(ButtonWidget.builder(Text.literal("§7Очистить всё"), b -> clearAll())
                    .dimensions(sx, y, fullW, 18).build());
            y += 22;
            this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                    .dimensions(sx, y, fullW, 18).build());
            y += 26;
        } else {
            this.addDrawableChild(ButtonWidget.builder(
                            Text.literal(tool == TOOL_PAINT ? "§a🖌 Кисть" : "§c🧽 Ластик"), b -> {
                        tool = (tool == TOOL_PAINT) ? TOOL_ERASE : TOOL_PAINT;
                        this.init();
                    }).dimensions(sx, y, btnHalfW, 20).build());
            this.addDrawableChild(ButtonWidget.builder(Text.literal("§7Сохранить"), b -> save())
                    .dimensions(sx + btnHalfW + gap, y, btnHalfW, 20).build());
            y += 26;
            this.addDrawableChild(ButtonWidget.builder(Text.literal("§7Очистить всё"), b -> clearAll())
                    .dimensions(sx, y, btnHalfW, 20).build());
            this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                    .dimensions(sx + btnHalfW + gap, y, btnHalfW, 20).build());
            y += 30;
        }

        // Поиск - ширина адаптивная
        searchField = new TextFieldWidget(this.textRenderer, sx, y, effW - 16, 18, Text.literal("Поиск блока..."));
        searchField.setMaxLength(64);
        searchField.setChangedListener(s -> {
            searchQuery = s.toLowerCase();
            rebuildFiltered();
            catScroll = 0;
        });
        this.addDrawableChild(searchField);
        y += 22;
        // Сетка и режим отображения — адаптивно
        int gridBtnW = narrow ? effW - 16 : btnHalfW;
        int viewBtnW = narrow ? effW - 16 : btnHalfW;
        if (!narrow) {
            this.addDrawableChild(ButtonWidget.builder(
                            Text.literal(showGrid ? "§a▦ Сетка: Вкл" : "§7▦ Сетка: Выкл"), b -> {
                        showGrid = !showGrid;
                        HungerGuardConfig.get().editorShowGrid = showGrid;
                        HungerGuardConfig.save();
                        this.init();
                    }).dimensions(sx, y, gridBtnW, 16).build());
            this.addDrawableChild(ButtonWidget.builder(
                            Text.literal("§7Вид: " + VISUAL_NAMES[visualMode]), b -> {
                        visualMode = (visualMode + 1) % VISUAL_NAMES.length;
                        HungerGuardConfig.get().editorVisualMode = visualMode;
                        HungerGuardConfig.save();
                        this.init();
                    }).dimensions(sx + btnHalfW + gap, y, viewBtnW, 16).build());
        } else {
            this.addDrawableChild(ButtonWidget.builder(
                            Text.literal(showGrid ? "§a▦ Сетка: Вкл" : "§7▦ Сетка: Выкл"), b -> {
                        showGrid = !showGrid;
                        HungerGuardConfig.get().editorShowGrid = showGrid;
                        HungerGuardConfig.save();
                        this.init();
                    }).dimensions(sx, y, gridBtnW, 16).build());
            y += 20;
            this.addDrawableChild(ButtonWidget.builder(
                            Text.literal("§7Вид: " + VISUAL_NAMES[visualMode]), b -> {
                        visualMode = (visualMode + 1) % VISUAL_NAMES.length;
                        HungerGuardConfig.get().editorVisualMode = visualMode;
                        HungerGuardConfig.save();
                        this.init();
                    }).dimensions(sx, y, viewBtnW, 16).build());
        }
    }

    private void save() {
        if (TemplateStore.save(template)) {
            notify("§a[Строитель] Шаблон \"" + templateName + "\" сохранён (" + template.blockCount() + " блоков)");
        } else {
            notify("§c[Строитель] Ошибка сохранения");
        }
    }

    private void clearAll() {
        template.blocks.clear();
        rebuildGrid();
        notify("§c[Строитель] Шаблон очищен");
    }

    private void rebuildFiltered() {
        filtered.clear();
        for (Item item : blockItems) {
            if (category != 0 && categoryOf(item) != category) continue;
            if (!searchQuery.isEmpty()) {
                String name = GuiUtil.itemName(item).toLowerCase();
                String id = Registries.ITEM.getId(item).toString().toLowerCase();
                if (!name.contains(searchQuery) && !id.contains(searchQuery)) continue;
            }
            filtered.add(item);
        }
    }

    /** Категория блока по id (0 зарезервирован под «Все»). */
    private static int categoryOf(Item item) {
        String id = Registries.ITEM.getId(item).getPath();
        if (has(id, "log", "planks", "_wood", "wooden", "fence", "gate", "sign")) return 1;
        if (has(id, "stone", "granite", "diorite", "andesite", "deepslate", "cobblestone", "bricks",
                "sandstone", "prismarine", "purpur", "quartz", "blackstone", "basalt", "tuff",
                "calcite", "nether")) return 2;
        if (has(id, "wool", "concrete", "terracotta", "glass", "candle", "banner", "carpet")) return 3;
        if (has(id, "grass", "dirt", "sand", "gravel", "leaves", "sapling", "flower", "mushroom",
                "cactus", "vine", "moss", "fern", "bamboo", "snow", "ice", "clay", "podzol",
                "mycelium", "coral", "kelp", "sugar", "tall_", "sea_", "azalea")) return 4;
        if (has(id, "redstone", "piston", "observer", "dispenser", "dropper", "hopper", "lever",
                "button", "pressure_plate", "rail", "repeater", "comparator", "target",
                "daylight", "tripwire")) return 5;
        if (has(id, "torch", "lantern", "lamp", "glowstone", "shroomlight", "campfire", "chest",
                "barrel", "furnace", "crafting_table", "anvil", "enchanting", "brewing", "cauldron",
                "ladder", "scaffolding", "bookshelf", "lectern", "bell", "loom", "grindstone",
                "smithing", "stonecutter", "cartography", "composter", "beacon", "conduit",
                "ender_chest", "respawn", "lodestone", "tnt", "sea_lantern", "jack_o", "end_rod",
                "pointed", "door", "trapdoor", "cake")) return 6;
        return 7;
    }

    private static boolean has(String id, String... keys) {
        for (String k : keys) if (id.contains(k)) return true;
        return false;
    }

    // ================= РЕНДЕР =================

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderViewport(context, mouseX, mouseY);
        renderSidebar(context, mouseX, mouseY);
        super.render(context, mouseX, mouseY, delta);
    }

    private boolean inViewport(double mx, double my) {
        return mx >= 8 && mx <= this.width - effectiveSidebarW() - 8 && my >= 8 && my <= this.height - 8;
    }

    private void renderViewport(DrawContext context, int mouseX, int mouseY) {
        int effW = effectiveSidebarW();
        int vx = 8, vy = 8, vw = this.width - effW - 16, vh = this.height - 16;
        if (vw < 120) vw = 120; // минимум чтобы не схлопывалось
        if (vh < 120) vh = 120;
        context.fill(vx, vy, vx + vw, vy + vh, 0xFF0A0E14);

        // камера
        double cx = template.dx / 2.0, cy = template.dy / 2.0, cz = template.dz / 2.0;
        double ry = Math.toRadians(yaw), rp = Math.toRadians(pitch);
        double cp = Math.cos(rp), sp = Math.sin(rp);
        Vec3d cam = new Vec3d(
                cx + dist * cp * Math.sin(ry),
                cy + dist * sp,
                cz + dist * cp * Math.cos(ry));
        Vec3d fwd = new Vec3d(cx - cam.x, cy - cam.y, cz - cam.z).normalize();
        Vec3d right = fwd.crossProduct(new Vec3d(0, 1, 0)).normalize();
        Vec3d up = right.crossProduct(fwd).normalize();

        float scale = 16f;
        int pcx = vx + vw / 2 + panX;
        int pcy = vy + vh / 2 + panY;

        // сохраняем базис камеры для пикинга лучом в doPaint()
        camPos = cam; camFwd = fwd; camRight = right; camUp = up;
        camScale = scale; camPcx = pcx; camPcy = pcy;

        faceHits.clear();
        for (BuilderTemplate.Block b : template.blocks) {
            for (Direction n : Direction.values()) {
                int nx = b.x + n.getOffsetX(), ny = b.y + n.getOffsetY(), nz = b.z + n.getOffsetZ();
                boolean occupied = nx >= 0 && nx < template.dx && ny >= 0 && ny < template.dy
                        && nz >= 0 && nz < template.dz && grid[nx][ny][nz] != null;
                if (occupied) continue; // грань скрыта соседом

                // отсечение задних граней
                double fx = b.x + 0.5 + n.getOffsetX() * 0.5;
                double fy = b.y + 0.5 + n.getOffsetY() * 0.5;
                double fz = b.z + 0.5 + n.getOffsetZ() * 0.5;
                Vec3d fc = new Vec3d(fx, fy, fz);
                Vec3d normal = new Vec3d(n.getOffsetX(), n.getOffsetY(), n.getOffsetZ());
                if (fc.subtract(cam).dotProduct(normal) >= 0) continue;

                float[] xs = new float[4], ys = new float[4];
                float depth = 0;
                Vec3d[] corners = faceCorners(b.x, b.y, b.z, n);
                for (int i = 0; i < 4; i++) {
                    Vec3d rel = corners[i].subtract(cam);
                    xs[i] = pcx + (float) rel.dotProduct(right) * scale;
                    ys[i] = pcy - (float) rel.dotProduct(up) * scale;
                    depth += (float) rel.dotProduct(fwd);
                }
                faceHits.add(new FaceHit(b.x, b.y, b.z, n, xs, ys, depth / 4f));
            }
        }

        // дальние → ближние
        faceHits.sort((a, c) -> Float.compare(c.depth, a.depth));

        context.enableScissor(vx, vy, vx + vw, vy + vh);

        // Сетка под постройкой (вкл/выкл как в Blender)
        if (showGrid) {
            drawGrid(context, cam, right, up, fwd, pcx, pcy, scale);
        }

        long t = System.currentTimeMillis();
        for (FaceHit fh : faceHits) {
            int col = faceColor(grid[fh.bx][fh.by][fh.bz], fh.bx, fh.by, fh.bz, fh.n, t);
            fillQuad(context, fh.xs, fh.ys, -fh.depth, col);
            if (visualMode == 1) { // обводка
                strokePolygon(context, fh.xs, fh.ys, -fh.depth - 0.2f, 0xFFE8ECF2);
            }
        }

        // подсветка под курсором: грань — белый контур, пустое место — клетка на сетке
        FaceHit hov = nearestFace(mouseX, mouseY);
        if (hov != null) {
            strokePolygon(context, hov.xs, hov.ys, 0f, 0xFFFFFFFF);
        } else if (tool == TOOL_PAINT) {
            int[] g = groundCellAt(mouseX, mouseY);
            if (g != null) drawGroundHighlight(context, g);
        }
        context.disableScissor();

        // подписи
        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§8ЛКМ-драг — вращение · колесо — зум · ПКМ-драг — сдвиг · ЛКМ — ставить/удалять"),
                vx + 8, vy + 8, 0x808080);
        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§8Размер: " + template.dx + "×" + template.dy + "×" + template.dz
                        + " · Блоков: " + template.blockCount()),
                vx + 8, vy + 22, 0x808080);
        if (template.blockCount() == 0) {
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal("§eПусто: кликни по сетке, чтобы поставить первый блок"),
                    vx + 8, vy + 36, 0xFFD6A83E);
        }
    }

    private void renderSidebar(DrawContext context, int mouseX, int mouseY) {
        int effW = effectiveSidebarW();
        int sx = this.width - effW + 8;
        GuiUtil.fillRoundRect(context, sx - 8, 8, effW, this.height - 16, 10, GuiUtil.COLOR_WINDOW_BG);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§b§lРедактор"), sx - 8 + effW / 2, 20, 0xFFFFFF);

        // Текущий блок — адаптивный отступ чтобы не налезал на кнопки на узких экранах
        int narrow = effW < 200 ? 1 : 0;
        int y = (narrow == 1) ? 186 : 120;
        context.drawTextWithShadow(this.textRenderer, Text.literal("§7Текущий блок:"), sx, y, GuiUtil.COLOR_TEXT_MUTED);
        Item cur = blockToItem(currentBlockId);
        if (cur != null) {
            try {
                context.drawItem(new ItemStack(cur), sx, y + 12);
                context.drawTextWithShadow(this.textRenderer, Text.literal("§f" + GuiUtil.itemName(cur)),
                        sx + 20, y + 18, 0xFFFFFF);
            } catch (Exception ignored) {}
        }
        y += 32;

        // Категории (кнопки-пилюли, переносятся на строки)
        context.drawTextWithShadow(this.textRenderer, Text.literal("§7Категории:"), sx, y, GuiUtil.COLOR_TEXT_MUTED);
        y += 12;
        int cx = sx;
        int catRowY = y;
        for (int i = 0; i < CATS.length; i++) {
            int tw = this.textRenderer.getWidth(CATS[i]) + 10;
            if (cx + tw > sx + effW - 16) { cx = sx; catRowY += 16; }
            boolean sel = i == category;
            boolean hovered = mouseX >= cx && mouseX <= cx + tw && mouseY >= catRowY && mouseY <= catRowY + 14;
            if (sel || hovered) {
                GuiUtil.fillPill(context, cx, catRowY, tw, 14, sel ? GuiUtil.accent() : 0xFF232B36);
            }
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal((sel ? "§f" : "§7") + CATS[i]), cx + 5, catRowY + 3,
                    sel ? 0xFFFFFF : 0xFFB9C0C8);
            catRects[i] = new int[]{cx, catRowY, tw, 14};
            cx += tw + 3;
        }
        y = catRowY + 14 + 8;
        gridTop = y;

        // Сетка блоков
        int gridBottom = this.height - 16;
        int gw = effW - 16;
        int cols = Math.max(1, gw / (CELL + CELL_GAP));
        int rowsVisible = Math.max(1, (gridBottom - y) / (CELL + CELL_GAP));
        int perPage = cols * rowsVisible;
        int maxScroll = Math.max(0, filtered.size() - perPage);
        if (catScroll > maxScroll) catScroll = maxScroll;

        for (int i = 0; i < perPage; i++) {
            int idx = catScroll + i;
            if (idx >= filtered.size()) break;
            Item item = filtered.get(idx);
            int r = i / cols, c = i % cols;
            int px = sx + c * (CELL + CELL_GAP);
            int py = y + r * (CELL + CELL_GAP);
            if (py + CELL > gridBottom) break;

            boolean sel = Registries.ITEM.getId(item).toString().equals(currentBlockId);
            boolean hovered = mouseX >= px && mouseX <= px + CELL && mouseY >= py && mouseY <= py + CELL;
            int bg = sel ? GuiUtil.accent() : (hovered ? GuiUtil.COLOR_ROW_HOVER : GuiUtil.COLOR_BLOCK_BG);
            GuiUtil.fillRoundRect(context, px, py, CELL, CELL, 4, bg);
            try {
                context.drawItem(new ItemStack(item), px + (CELL - 16) / 2, py + (CELL - 16) / 2);
            } catch (Exception ignored) {}
        }

        // Подсказка
        context.drawTextWithShadow(this.textRenderer,
                Text.literal("§8Колесо — листать · " + filtered.size() + " блоков"),
                sx, gridBottom - 10, 0x808080);
    }

    // ================= 3D-хелперы =================

    private Vec3d[] faceCorners(int x, int y, int z, Direction n) {
        return switch (n) {
            case EAST -> new Vec3d[]{new Vec3d(x + 1, y, z), new Vec3d(x + 1, y + 1, z), new Vec3d(x + 1, y + 1, z + 1), new Vec3d(x + 1, y, z + 1)};
            case WEST -> new Vec3d[]{new Vec3d(x, y, z), new Vec3d(x, y, z + 1), new Vec3d(x, y + 1, z + 1), new Vec3d(x, y + 1, z)};
            case UP -> new Vec3d[]{new Vec3d(x, y + 1, z), new Vec3d(x, y + 1, z + 1), new Vec3d(x + 1, y + 1, z + 1), new Vec3d(x + 1, y + 1, z)};
            case DOWN -> new Vec3d[]{new Vec3d(x, y, z), new Vec3d(x + 1, y, z), new Vec3d(x + 1, y, z + 1), new Vec3d(x, y, z + 1)};
            case SOUTH -> new Vec3d[]{new Vec3d(x, y, z + 1), new Vec3d(x + 1, y, z + 1), new Vec3d(x + 1, y + 1, z + 1), new Vec3d(x, y + 1, z + 1)};
            case NORTH -> new Vec3d[]{new Vec3d(x, y, z), new Vec3d(x, y + 1, z), new Vec3d(x + 1, y + 1, z), new Vec3d(x + 1, y, z)};
        };
    }

    private FaceHit nearestFace(double mx, double my) {
        for (int i = faceHits.size() - 1; i >= 0; i--) {
            FaceHit fh = faceHits.get(i);
            if (pointInPoly(fh.xs, fh.ys, mx, my)) return fh;
        }
        return null;
    }

    private boolean pointInPoly(float[] xs, float[] ys, double px, double py) {
        boolean inside = false;
        int n = xs.length;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            if (((ys[i] > py) != (ys[j] > py)) &&
                    (px < (xs[j] - xs[i]) * (py - ys[i]) / (ys[j] - ys[i]) + xs[i])) {
                inside = !inside;
            }
        }
        return inside;
    }

    private int blockColor(String id) {
        try {
            Block b = Registries.BLOCK.get(Identifier.of(id));
            if (b == null) return 0xFF9E9E9E;
            MapColor mc = b.getDefaultMapColor();
            int rgb = mc.getRenderColor(MapColor.Brightness.NORMAL);
            return 0xFF000000 | (rgb & 0xFFFFFF);
        } catch (Exception e) {
            return 0xFF9E9E9E;
        }
    }

    private int shade(int color, float f) {
        int r = (int) (((color >> 16) & 255) * f);
        int g = (int) (((color >> 8) & 255) * f);
        int b = (int) ((color & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Цвет грани с учётом режима отображения (ghost-режимы). */
    private int faceColor(String id, int bx, int by, int bz, Direction n, long t) {
        int base = blockColor(id);
        float light = 0.55f + 0.45f * (float) Math.max(0,
                n.getOffsetX() * LIGHT.x + n.getOffsetY() * LIGHT.y + n.getOffsetZ() * LIGHT.z);
        switch (visualMode) {
            case 1: // обводка — тёмная заливка + светлый контур
                return shade(base, light * 0.38f);
            case 2: // переливание — тон по высоте
                return shade(hsv(hueOf(base) + by * 12, 0.65f, 0.9f), light);
            case 3: { // плазма — живое переливание цветов
                int h = (int) ((Math.sin((bx + by) * 0.55 + t * 0.0012) + Math.cos((bz - by) * 0.45 - t * 0.0009)) * 300);
                return shade(hsv(h, 0.75f, 0.95f), light);
            }
            case 4: { // пульсация — свечение по волне
                float pulse = 0.55f + 0.45f * (float) Math.sin(t * 0.004 + (bx + bz) * 0.45);
                return shade(base, light * pulse);
            }
            default:
                return shade(base, light);
        }
    }

    private static int hsv(int h, float s, float v) {
        h = ((h % 360) + 360) % 360;
        float c = v * s;
        float x = c * (1 - Math.abs((h / 60f) % 2 - 1));
        float m = v - c;
        float r = 0, g = 0, b = 0;
        if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
        else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
        return 0xFF000000 | (((int) ((r + m) * 255)) << 16) | (((int) ((g + m) * 255)) << 8) | ((int) ((b + m) * 255));
    }

    private static int hueOf(int color) {
        int r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
        float rf = r / 255f, gf = g / 255f, bf = b / 255f;
        float max = Math.max(rf, Math.max(gf, bf)), min = Math.min(rf, Math.min(gf, bf));
        float d = max - min;
        if (d == 0) return 0;
        float h;
        if (max == rf) h = (gf - bf) / d + (gf < bf ? 6 : 0);
        else if (max == gf) h = (bf - rf) / d + 2;
        else h = (rf - gf) / d + 4;
        return (int) (h * 60) % 360;
    }

    /** Проецирует мировую точку на экран (null, если за камерой). */
    private float[] project(Vec3d p, Vec3d cam, Vec3d right, Vec3d up, Vec3d fwd, float scale, int pcx, int pcy) {
        Vec3d rel = p.subtract(cam);
        if (rel.dotProduct(fwd) <= 0.05) return null;
        float sx = pcx + (float) rel.dotProduct(right) * scale;
        float sy = pcy - (float) rel.dotProduct(up) * scale;
        return new float[]{sx, sy};
    }

    /** Сетка на плоскости y=0 под постройкой (как в Blender). */
    private void drawGrid(DrawContext context, Vec3d cam, Vec3d right, Vec3d up, Vec3d fwd, int pcx, int pcy, float scale) {
        int color = 0xFF2A3442;
        for (int x = 0; x <= template.dx; x++) {
            float[] a = project(new Vec3d(x, -0.01, 0), cam, right, up, fwd, scale, pcx, pcy);
            float[] b = project(new Vec3d(x, -0.01, template.dz), cam, right, up, fwd, scale, pcx, pcy);
            if (a != null && b != null) strokeLine(context, a[0], a[1], b[0], b[1], 0f, color);
        }
        for (int z = 0; z <= template.dz; z++) {
            float[] a = project(new Vec3d(0, -0.01, z), cam, right, up, fwd, scale, pcx, pcy);
            float[] b = project(new Vec3d(template.dx, -0.01, z), cam, right, up, fwd, scale, pcx, pcy);
            if (a != null && b != null) strokeLine(context, a[0], a[1], b[0], b[1], 0f, color);
        }
    }

    private void strokeLine(DrawContext context, float x1, float y1, float x2, float y2, float z, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01f) return;
        float px = -dy / len * 0.6f, py = dx / len * 0.6f;
        fillQuad(context,
                new float[]{x1 + px, x2 + px, x2 - px, x1 - px},
                new float[]{y1 + py, y2 + py, y2 - py, y1 - py},
                z, color);
    }

    private void strokePolygon(DrawContext context, float[] xs, float[] ys, float z, int color) {
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            strokeLine(context, xs[i], ys[i], xs[j], ys[j], z, color);
        }
    }

    private Item blockToItem(String blockId) {
        try {
            Block b = Registries.BLOCK.get(Identifier.of(blockId));
            if (b == null) return null;
            return b.asItem();
        } catch (Exception e) {
            return null;
        }
    }

    /** Рисует произвольный 4-угольник цветом (через debug-слой, 1.21.8). */
    private void fillQuad(DrawContext context, float[] xs, float[] ys, float z, int color) {
        float scale = (this.client == null) ? 1f : (float) this.client.getWindow().getScaleFactor();
        Matrix4f mat = new Matrix4f().scale(scale, scale, 1f);
        int a = (color >> 24) & 255, r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        emitQuad(buf, mat, xs, ys, r, g, b, a);
        // вторая обмотка — грань видна при любом culling
        emitQuad(buf, mat, new float[]{xs[0], xs[3], xs[2], xs[1]}, new float[]{ys[0], ys[3], ys[2], ys[1]}, r, g, b, a);
        BuiltBuffer built = buf.end();
        RenderLayer.getDebugQuads().draw(built);
    }

    private static void emitQuad(BufferBuilder buf, Matrix4f mat, float[] xs, float[] ys, int r, int g, int b, int a) {
        buf.vertex(mat, xs[0], ys[0], 0f).color(r, g, b, a);
        buf.vertex(mat, xs[1], ys[1], 0f).color(r, g, b, a);
        buf.vertex(mat, xs[2], ys[2], 0f).color(r, g, b, a);
        buf.vertex(mat, xs[3], ys[3], 0f).color(r, g, b, a);
    }

    // ================= ВВОД =================

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (inViewport(mx, my) && (button == GLFW.GLFW_MOUSE_BUTTON_LEFT || button == GLFW.GLFW_MOUSE_BUTTON_RIGHT)) {
            dragStartX = mx;
            dragStartY = my;
            dragging = false;
            panning = button == GLFW.GLFW_MOUSE_BUTTON_RIGHT;
            return true;
        }

        // Клик по категории или сетке блоков
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            int sx = this.width - effectiveSidebarW() + 8;
            for (int i = 0; i < CATS.length; i++) {
                int[] r = catRects[i];
                if (r != null && mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3]) {
                    category = i;
                    catScroll = 0;
                    rebuildFiltered();
                    return true;
                }
            }
            int cols = Math.max(1, (effectiveSidebarW() - 16) / (CELL + CELL_GAP));
            int c = (int) ((mx - sx) / (CELL + CELL_GAP));
            int r = (int) ((my - gridTop) / (CELL + CELL_GAP));
            if (mx >= sx && c >= 0 && c < cols && r >= 0) {
                int idx = catScroll + r * cols + c;
                if (idx >= 0 && idx < filtered.size()) {
                    currentBlockId = Registries.ITEM.getId(filtered.get(idx)).toString();
                    return true;
                }
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && !panning) {
            if (Math.abs(mx - dragStartX) + Math.abs(my - dragStartY) > 3) dragging = true;
            if (dragging) {
                yaw = (float) (yaw + dx * 0.6);
                pitch = MathHelper.clamp((float) (pitch - dy * 0.6), -89f, 89f);
            }
            return true;
        }
        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && panning) {
            panX += (int) dx;
            panY += (int) dy;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && !panning) {
            if (!dragging && inViewport(mx, my)) {
                doPaint(mx, my);
            }
            dragging = false;
            return true;
        }
        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            panning = false;
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    private void doPaint(double mx, double my) {
        if (camPos == null) return;
        // Луч из камеры через курсор (обратная проекция)
        double u = (mx - camPcx) / camScale;
        double v = (camPcy - my) / camScale;
        Vec3d dir = camFwd.add(camRight.multiply(u)).add(camUp.multiply(v));

        if (tool == TOOL_ERASE) {
            FaceHit fh = rayPickFace(camPos, dir);
            if (fh != null && grid[fh.bx][fh.by][fh.bz] != null) {
                paint(fh.bx, fh.by, fh.bz, null);
            }
            return;
        }

        // Кисть: сначала пробуем поставить блок на грань существующего блока
        FaceHit fh = rayPickFace(camPos, dir);
        if (fh != null) {
            int tx = fh.bx + fh.n.getOffsetX();
            int ty = fh.by + fh.n.getOffsetY();
            int tz = fh.bz + fh.n.getOffsetZ();
            if (inBounds(tx, ty, tz) && grid[tx][ty][tz] == null) {
                paint(tx, ty, tz, currentBlockId);
            }
            return;
        }

        // Пусто под курсором — ставим первый блок на землю (сетка y=0)
        int[] g = rayPickGround(camPos, dir);
        if (g != null && grid[g[0]][0][g[2]] == null) {
            paint(g[0], 0, g[2], currentBlockId);
        }
    }

    private boolean inBounds(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < template.dx && y < template.dy && z < template.dz;
    }

    /** Ближайшая видимая грань, пересечённая лучом (3D-пикинг). */
    private FaceHit rayPickFace(Vec3d o, Vec3d d) {
        FaceHit best = null;
        double bestT = Double.MAX_VALUE;
        for (BuilderTemplate.Block b : template.blocks) {
            for (Direction n : Direction.values()) {
                int nx = b.x + n.getOffsetX(), ny = b.y + n.getOffsetY(), nz = b.z + n.getOffsetZ();
                if (inBounds(nx, ny, nz) && grid[nx][ny][nz] != null) continue; // грань закрыта соседом
                double t = rayFaceT(o, d, b.x, b.y, b.z, n);
                if (t > 0.001 && t < bestT) {
                    bestT = t;
                    best = new FaceHit(b.x, b.y, b.z, n, null, null, (float) t);
                }
            }
        }
        return best;
    }

    /** Пересечение луча с ось-выровненной гранью куба; -1 если нет. */
    private double rayFaceT(Vec3d o, Vec3d d, int bx, int by, int bz, Direction n) {
        double t;
        switch (n) {
            case EAST:  if (d.x == 0) return -1; t = (bx + 1 - o.x) / d.x; if (t <= 0) return -1;
                return (o.y + t * d.y >= by && o.y + t * d.y <= by + 1 && o.z + t * d.z >= bz && o.z + t * d.z <= bz + 1) ? t : -1;
            case WEST:  if (d.x == 0) return -1; t = (bx - o.x) / d.x; if (t <= 0) return -1;
                return (o.y + t * d.y >= by && o.y + t * d.y <= by + 1 && o.z + t * d.z >= bz && o.z + t * d.z <= bz + 1) ? t : -1;
            case UP:    if (d.y == 0) return -1; t = (by + 1 - o.y) / d.y; if (t <= 0) return -1;
                return (o.x + t * d.x >= bx && o.x + t * d.x <= bx + 1 && o.z + t * d.z >= bz && o.z + t * d.z <= bz + 1) ? t : -1;
            case DOWN:  if (d.y == 0) return -1; t = (by - o.y) / d.y; if (t <= 0) return -1;
                return (o.x + t * d.x >= bx && o.x + t * d.x <= bx + 1 && o.z + t * d.z >= bz && o.z + t * d.z <= bz + 1) ? t : -1;
            case SOUTH: if (d.z == 0) return -1; t = (bz + 1 - o.z) / d.z; if (t <= 0) return -1;
                return (o.x + t * d.x >= bx && o.x + t * d.x <= bx + 1 && o.y + t * d.y >= by && o.y + t * d.y <= by + 1) ? t : -1;
            default:    if (d.z == 0) return -1; t = (bz - o.z) / d.z; if (t <= 0) return -1;
                return (o.x + t * d.x >= bx && o.x + t * d.x <= bx + 1 && o.y + t * d.y >= by && o.y + t * d.y <= by + 1) ? t : -1;
        }
    }

    /** Клетка земли (y=0) под курсором; null если луч не попадает в сетку. */
    private int[] groundCellAt(double mx, double my) {
        if (camPos == null) return null;
        double u = (mx - camPcx) / camScale;
        double v = (camPcy - my) / camScale;
        Vec3d dir = camFwd.add(camRight.multiply(u)).add(camUp.multiply(v));
        return rayPickGround(camPos, dir);
    }

    private int[] rayPickGround(Vec3d o, Vec3d d) {
        if (Math.abs(d.y) < 1e-6) return null;
        double t = -o.y / d.y;
        if (t <= 0.001) return null;
        double x = o.x + t * d.x, z = o.z + t * d.z;
        // ИСПРАВЛЕНО: граница >= вместо > (раньше пропускала крайние клетки)
        if (x < 0 || x >= template.dx || z < 0 || z >= template.dz) return null;
        int gx = (int) Math.floor(x), gz = (int) Math.floor(z);
        if (gx < 0 || gx >= template.dx || gz < 0 || gz >= template.dz) return null;
        return new int[]{gx, 0, gz};
    }

    /** Подсветка клетки земли под курсором (куда встанет первый блок). */
    private void drawGroundHighlight(DrawContext context, int[] g) {
        float[] xs = new float[4], ys = new float[4];
        Vec3d[] cs = new Vec3d[]{
                new Vec3d(g[0], 0.02, g[2]), new Vec3d(g[0] + 1, 0.02, g[2]),
                new Vec3d(g[0] + 1, 0.02, g[2] + 1), new Vec3d(g[0], 0.02, g[2] + 1)};
        for (int i = 0; i < 4; i++) {
            float[] p = project(cs[i], camPos, camRight, camUp, camFwd, camScale, camPcx, camPcy);
            if (p == null) return;
            xs[i] = p[0]; ys[i] = p[1];
        }
        fillQuad(context, xs, ys, 0f, 0x593ED6C4);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (inViewport(mx, my)) {
            dist = MathHelper.clamp(dist - (float) v * 1.5f, 8f, 60f);
            return true;
        }
        // над сеткой блоков — листаем палитру
        int sx = this.width - effectiveSidebarW() + 8;
        if (mx >= sx) {
            int cols = Math.max(1, (effectiveSidebarW() - 16) / (CELL + CELL_GAP));
            int rows = Math.max(1, (this.height - 16 - gridTop) / (CELL + CELL_GAP));
            int perPage = cols * rows;
            catScroll = (int) MathHelper.clamp(catScroll - v * cols, 0, Math.max(0, filtered.size() - perPage));
            return true;
        }
        return super.mouseScrolled(mx, my, h, v);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void notify(String msg) {
        if (this.client != null && this.client.player != null) {
            this.client.player.sendMessage(Text.literal(msg), false);
        }
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static final class FaceHit {
        final int bx, by, bz;
        final Direction n;
        final float[] xs, ys;
        final float depth;

        FaceHit(int bx, int by, int bz, Direction n, float[] xs, float[] ys, float depth) {
            this.bx = bx; this.by = by; this.bz = bz;
            this.n = n; this.xs = xs; this.ys = ys; this.depth = depth;
        }
    }
}
