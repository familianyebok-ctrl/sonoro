package com.example.hungerguard;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.BufferUtils;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWKeyCallback;
import org.lwjgl.glfw.GLFWMouseButtonCallback;

import java.nio.DoubleBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MacroRecorder {

    public static final MacroRecorder INSTANCE = new MacroRecorder();
    public static final boolean REQUIRE_SINGLEPLAYER_FOR_MACRO = false;

    /** Период повторения ПКМ при зажатой кнопке — как в ванильном клиенте (каждые 4 тика). */
    private static final int USE_REPEAT_TICKS = 4;

    public enum State { IDLE, RECORDING, PLAYING }

    private State state = State.IDLE;
    private final List<Frame> frames = new ArrayList<>();
    private int playbackIndex = 0;
    private final List<ChatEntry> pendingChat = new ArrayList<>();
    private boolean suppressRecording = false;
    private int cooldownTicks = 0;
    private final Random random = new Random();

    private boolean prevAttack = false;
    private boolean prevUse = false;
    private boolean prevDrop = false;
    private boolean prevSwapHands = false;
    private boolean prevInventory = false;
    private boolean prevJump = false;
    private boolean prevSneak = false;
    private boolean prevSprint = false;

    // ==== Мышь (GLFW) — для кликов в интерфейсах (верстак, сундук и т.п.) ====
    private boolean prevLeftDown = false;
    private boolean prevRightDown = false;
    private boolean prevScreenOpen = false;

    // ==== GLFW-колбэки (точный захват каждого клика/нажатия, даже короче тика) ====
    private GLFWKeyCallback prevKeyCallback = null;
    private GLFWMouseButtonCallback prevMouseCallback = null;
    private GLFWKeyCallback myKeyCallback = null;
    private GLFWMouseButtonCallback myMouseCallback = null;
    private long macroWindow = 0L;
    private final DoubleBuffer cxBuf = BufferUtils.createDoubleBuffer(1);
    private final DoubleBuffer cyBuf = BufferUtils.createDoubleBuffer(1);

    // Флаги нажатий за текущий тик (колбэк пишет, recordTick читает и сбрасывает)
    private boolean fwdPressed = false, backPressed = false, leftPressed = false, rightPressed = false;
    private boolean jumpPressed = false, sneakPressed = false, sprintPressed = false;
    private boolean dropPressed = false, swapPressed = false, invPressed = false;
    private boolean leftClickPressed = false, rightClickPressed = false;
    private double clickX = 0, clickY = 0; // позиция курсора в момент нажатия (scaled)

    // Сколько тиков подряд ждём открытия экрана при воспроизведении (анти-зависание)
    private int stallTicks = 0;

    private int useRepeatTimer = 0;

    private float smoothYaw = 0f;
    private float smoothPitch = 0f;
    private boolean smoothInit = false;

    private float legiCurrentSharpness = 0.5f;
    private int legiSharpnessTimer = 0;
    private float legiAimDrift = 0f;
    private int legiAimDriftTimer = 0;

    private float speedAccumulator = 0f;
    private int legiTimingDelay = 0;

    private boolean inventoryRestoreTriggered = false;

    // Плавность камеры в «Точном» режиме (0 = как раньше, 1 = максимально мягко)
    private float exactYaw = 0f;
    private float exactPitch = 0f;
    private boolean exactSmoothInit = false;

    // ==== Для плавной камеры в «Точном» режиме ====
    /** Индекс кадра, применённого в последнем тике (цель камеры на конец текущего тика). */
    private int activeFrameIdx = -1;
    /** Время последнего рендер-кадра (наносекунды) — для независимости «Легит»-сглаживания от FPS. */
    private long lastRenderNanos = 0L;
    /** Возраст игрока на прошлом рендер-кадре — чтобы рандомизация «Легит» менялась раз в тик. */
    private int lastTickAge = -1;

    private MacroRecorder() {}

    public State getState() { return state; }
    public int getFrameCount() { return frames.size(); }
    public int getCooldownRemainingTicks() { return cooldownTicks; }

    // ИСПРАВЛЕНО: дебаунс чтобы не лагало при быстрых кликах Стоп/Старт
    private long lastMacroActionMs = 0;
    private boolean canDoMacroAction() {
        long now = System.currentTimeMillis();
        if (now - lastMacroActionMs < 400) return false;
        lastMacroActionMs = now;
        return true;
    }

    public void startRecording() {
        if (!canDoMacroAction() && state == State.RECORDING) return;
        // Если уже играет - сначала стоп
        if (state == State.PLAYING) stopPlayback(MinecraftClient.getInstance());
        if (state == State.RECORDING) return; // уже пишется
        frames.clear();
        pendingChat.clear();
        cooldownTicks = 0;
        stallTicks = 0;
        installInputHooks(MinecraftClient.getInstance());
        state = State.RECORDING;
        log("§a[Macro] Запись начата");
        lastMacroActionMs = System.currentTimeMillis();
    }

    public void stopRecording() {
        uninstallInputHooks();
        if (state == State.RECORDING) {
            state = State.IDLE;
            log("§a[Macro] Запись остановлена (" + frames.size() + " тиков)");
        }
    }

    public void startPlayback() {
        if (!canDoMacroAction() && state == State.PLAYING) return;
        if (state == State.RECORDING) stopRecording();
        if (frames.isEmpty()) return;
        // Не стартуем если уже играет
        if (state == State.PLAYING) return;
        playbackIndex = 0;
        cooldownTicks = 0;
        speedAccumulator = 0f;
        smoothInit = false;
        exactSmoothInit = false;
        legiCurrentSharpness = 0.5f;
        legiSharpnessTimer = 0;
        legiAimDrift = 0f;
        legiAimDriftTimer = 0;
        legiTimingDelay = 0;
        inventoryRestoreTriggered = false;
        useRepeatTimer = 0;
        activeFrameIdx = -1;
        lastRenderNanos = 0L;
        lastTickAge = -1;
        stallTicks = 0;
        resetEdgeState();
        state = State.PLAYING;
        log("§b[Macro] Воспроизведение начато");
    }

    public void stopPlayback(MinecraftClient client) {
        uninstallInputHooks();
        if (state != State.IDLE) {
            state = State.IDLE;
            log("§b[Macro] Воспроизведение остановлено");
        }
        cooldownTicks = 0;
        speedAccumulator = 0f;
        activeFrameIdx = -1;
        resetEdgeState();
        releaseAllKeys(client);
    }

    private void resetEdgeState() {
        prevAttack = false;
        prevUse = false;
        prevDrop = false;
        prevSwapHands = false;
        prevInventory = false;
        prevJump = false;
        prevSneak = false;
        prevSprint = false;
        prevLeftDown = false;
        prevRightDown = false;
        prevScreenOpen = false;
        useRepeatTimer = 0;
    }

    /**
     * Вешаем свои GLFW-колбэки на время записи. Они ловят КАЖДОЕ нажатие клавиши
     * и кнопки мыши — даже если оно длилось меньше одного тика (20 Гц), чтобы
     * запись ничего не пропускала. Ванильные колбэки сохраняем и вызываем ПОСЛЕ
     * своих, чтобы не сломать игру; при остановке возвращаем их на место.
     */
    private void installInputHooks(MinecraftClient client) {
        uninstallInputHooks();
        if (client.getWindow() == null) return;
        long handle = client.getWindow().getHandle();
        macroWindow = handle;

        myKeyCallback = new GLFWKeyCallback() {
            @Override public void invoke(long window, int key, int scancode, int action, int mods) {
                // ИСПРАВЛЕНО: не записываем нажатия когда открыт любой экран (меню, инвентарь) — иначе макрос лагает и записывает клики по своим же кнопкам
                MinecraftClient mc = MinecraftClient.getInstance();
                boolean isScreenOpen = mc.currentScreen != null;
                if (action == GLFW.GLFW_PRESS && !isScreenOpen) {
                    GameOptions go = mc.options;
                    if (go.forwardKey.matchesKey(key, scancode)) fwdPressed = true;
                    if (go.backKey.matchesKey(key, scancode)) backPressed = true;
                    if (go.leftKey.matchesKey(key, scancode)) leftPressed = true;
                    if (go.rightKey.matchesKey(key, scancode)) rightPressed = true;
                    if (go.jumpKey.matchesKey(key, scancode)) jumpPressed = true;
                    if (go.sneakKey.matchesKey(key, scancode)) sneakPressed = true;
                    if (go.sprintKey.matchesKey(key, scancode)) sprintPressed = true;
                    if (go.dropKey.matchesKey(key, scancode)) dropPressed = true;
                    if (go.swapHandsKey.matchesKey(key, scancode)) swapPressed = true;
                    if (go.inventoryKey.matchesKey(key, scancode)) invPressed = true;
                }
                if (prevKeyCallback != null) prevKeyCallback.invoke(window, key, scancode, action, mods);
            }
        };
        prevKeyCallback = GLFW.glfwSetKeyCallback(handle, myKeyCallback);

        myMouseCallback = new GLFWMouseButtonCallback() {
            @Override public void invoke(long window, int button, int action, int mods) {
                // ИСПРАВЛЕНО: не записываем клики по интерфейсам — иначе при старте/стопе макроса запись ловит клик по кнопке "Старт" и ломается
                MinecraftClient mc = MinecraftClient.getInstance();
                boolean isScreenOpen = mc.currentScreen != null;
                if (action == GLFW.GLFW_PRESS && !isScreenOpen) {
                    if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) leftClickPressed = true;
                    else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) rightClickPressed = true;
                    cxBuf.clear(); cyBuf.clear();
                    GLFW.glfwGetCursorPos(window, cxBuf, cyBuf);
                    double scale = mc.getWindow().getScaleFactor();
                    if (scale < 1) scale = 1;
                    clickX = cxBuf.get(0) / scale;
                    clickY = cyBuf.get(0) / scale;
                }
                if (prevMouseCallback != null) prevMouseCallback.invoke(window, button, action, mods);
            }
        };
        prevMouseCallback = GLFW.glfwSetMouseButtonCallback(handle, myMouseCallback);
    }

    private void uninstallInputHooks() {
        if (macroWindow != 0L) {
            if (myKeyCallback != null) {
                GLFW.glfwSetKeyCallback(macroWindow, prevKeyCallback);
                myKeyCallback.free();
                myKeyCallback = null;
            }
            if (myMouseCallback != null) {
                GLFW.glfwSetMouseButtonCallback(macroWindow, prevMouseCallback);
                myMouseCallback.free();
                myMouseCallback = null;
            }
            prevKeyCallback = null;
            prevMouseCallback = null;
            macroWindow = 0L;
        }
        fwdPressed = backPressed = leftPressed = rightPressed = false;
        jumpPressed = sneakPressed = sprintPressed = false;
        dropPressed = swapPressed = invPressed = false;
        leftClickPressed = rightClickPressed = false;
    }

    public void clear() {
        uninstallInputHooks();
        frames.clear();
        pendingChat.clear();
        playbackIndex = 0;
        cooldownTicks = 0;
        stallTicks = 0;
        if (state != State.RECORDING) state = State.IDLE;
        log("§7[Macro] Запись очищена");
    }

    public void recordChat(String message, boolean isCommand) {
        if (state != State.RECORDING || suppressRecording) return;
        if (message == null || message.isEmpty()) return;
        ChatEntry entry = new ChatEntry(message, isCommand);
        if (!frames.isEmpty()) {
            Frame last = frames.get(frames.size() - 1);
            if (last.chatEntries == null) last.chatEntries = new ArrayList<>();
            last.chatEntries.add(entry);
        } else {
            pendingChat.add(entry);
        }
    }

    public void runWithoutRecording(Runnable action) {
        boolean previous = suppressRecording;
        suppressRecording = true;
        try { action.run(); }
        finally { suppressRecording = previous; }
    }

    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        GameOptions o = client.options;
        if (state == State.RECORDING) recordTick(client, o);
        else if (state == State.PLAYING) playbackTick(client, o);
    }

    /**
     * Плавная интерполяция камеры. Вызывается КАЖДЫЙ рендер-кадр из `HudRenderCallback`
     * (рендер-фаза идёт ПОСЛЕ тика), поэтому `tickDelta` — реальный прогресс внутри
     * текущего тика (0..1), а не фиксированная 1.0.
     */
    public void onRenderFrame(MinecraftClient client, float tickDelta) {
        if (state != State.PLAYING || client.player == null) return;
        if (frames.isEmpty()) return;

        HungerGuardConfig cfg = HungerGuardConfig.get();
        int legit = cfg.macroLegitLevel;
        int size = frames.size();

        int activeIdx = activeFrameIdx;
        if (activeIdx < 0 || activeIdx >= size) activeIdx = 0;

        Frame to = frames.get(activeIdx);
        int fromIdx;
        if (activeIdx > 0) {
            fromIdx = activeIdx - 1;
        } else {
            fromIdx = cfg.macroLoop ? size - 1 : 0;
        }
        Frame from = frames.get(fromIdx);

        // 🎯 Точный — значения 1:1 как в записи, но ПЛАВНО между кадрами.
        if (legit == 0) {
            float t = Math.max(0f, Math.min(1f, tickDelta));
            float deltaYaw = MathHelper.wrapDegrees(to.yaw - from.yaw);
            float deltaPitch = to.pitch - from.pitch;
            float yaw = from.yaw + deltaYaw * t;
            float pitch = from.pitch + deltaPitch * t;

            // Доп. плавность (настройка «Плавность»): 0 = как раньше, 1 = максимально мягко
            float s = cfg.macroSmoothness;
            if (s > 0f) {
                if (!exactSmoothInit) {
                    exactYaw = yaw;
                    exactPitch = pitch;
                    exactSmoothInit = true;
                }
                float k = 1f - s * 0.7f;
                exactYaw += MathHelper.wrapDegrees(yaw - exactYaw) * k;
                exactPitch += (pitch - exactPitch) * k;
                yaw = exactYaw;
                pitch = exactPitch;
            }

            client.player.setYaw(yaw);
            client.player.setPitch(pitch);
            client.player.headYaw = yaw;
            client.player.bodyYaw = yaw;
            return;
        }

        // 🎮 Легит — плавное «человеческое» наведение на текущий кадр
        if (!smoothInit) {
            smoothYaw = client.player.getYaw();
            smoothPitch = client.player.getPitch();
            smoothInit = true;
        }

        int age = client.player.age;
        if (age != lastTickAge) {
            lastTickAge = age;

            if (legiSharpnessTimer <= 0) {
                float base = HungerGuardConfig.get().macroSharpness;
                legiCurrentSharpness = Math.max(0.2f, Math.min(1.0f, base * (0.8f + random.nextFloat() * 0.4f)));
                legiSharpnessTimer = 15 + random.nextInt(15);
            }
            legiSharpnessTimer--;

            if (legiAimDriftTimer <= 0) {
                legiAimDrift = (random.nextFloat() - 0.5f) * 0.06f;
                legiAimDriftTimer = 20 + random.nextInt(20);
            }
            legiAimDriftTimer--;
        }

        float targetYaw = to.yaw + legiAimDrift;
        float targetPitch = to.pitch + legiAimDrift * 0.5f;

        float deltaYaw = MathHelper.wrapDegrees(targetYaw - smoothYaw);
        float deltaPitch = targetPitch - smoothPitch;

        float sharpness = legiCurrentSharpness;
        float lerp;
        if (sharpness < 0.3f) {
            lerp = 0.015f + (sharpness - 0.2f) / 0.1f * 0.025f;
        } else if (sharpness < 0.6f) {
            lerp = 0.04f + (sharpness - 0.3f) / 0.3f * 0.08f;
        } else if (sharpness < 0.85f) {
            lerp = 0.12f + (sharpness - 0.6f) / 0.25f * 0.18f;
        } else {
            lerp = 0.30f + (sharpness - 0.85f) / 0.15f * 0.50f;
        }

        long now = System.nanoTime();
        float frameSec = (lastRenderNanos == 0L) ? (1f / 60f) : (now - lastRenderNanos) / 1_000_000_000f;
        lastRenderNanos = now;
        if (frameSec <= 0f) frameSec = 1f / 60f;
        float tickScale = Math.min(1.5f, frameSec * 20f);
        lerp = 1f - (float) Math.pow(1f - lerp, tickScale);

        smoothYaw += deltaYaw * lerp;
        smoothPitch += deltaPitch * lerp;

        float finalYaw = smoothYaw;
        float finalPitch = MathHelper.clamp(smoothPitch, -90f, 90f);

        client.player.setYaw(finalYaw);
        client.player.setPitch(finalPitch);
        client.player.headYaw = finalYaw;
        client.player.bodyYaw = finalYaw;
    }

    private void recordTick(MinecraftClient client, GameOptions o) {
        Frame f = new Frame();
        // Клавиши: уровень (зажата) + флаг точного нажатия из GLFW-колбэка,
        // чтобы короткие нажатия короче тика не терялись.
        f.forward = o.forwardKey.isPressed() || fwdPressed;
        f.back = o.backKey.isPressed() || backPressed;
        f.left = o.leftKey.isPressed() || leftPressed;
        f.right = o.rightKey.isPressed() || rightPressed;
        f.jump = o.jumpKey.isPressed() || jumpPressed;
        f.sprint = o.sprintKey.isPressed() || sprintPressed;
        f.sneak = o.sneakKey.isPressed() || sneakPressed;
        f.drop = dropPressed;
        f.swapHands = swapPressed;
        f.inventory = invPressed;

        // Мышь: текущее состояние из GLFW + точные фронты кликов из колбэка
        // (ванильный клиент не обновляет attack/use, пока открыт экран).
        long handle = client.getWindow().getHandle();
        boolean leftDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean rightDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        f.attack = leftDown || leftClickPressed;
        f.use = rightDown || rightClickPressed;
        f.leftClick = leftClickPressed || (leftDown && !prevLeftDown);
        f.rightClick = rightClickPressed || (rightDown && !prevRightDown);
        prevLeftDown = leftDown;
        prevRightDown = rightDown;

        f.selectedSlot = client.player.getInventory().getSelectedSlot();
        f.yaw = client.player.getYaw();
        f.pitch = client.player.getPitch();

        // ==== Экран и позиция курсора ====
        f.screenOpen = client.currentScreen != null;
        // Фронт закрытия экрана (ESC или любое закрытие) — по нему закрываем при воспроизведении
        f.screenClosed = prevScreenOpen && client.currentScreen == null;
        prevScreenOpen = f.screenOpen;
        if (leftClickPressed || rightClickPressed) {
            // Если в этом тике был клик — берём точную позицию курсора на момент нажатия
            f.mouseX = clickX;
            f.mouseY = clickY;
        } else {
            f.mouseX = client.mouse.getScaledX(client.getWindow());
            f.mouseY = client.mouse.getScaledY(client.getWindow());
        }

        // Сбрасываем флаги колбэков — они относятся к текущему тику
        fwdPressed = backPressed = leftPressed = rightPressed = false;
        jumpPressed = sneakPressed = sprintPressed = false;
        dropPressed = swapPressed = invPressed = false;
        leftClickPressed = rightClickPressed = false;

        // Цель атаки (блок + сторона) — чтобы при воспроизведении ломать ТОТ ЖЕ блок
        f.blockPos = null;
        f.blockDirection = null;
        if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            BlockHitResult bhr = (BlockHitResult) client.crosshairTarget;
            f.blockPos = bhr.getBlockPos();
            f.blockDirection = bhr.getSide();
        }

        f.hotbarSnapshot = new String[9];
        for (int i = 0; i < 9; i++) {
            ItemStack st = client.player.getInventory().getStack(i);
            if (st.isEmpty()) {
                f.hotbarSnapshot[i] = "";
            } else {
                Identifier id = Registries.ITEM.getId(st.getItem());
                f.hotbarSnapshot[i] = id.toString() + "|" + st.getCount();
            }
        }

        if (!pendingChat.isEmpty()) {
            f.chatEntries = new ArrayList<>(pendingChat);
            pendingChat.clear();
        }
        frames.add(f);
    }

    private void playbackTick(MinecraftClient client, GameOptions o) {
        HungerGuardConfig cfg = HungerGuardConfig.get();
        int legit = cfg.macroLegitLevel;

        if (playbackIndex >= frames.size()) {
            if (cfg.macroLoop && !frames.isEmpty()) {
                playbackIndex = 0;
                resetEdgeState();
                releaseAllKeys(client);
                smoothInit = false;
                int cooldown = cfg.macroCooldownTicks;
                if (cooldown > 0) { cooldownTicks = cooldown; return; }
            } else {
                stopPlayback(client);
                return;
            }
        }

        if (cooldownTicks > 0) { cooldownTicks--; return; }

        if (legit >= 1 && legiTimingDelay > 0) {
            legiTimingDelay--;
            return;
        }

        float speed = cfg.macroPlaybackSpeed;
        if (speed < 0.5f) speed = 0.5f;
        if (speed > 5.0f) speed = 5.0f;

        speedAccumulator += speed;
        int framesProcessed = 0;

        while (speedAccumulator >= 1.0f && framesProcessed < 4) {
            Frame f = frames.get(playbackIndex);

            if (!applyFrame(o, client, f)) {
                // По записи экран открыт, а у нас ещё нет (сервер ещё не открыл
                // верстак/сундук) — ждём, не продвигаясь, чтобы не потерять клик.
                activeFrameIdx = playbackIndex;
                stallTicks++;
                if (stallTicks > 60) {
                    // 3 секунды без экрана — пропускаем кадр, чтобы не зависнуть
                    stallTicks = 0;
                    playbackIndex++;
                    if (playbackIndex >= frames.size()) {
                        stopPlayback(client);
                        return;
                    }
                }
                break;
            }
            stallTicks = 0;
            speedAccumulator -= 1.0f;
            framesProcessed++;
            activeFrameIdx = playbackIndex;

            if (f.inventory && !inventoryRestoreTriggered) {
                inventoryRestoreTriggered = true;
                if (cfg.macroAutoTakeFromInventory) autoTakeFromInventory(client);
                if (cfg.macroRestoreInventory) restoreInventory(client, f);
            }
            if (!f.inventory) {
                inventoryRestoreTriggered = false;
            }

            playbackIndex++;

            if (playbackIndex >= frames.size()) {
                if (cfg.macroLoop) {
                    playbackIndex = 0;
                    resetEdgeState();
                    releaseAllKeys(client);
                    smoothInit = false;
                } else {
                    stopPlayback(client);
                    return;
                }
            }
        }

        if (legit >= 1 && cfg.macroTimingJitter) {
            int maxJitter = Math.max(1, cfg.macroTimingJitterMax);
            if (random.nextFloat() < 0.35f) {
                legiTimingDelay = 1 + random.nextInt(maxJitter);
            }
        }
    }

    /** Применяет один кадр. Возвращает false, если нужно подождать (экран ещё не открылся). */
    private boolean applyFrame(GameOptions o, MinecraftClient client, Frame f) {
        // === Закрытие экрана (ESC или любое закрытие) — по фронту из записи ===
        if (f.screenClosed && client.currentScreen != null) {
            client.setScreen(null);
        }

        // === Открытие инвентаря (E) — экран клиента, открывается мгновенно ===
        if (f.inventory && !prevInventory && f.screenOpen && client.currentScreen == null) {
            openInventory(client);
        }
        prevInventory = f.inventory;

        // === Если по записи экран открыт, а у нас ещё не открылся (лаг сервера) —
        //     ждём, чтобы не потерять клики по интерфейсу ===
        if (f.screenOpen && client.currentScreen == null) {
            return false;
        }

        // === ДВИЖЕНИЕ (непрерывные клавиши — ввод читается каждый тик) ===
        o.forwardKey.setPressed(f.forward);
        o.backKey.setPressed(f.back);
        o.leftKey.setPressed(f.left);
        o.rightKey.setPressed(f.right);
        o.jumpKey.setPressed(f.jump);
        o.sprintKey.setPressed(f.sprint);
        o.sneakKey.setPressed(f.sneak);
        prevJump = f.jump;
        prevSprint = f.sprint;
        prevSneak = f.sneak;

        // === АТАКА (ЛКМ) — только в мире (в интерфейсе клики обрабатываются ниже) ===
        if (!f.screenOpen) {
            if (f.attack && !prevAttack) {
                attackStart(client, f);
            } else if (f.attack) {
                attackProgress(client, f);
            } else if (prevAttack) {
                attackStop(client);
            }
            prevAttack = f.attack;
        } else {
            if (prevAttack) attackStop(client);
            prevAttack = false;
        }

        // === ПКМ: строим/используем (только в мире). При зажатой кнопке повторяем
        // каждые 4 тика, как ванильный клиент — чтобы ставилась цепочка блоков ===
        if (!f.screenOpen) {
            if (f.use) {
                if (!prevUse) {
                    useRepeatTimer = 0;
                    useStart(client, f);
                } else {
                    useRepeatTimer++;
                    if (useRepeatTimer >= USE_REPEAT_TICKS) {
                        useRepeatTimer = 0;
                        useStart(client, f);
                    }
                }
            }
            prevUse = f.use;
        } else {
            prevUse = false;
        }

        // === Q — выброс предмета ===
        if (f.drop && !prevDrop) {
            try {
                if (client.player != null) client.player.dropSelectedItem(false);
            } catch (Exception ignored) {}
        }
        prevDrop = f.drop;

        // === F — свап рук (настоящий пакет SWAP_ITEM_WITH_OFFHAND) ===
        if (f.swapHands && !prevSwapHands) {
            swapHands(client);
        }
        prevSwapHands = f.swapHands;

        // === E — открыть инвентарь. Закрытие экранов делает общий блок выше. ===
        if (f.inventory && !prevInventory && f.screenOpen) {
            openInventory(client);
        }
        prevInventory = f.inventory;

        // Слот хотбара
        if (client.player != null) {
            client.player.getInventory().setSelectedSlot(f.selectedSlot);
        }

        // Чат
        if (f.chatEntries != null && client.getNetworkHandler() != null) {
            for (ChatEntry entry : f.chatEntries) {
                if (entry.isCommand) {
                    client.getNetworkHandler().sendChatCommand(entry.text);
                } else {
                    client.getNetworkHandler().sendChatMessage(entry.text);
                }
            }
        }

        // ==== Клики мышью в интерфейсах (верстак, сундук и т.п.) ====
        // Воспроизводим клик по той же позиции, куда кликали при записи
        // (нажатие + отпускание — как настоящий клик).
        if (f.screenOpen && client.currentScreen != null) {
            if (f.leftClick) {
                try {
                    client.currentScreen.mouseClicked(f.mouseX, f.mouseY, 0);
                    client.currentScreen.mouseReleased(f.mouseX, f.mouseY, 0);
                } catch (Exception ignored) {}
            }
            if (f.rightClick) {
                try {
                    client.currentScreen.mouseClicked(f.mouseX, f.mouseY, 1);
                    client.currentScreen.mouseReleased(f.mouseX, f.mouseY, 1);
                } catch (Exception ignored) {}
            }
        }
        return true;
    }

    /** Цель ломания: записанный блок (если рядом) или текущий прицел. */
    private BlockHitResult resolveBlockTarget(MinecraftClient client, Frame f) {
        if (f.blockPos != null && f.blockDirection != null && client.player != null) {
            double cx = f.blockPos.getX() + 0.5;
            double cy = f.blockPos.getY() + 0.5;
            double cz = f.blockPos.getZ() + 0.5;
            if (client.player.squaredDistanceTo(cx, cy, cz) <= 25.0) { // 5 блоков
                return new BlockHitResult(new Vec3d(cx, cy, cz), f.blockDirection, f.blockPos, false);
            }
        }
        if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            return (BlockHitResult) client.crosshairTarget;
        }
        return null;
    }

    /**
     * Рейкаст ОТ ЗАПИСАННЫХ УГЛОВ КАМЕРЫ. Это ключевое для точной постройки:
     * блок ставится ровно туда, куда ты целился при записи, даже если «живой»
     * прицел в этот тик ещё не успел довернуться.
     */
    private BlockHitResult raycastFromCamera(MinecraftClient client, float yaw, float pitch) {
        if (client.player == null || client.world == null) return null;
        double reach = client.player.isCreative() ? 5.0 : 4.5;
        Vec3d eye = client.player.getCameraPosVec(1.0f);

        float radYaw = yaw * MathHelper.RADIANS_PER_DEGREE;
        float radPitch = pitch * MathHelper.RADIANS_PER_DEGREE;
        double dx = -MathHelper.sin(radYaw) * MathHelper.cos(radPitch);
        double dy = -MathHelper.sin(radPitch);
        double dz = MathHelper.cos(radYaw) * MathHelper.cos(radPitch);

        Vec3d end = eye.add(dx * reach, dy * reach, dz * reach);
        try {
            return client.world.raycast(new RaycastContext(
                    eye, end, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, client.player));
        } catch (Exception ignored) {
            return null;
        }
    }

    /** Первое нажатие атаки: START_DESTROY_BLOCK + взмах (или удар по сущности). */
    private void attackStart(MinecraftClient client, Frame f) {
        if (client.player == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        try {
            BlockHitResult bhr = resolveBlockTarget(client, f);
            if (bhr != null) {
                client.interactionManager.attackBlock(bhr.getBlockPos(), bhr.getSide());
                return;
            }
            if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                EntityHitResult ehr = (EntityHitResult) client.crosshairTarget;
                client.interactionManager.attackEntity(client.player, ehr.getEntity());
                return;
            }
            client.player.swingHand(Hand.MAIN_HAND);
        } catch (Exception ignored) {}
    }

    /** Каждый тик, пока зажата атака: обновляем прогресс ломания. */
    private void attackProgress(MinecraftClient client, Frame f) {
        if (client.player == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        try {
            BlockHitResult bhr = resolveBlockTarget(client, f);
            if (bhr != null) {
                client.interactionManager.updateBlockBreakingProgress(bhr.getBlockPos(), bhr.getSide());
            }
        } catch (Exception ignored) {}
    }

    /** Отпустили атаку: STOP_DESTROY_BLOCK. */
    private void attackStop(MinecraftClient client) {
        if (client.interactionManager == null) return;
        try {
            client.interactionManager.cancelBlockBreaking();
        } catch (Exception ignored) {}
    }

    /**
     * ПКМ: по блоку — ставим блок/взаимодействуем (цель считаем от записанной
     * камеры), в воздухе — используем предмет (еда, лук и т.п.).
     */
    private void useStart(MinecraftClient client, Frame f) {
        if (client.player == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        try {
            BlockHitResult bhr = raycastFromCamera(client, f.yaw, f.pitch);
            if (bhr != null) {
                client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, bhr);
            } else {
                client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
            }
        } catch (Exception ignored) {}
    }

    /** Свап рук — настоящий пакет, как шлёт ванильный клиент при нажатии F. */
    private void swapHands(MinecraftClient client) {
        if (client.getNetworkHandler() == null) return;
        try {
            client.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                    BlockPos.ORIGIN,
                    Direction.DOWN));
        } catch (Exception ignored) {}
    }

    private void openInventory(MinecraftClient client) {
        if (client.currentScreen == null && client.player != null) {
            client.setScreen(new InventoryScreen(client.player));
        }
    }

    private void closeInventory(MinecraftClient client) {
        if (client.currentScreen != null) {
            client.setScreen(null);
        }
    }

    /** Выдать предмет в слот хотбара через пакет креатива (работает в креативе). */
    private void setCreativeSlot(MinecraftClient client, int hotbarSlot, ItemStack stack) {
        if (client.getNetworkHandler() == null) return;
        try {
            client.getNetworkHandler().sendPacket(new CreativeInventoryActionC2SPacket(hotbarSlot + 36, stack));
        } catch (Exception ignored) {}
    }

    /** Авто-взятие предметов из списка «Предметы для макроса» (порядок = слоты 1..9). */
    private void autoTakeFromInventory(MinecraftClient client) {
        List<Item> items = HungerGuardConfig.getMacroInventoryItems();
        if (items.isEmpty() || client.player == null || client.interactionManager == null) return;

        PlayerInventory inv = client.player.getInventory();
        int syncId = client.player.playerScreenHandler.syncId;

        for (int targetSlot = 0; targetSlot < Math.min(9, items.size()); targetSlot++) {
            Item wanted = items.get(targetSlot);
            ItemStack cur = inv.getStack(targetSlot);
            if (!cur.isEmpty() && cur.getItem() == wanted) continue;

            int found = -1;
            for (int i = 9; i < 36; i++) {
                ItemStack st = inv.getStack(i);
                if (!st.isEmpty() && st.getItem() == wanted) { found = i; break; }
            }
            if (found == -1) {
                if (client.player.isCreative()) {
                    setCreativeSlot(client, targetSlot, new ItemStack(wanted));
                    log("§a[Macro] Взял " + Registries.ITEM.getId(wanted) + " в слот " + (targetSlot + 1) + " (креатив)");
                } else {
                    log("§e[Macro] Не хватает: " + Registries.ITEM.getId(wanted));
                }
                continue;
            }

            try {
                client.interactionManager.clickSlot(syncId, found, 0, SlotActionType.PICKUP, client.player);
                client.interactionManager.clickSlot(syncId, targetSlot + 36, 0, SlotActionType.PICKUP, client.player);
                if (!cur.isEmpty()) {
                    client.interactionManager.clickSlot(syncId, found, 0, SlotActionType.PICKUP, client.player);
                }
                log("§a[Macro] Взял " + Registries.ITEM.getId(wanted) + " в слот " + (targetSlot + 1));
            } catch (Exception ignored) {}
        }
    }

    /**
     * Восстановление хотбара по снимку записи — то, что делает «строительного бота»:
     * в выживании перекладывает блоки из основного инвентаря в хотбар в записанном
     * порядке, в креативе — выдаёт недостающие через пакет креатива.
     */
    private void restoreInventory(MinecraftClient client, Frame f) {
        if (f.hotbarSnapshot == null || client.player == null || client.interactionManager == null) return;

        PlayerInventory inv = client.player.getInventory();
        int syncId = client.player.playerScreenHandler.syncId;
        boolean creative = client.player.isCreative();

        for (int slot = 0; slot < 9; slot++) {
            String target = f.hotbarSnapshot[slot];
            if (target == null || target.isEmpty()) continue;

            String[] parts = target.split("\\|");
            if (parts.length < 2) continue;

            String itemId = parts[0];
            int wantedCount;
            try { wantedCount = Integer.parseInt(parts[1]); }
            catch (Exception e) { continue; }

            ItemStack current = inv.getStack(slot);
            if (!current.isEmpty()) {
                Identifier curId = Registries.ITEM.getId(current.getItem());
                if (curId.toString().equals(itemId) && current.getCount() >= wantedCount) {
                    continue;
                }
            }

            // 1) Ищем в основном инвентаре (9-35)
            int foundSlot = -1;
            for (int i = 9; i < 36; i++) {
                ItemStack st = inv.getStack(i);
                if (!st.isEmpty() && Registries.ITEM.getId(st.getItem()).toString().equals(itemId)) {
                    foundSlot = i;
                    break;
                }
            }

            if (foundSlot == -1) {
                // 2) В креативе — выдаём предмет, как если бы взяли из креатив-меню
                if (creative) {
                    Item wanted = Registries.ITEM.get(Identifier.of(itemId));
                    if (wanted != null) {
                        setCreativeSlot(client, slot, new ItemStack(wanted, wantedCount));
                        log("§a[Macro] Выдал " + itemId + " x" + wantedCount + " в слот " + (slot + 1) + " (креатив)");
                    } else {
                        log("§e[Macro] Неизвестный предмет: " + itemId);
                    }
                } else {
                    log("§e[Macro] Не хватает: " + itemId + " (нужно " + wantedCount + ")");
                }
                continue;
            }

            // 3) Есть в инвентаре — перекладываем через clickSlot
            if (!current.isEmpty()) {
                int emptySlot = -1;
                for (int i = 9; i < 36; i++) {
                    if (inv.getStack(i).isEmpty()) {
                        emptySlot = i;
                        break;
                    }
                }
                if (emptySlot == -1) {
                    log("§c[Macro] Нет свободных слотов!");
                    return;
                }
                try {
                    client.interactionManager.clickSlot(syncId, slot + 36, 0, SlotActionType.PICKUP, client.player);
                    client.interactionManager.clickSlot(syncId, emptySlot, 0, SlotActionType.PICKUP, client.player);
                } catch (Exception ignored) {}
            }

            try {
                client.interactionManager.clickSlot(syncId, foundSlot, 0, SlotActionType.PICKUP, client.player);
                client.interactionManager.clickSlot(syncId, slot + 36, 0, SlotActionType.PICKUP, client.player);
                log("§a[Macro] Положил " + itemId + " в слот " + (slot + 1));
            } catch (Exception ignored) {}
        }
    }

    private void releaseAllKeys(MinecraftClient client) {
        GameOptions o = client.options;
        o.forwardKey.setPressed(false);
        o.backKey.setPressed(false);
        o.leftKey.setPressed(false);
        o.rightKey.setPressed(false);
        o.jumpKey.setPressed(false);
        o.sprintKey.setPressed(false);
        o.sneakKey.setPressed(false);
        o.attackKey.setPressed(false);
        o.useKey.setPressed(false);
        o.dropKey.setPressed(false);
        o.swapHandsKey.setPressed(false);
        o.inventoryKey.setPressed(false);
    }

    private void log(String msg) {
        if (!HungerGuardConfig.get().macroLogToChat) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(Text.literal(msg), false);
        }
    }

    private static class ChatEntry {
        final String text;
        final boolean isCommand;
        ChatEntry(String text, boolean isCommand) {
            this.text = text;
            this.isCommand = isCommand;
        }
    }

    private static class Frame {
        boolean forward, back, left, right, jump, sprint, sneak;
        boolean attack, use, drop, swapHands, inventory;
        boolean screenOpen;            // был ли открыт какой-то экран в этот тик
        boolean screenClosed;          // фронт закрытия экрана (ESC и т.п.)
        boolean leftClick, rightClick; // фронт клика мышью (для интерфейсов)
        double mouseX, mouseY;         // позиция курсора (масштабированная)
        int selectedSlot;
        float yaw, pitch;
        BlockPos blockPos;
        Direction blockDirection;
        List<ChatEntry> chatEntries;
        String[] hotbarSnapshot;
    }
}
