package com.example.hungerguard.gui;

import com.example.hungerguard.FarmerBot;
import com.example.hungerguard.HungerGuardConfig;
import com.example.hungerguard.MacroRecorder;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Компактное меню клиента: одно окно по центру экрана,
 * где ВСЕ модули видны сразу (без вкладок).
 * Размер окна автоматически подстраивается под разрешение:
 * никогда не занимает весь экран и всегда по центру.
 */
public class ClientMenuScreen extends Screen {

    // === Максимальные размеры окна — увеличено чтобы фермер не пропадал ===
    private static final int MAX_W = 470;
    private static final int MAX_H = 300;
    private static final int RADIUS = 12;
    private static final int HEADER_H = 38;
    private static final int LIST_TOP = 44;
    private static final int ROW_GAP = 4;
    private static final int FOOTER_H = 34;

    private int winX, winY, winW, winH;
    private int rowH = 32;

    // Хит-зоны (пересчитываются в layout())
    private final List<int[]> themeRects = new ArrayList<>(); // x,y,w,h,themeIndex
    private final List<RowHit> moduleHits = new ArrayList<>();

    public ClientMenuScreen() { this(0); }

    /** @param initialTab оставлен для совместимости — вкладок больше нет, все модули видны сразу. */
    public ClientMenuScreen(int initialTab) {
        super(Text.literal("HungerGuard"));
    }

    // ==== Модуль ====

    private static final class Module {
        final String name;
        final Supplier<String> info;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        final Runnable open; // null = нет настроек

        Module(String name, Supplier<String> info, BooleanSupplier get, Consumer<Boolean> set, Runnable open) {
            this.name = name;
            this.info = info;
            this.get = get;
            this.set = set;
            this.open = open;
        }
    }

    /** Все модули клиента — отображаются одновременно. */
    private List<Module> modules() {
        HungerGuardConfig c = HungerGuardConfig.get();
        List<Module> list = new ArrayList<>();
        list.add(new Module("Hunger Guard", () -> "Порог голода: " + threshold() + "/20",
                () -> c.hungerEnabled, v -> { c.hungerEnabled = v; HungerGuardConfig.save(); },
                () -> this.client.setScreen(new HungerGuardSettingsScreen(this))));
        list.add(new Module("Macro", this::macroInfo,
                () -> c.macroEnabled, v -> { c.macroEnabled = v; HungerGuardConfig.save(); },
                () -> this.client.setScreen(new MacroSettingsScreen(this))));
        list.add(new Module("Auto Sell", () -> "Задержка: " + c.autoSellDelayMs + " мс · "
                        + c.autoSellItemIds.size() + " предм.",
                () -> c.autoSellEnabled, v -> { c.autoSellEnabled = v; HungerGuardConfig.save(); },
                () -> this.client.setScreen(new AutoSellScreen(this))));
        // ИСПРАВЛЕНО: строитель на долгих техработах — отключаем пока поле шаблона не регает
        list.add(new Module("Строитель §c⛔ ТЕХ.РАБОТЫ", () -> "§cНа техработах — скоро вернётся",
                () -> false, v -> notify("§c[Строитель] На долгих тех.работах — поле шаблона чинится"),
                () -> notify("§c[Строитель] Отключён на тех.работы. Фермер работает.")));
        list.add(new Module("Фермер", () -> "Собрано: " + FarmerBot.INSTANCE.getHarvested()
                        + " · дальность " + c.farmerRange,
                () -> c.farmerEnabled, v -> { c.farmerEnabled = v; HungerGuardConfig.save(); },
                () -> this.client.setScreen(new FarmerScreen(this))));
        return list;
    }

    private String macroInfo() {
        String state = switch (MacroRecorder.INSTANCE.getState()) {
            case RECORDING -> "идёт запись";
            case PLAYING -> "воспроизведение";
            default -> "ожидание";
        };
        return "Тиков: " + MacroRecorder.INSTANCE.getFrameCount() + " · " + state;
    }

    private int threshold() {
        return Math.max(0, Math.min(20, HungerGuardConfig.get().foodThreshold));
    }

    // ==== Инициализация ====

    @Override
    protected void init() {
        // ИСПРАВЛЕНО: адаптивный размер — гарантируем место для 5 модулей (фермер)
        winW = Math.min(MAX_W, this.width - 20);
        winH = Math.min(MAX_H, this.height - 20);
        winW = Math.max(360, winW);
        winH = Math.max(280, winH);
        if (winH < 280) winH = 280;
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        this.clearChildren();

        // Кнопка закрытия - строго внутри окна
        this.addDrawableChild(ButtonWidget.builder(Text.literal("×"), b -> close())
                .dimensions(winX + winW - 22, winY + 6, 16, 16).build());

        // Кнопки макроса в футере - адаптивно по ширине окна
        int by = winY + winH - 26;
        int btnW = Math.max(50, (winW - 24 - 60) / 3);
        int totalW = btnW * 3 + 10;
        int bx;
        if (winW < 400) {
            // На узких экранах - правее лейбла "Макрос:"
            bx = winX + 12 + 55;
            btnW = Math.max(45, (winW - 24 - 65) / 3);
        } else {
            bx = winX + (winW - totalW) / 2;
            bx = Math.max(bx, winX + 70);
        }
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§c● Запись"), b -> onRecord())
                .dimensions(bx, by, btnW, 16).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§7■ Стоп"), b -> onStop())
                .dimensions(bx + btnW + 5, by, btnW, 16).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§a▶ Старт"), b -> onPlay())
                .dimensions(bx + 2 * (btnW + 5), by, btnW, 16).build());

        layout();
    }

    /** Пересчёт хит-зон под текущий размер окна. ИСПРАВЛЕНО: темы переносятся, модули не вылезают */
    private void layout() {
        themeRects.clear();
        moduleHits.clear();

        int footerTop = winY + winH - FOOTER_H;
        int listTop = winY + LIST_TOP;
        int listH = footerTop - listTop;
        if (listH < 140) listH = 140;
        // ИСПРАВЛЕНО: гарантируем что 5 модулей влезают — считаем rowH чтобы точно влезло
        int available = listH - 4 * ROW_GAP - 6;
        rowH = available / 5;
        rowH = Math.max(22, Math.min(32, rowH));

        // Темы - две строки максимум, перенос если не влезают по ширине
        int tx = winX + 14;
        int ty = winY + 22;
        int sq = 12, gap = 4;
        int maxPerRow = Math.max(5, (winW - 28) / (sq + gap));
        for (int i = 0; i < GuiUtil.THEMES.length; i++) {
            int col = i % maxPerRow;
            int row = i / maxPerRow;
            if (row >= 2) break;
            int x = tx + col * (sq + gap);
            int y = ty + row * (sq + gap);
            if (y + sq > winY + HEADER_H - 2) break;
            themeRects.add(new int[]{x, y, sq, sq, i});
        }

        int y = listTop + 3;
        int x = winX + 12;
        int w = winW - 24;
        for (Module m : modules()) {
            if (y + rowH > footerTop) break;
            moduleHits.add(new RowHit(x, y, w, rowH, m));
            y += rowH + ROW_GAP;
        }
        // Защита: если из-за округления не влез последний (фермер), уменьшаем rowH на 1 и пересобираем
        if (moduleHits.size() < modules().size() && rowH > 22) {
            rowH -= 2;
            moduleHits.clear();
            y = listTop + 3;
            for (Module m : modules()) {
                if (y + rowH > footerTop) break;
                moduleHits.add(new RowHit(x, y, w, rowH, m));
                y += rowH + ROW_GAP;
            }
        }
    }

    // ==== Рендер ====

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x80000000);

        GuiUtil.fillRoundRect(context, winX, winY, winW, winH, RADIUS, GuiUtil.COLOR_WINDOW_BG);

        renderHeader(context);
        renderModules(context, mouseX, mouseY);
        renderFooter(context);

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderHeader(DrawContext context) {
        context.fill(winX + 14, winY + HEADER_H, winX + winW - 14, winY + HEADER_H + 1, GuiUtil.COLOR_SEPARATOR);

        context.drawTextWithShadow(this.textRenderer, Text.literal("§7Темы"),
                winX + 14, winY + 8, GuiUtil.COLOR_TEXT_MUTED);

        int sel = HungerGuardConfig.get().themeIndex;
        for (int[] r : themeRects) {
            int idx = r[4];
            int color = GuiUtil.THEMES[idx].accent();
            GuiUtil.fillRoundRect(context, r[0], r[1], r[2], r[3], 4, color);
            if (idx == sel) {
                context.fill(r[0] - 1, r[1] - 1, r[0] + r[2] + 1, r[1] + r[3] + 1, 0xFFFFFFFF);
                GuiUtil.fillRoundRect(context, r[0], r[1], r[2], r[3], 4, color);
            }
        }

        // Название клиента + версия (по метке видно, что запущен свежий jar)
        String title = "HUNGERGUARD v1.7";
        int titleW = this.textRenderer.getWidth(title);
        context.drawTextWithShadow(this.textRenderer, Text.literal("§f§lHUNGER§b§lGUARD §8§lv1.7"),
                winX + winW - 26 - titleW - 16, winY + 20, 0xFFFFFF);
    }

    private void renderModules(DrawContext context, int mouseX, int mouseY) {
        for (RowHit hit : moduleHits) {
            Module m = (Module) hit.obj;
            boolean on = m.get.getAsBoolean();
            boolean hovered = mouseX >= hit.x && mouseX <= hit.x + hit.w
                    && mouseY >= hit.y && mouseY <= hit.y + hit.h;

            if (hovered) {
                GuiUtil.fillRoundRect(context, hit.x, hit.y, hit.w, hit.h, 8, GuiUtil.COLOR_BLOCK_BG);
            }

            // Название + живой статус
            context.drawTextWithShadow(this.textRenderer, Text.literal((on ? "§f" : "§7") + m.name),
                    hit.x + 10, hit.y + 4, on ? 0xFFFFFF : 0xFFB9C0C8);
            context.drawTextWithShadow(this.textRenderer, Text.literal("§8" + m.info.get()),
                    hit.x + 10, hit.y + rowH - 11, GuiUtil.COLOR_TEXT_MUTED);

            // Тумблер справа
            int pillW = 28, pillH = 14;
            int pillX = hit.x + hit.w - pillW - 10;
            int pillY = hit.y + (rowH - pillH) / 2;
            drawPill(context, pillX, pillY, on);

            // Шестерёнка
            if (m.open != null) {
                int gx = pillX - 16;
                drawGear(context, gx, pillY + pillH / 2, 6, hovered ? GuiUtil.accent() : 0xFF6B7683);
            }
        }
    }

    private void renderFooter(DrawContext context) {
        context.fill(winX + 14, winY + winH - 32, winX + winW - 14, winY + winH - 31, GuiUtil.COLOR_SEPARATOR);
        context.drawTextWithShadow(this.textRenderer, Text.literal("§7Макрос:"),
                winX + 14, winY + winH - 23, GuiUtil.COLOR_TEXT_MUTED);
        String esc = "v1.7 · Esc — закрыть";
        context.drawTextWithShadow(this.textRenderer, Text.literal("§8" + esc),
                winX + winW - 14 - this.textRenderer.getWidth(esc), winY + winH - 23, GuiUtil.COLOR_TEXT_MUTED);
    }

    private void drawPill(DrawContext context, int x, int y, boolean on) {
        int w = 28, h = 14;
        GuiUtil.fillPill(context, x, y, w, h, on ? GuiUtil.accent() : GuiUtil.COLOR_TOGGLE_OFF);
        int r = h / 2 - 2;
        int cx = on ? x + w - r - 2 : x + r + 2;
        GuiUtil.fillCircle(context, cx, y + h / 2, r, 0xFFFFFFFF);
    }

    private void drawGear(DrawContext context, int cx, int cy, int r, int color) {
        context.fill(cx - r - 1, cy - 1, cx - r + 1, cy + 1, color);
        context.fill(cx + r - 1, cy - 1, cx + r + 1, cy + 1, color);
        context.fill(cx - 1, cy - r - 1, cx + 1, cy - r + 1, color);
        context.fill(cx - 1, cy + r - 1, cx + 1, cy + r + 1, color);
        GuiUtil.fillCircle(context, cx, cy, r - 2, color);
        GuiUtil.fillCircle(context, cx, cy, Math.max(1, (r - 2) / 2), GuiUtil.COLOR_WINDOW_BG);
    }

    // ==== Клики ====

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        // Темы
        for (int[] r : themeRects) {
            if (mouseX >= r[0] && mouseX <= r[0] + r[2] && mouseY >= r[1] && mouseY <= r[1] + r[3]) {
                GuiUtil.setTheme(r[4]);
                return true;
            }
        }

        // Модули: шестерёнка — настройки, остальное — тумблер
        for (RowHit hit : moduleHits) {
            if (mouseX >= hit.x && mouseX <= hit.x + hit.w && mouseY >= hit.y && mouseY <= hit.y + hit.h) {
                Module m = (Module) hit.obj;
                int pillW = 28;
                int pillX = hit.x + hit.w - pillW - 10;
                if (m.open != null && mouseX >= pillX - 20 && mouseX <= pillX - 4) {
                    m.open.run();
                    return true;
                }
                m.set.accept(!m.get.getAsBoolean());
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() { return false; }

    // ==== Управление макросом ====

    private void notify(String message) {
        if (this.client != null && this.client.player != null) {
            this.client.player.sendMessage(Text.literal(message), false);
        }
    }

    private boolean canUseMacro() {
        if (!HungerGuardConfig.get().macroEnabled) {
            notify("§cФункция Macro выключена");
            return false;
        }
        return true;
    }

    private long lastMacroGuiClick = 0;
    private boolean debounceMacroGui() {
        long now = System.currentTimeMillis();
        if (now - lastMacroGuiClick < 350) return false;
        lastMacroGuiClick = now;
        return true;
    }
    private void onRecord() {
        if (!canUseMacro() || !debounceMacroGui()) return;
        // Защита от двойного вызова: если уже играет - стоп, если уже пишется - игнор
        if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.PLAYING) {
            MacroRecorder.INSTANCE.stopPlayback(this.client);
            // небольшая задержка чтобы не триггерило одновременно
            return;
        }
        if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.RECORDING) return;
        MacroRecorder.INSTANCE.startRecording();
        updateMacroButtons();
    }

    private void onStop() {
        if (!debounceMacroGui()) return;
        MacroRecorder.State state = MacroRecorder.INSTANCE.getState();
        if (state == MacroRecorder.State.RECORDING) {
            MacroRecorder.INSTANCE.stopRecording();
        } else if (state == MacroRecorder.State.PLAYING) {
            MacroRecorder.INSTANCE.stopPlayback(this.client);
        }
        updateMacroButtons();
    }

    private void onPlay() {
        if (!canUseMacro() || !debounceMacroGui()) return;
        if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.RECORDING) {
            MacroRecorder.INSTANCE.stopRecording();
            return;
        }
        if (MacroRecorder.INSTANCE.getFrameCount() == 0) {
            notify("§cНечего воспроизводить");
            return;
        }
        if (MacroRecorder.INSTANCE.getState() == MacroRecorder.State.PLAYING) return;
        MacroRecorder.INSTANCE.startPlayback();
        updateMacroButtons();
    }
    private void updateMacroButtons() {
        // форсируем тик чтобы кнопки сразу перерисовались и не было лага "одновременно старт+запись"
        this.tick();
    }

    private static final class RowHit {
        final int x, y, w, h;
        final Object obj;

        RowHit(int x, int y, int w, int h, Object obj) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.obj = obj;
        }
    }
}
