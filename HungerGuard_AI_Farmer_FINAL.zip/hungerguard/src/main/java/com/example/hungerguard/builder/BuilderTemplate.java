package com.example.hungerguard.builder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * Шаблон постройки: воксельная модель с относительными координатами от угла (0,0,0).
 * Хранится в JSON (.minecraft/config/hungerguard_templates/).
 */
public class BuilderTemplate {

    public String name = "";
    public int dx = 16, dy = 16, dz = 16;
    public List<Block> blocks = new ArrayList<>();

    /** Один блок шаблона: относительные координаты + id блока ("minecraft:stone"). */
    public static class Block {
        public int x, y, z;
        public String id;

        public Block() {}

        public Block(int x, int y, int z, String id) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.id = id;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static BuilderTemplate createEmpty(String name, int dx, int dy, int dz) {
        BuilderTemplate t = new BuilderTemplate();
        t.name = name;
        t.dx = dx;
        t.dy = dy;
        t.dz = dz;
        return t;
    }

    /** Возвращает id блока в координате или null, если пусто. */
    public String getBlockId(int x, int y, int z) {
        for (Block b : blocks) {
            if (b.x == x && b.y == y && b.z == z) return b.id;
        }
        return null;
    }

    /** Ставит блок (id) или убирает (id == null/пусто). Координаты вне размеров игнорируются. */
    public void setBlock(int x, int y, int z, String id) {
        if (x < 0 || y < 0 || z < 0 || x >= dx || y >= dy || z >= dz) return;
        blocks.removeIf(b -> b.x == x && b.y == y && b.z == z);
        if (id != null && !id.isEmpty()) {
            blocks.add(new Block(x, y, z, id));
        }
    }

    public int blockCount() {
        return blocks.size();
    }

    public String toJson() {
        return GSON.toJson(this);
    }

    public static BuilderTemplate fromJson(String json) {
        BuilderTemplate t = GSON.fromJson(json, BuilderTemplate.class);
        if (t == null) t = new BuilderTemplate();
        if (t.blocks == null) t.blocks = new ArrayList<>();
        return t;
    }
}
