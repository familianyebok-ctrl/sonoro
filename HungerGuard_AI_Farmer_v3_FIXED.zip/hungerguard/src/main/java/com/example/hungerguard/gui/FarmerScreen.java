package com.example.hungerguard.gui;

import com.example.hungerguard.FarmerBot;
import com.example.hungerguard.HungerGuardConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * Настройки авто-фермы: дальность сканирования, радиус сундука,
 * интервал шифта, скорость, резкость камеры, пересадка, склад.
 * Окно адаптивное — подстраивается под размер экрана, чтобы всё было видно.
 */
public class FarmerScreen extends Screen {

    private static final int MAX_W = 400;
    private static final int MAX_H = 384;

    private final Screen parent;
    private int winX, winY, winW, winH;

    public FarmerScreen(Screen parent) {
        super(Text.literal("Авто-ферма"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        winW = Math.min(MAX_W, this.width - 12);
        winH = Math.min(MAX_H, this.height - 12);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;
        this.clearChildren();

        int x = winX + 16;
        int w = winW - 32;
        int y = winY + 34;

        this.addDrawableChild(new RangeSlider(x, y, w, 18)); y += 22;
        this.addDrawableChild(new ChestRadiusSlider(x, y, w, 18)); y += 22;
        this.addDrawableChild(new ShiftSlider(x, y, w, 18)); y += 22;
        this.addDrawableChild(new SpeedSlider(x, y, w, 18)); y += 22;
        this.addDrawableChild(new SharpnessSlider(x, y, w, 18)); y += 26;

        this.addDrawableChild(new ToggleSwitch(x, y, w, "Авто-посев (пересадка)",
                () -> HungerGuardConfig.get().farmerReplant,
                v -> { HungerGuardConfig.get().farmerReplant = v; HungerGuardConfig.save(); }));
        y += 22;

        this.addDrawableChild(new ToggleSwitch(x, y, w, "Складывать в сундук",
                () -> HungerGuardConfig.get().farmerDeposit,
                v -> { HungerGuardConfig.get().farmerDeposit = v; HungerGuardConfig.save(); }));
        y += 22;

        this.addDrawableChild(new ToggleSwitch(x, y, w, "Авто-смена инструмента",
                () -> HungerGuardConfig.get().farmerToolSwitch,
                v -> { HungerGuardConfig.get().farmerToolSwitch = v; HungerGuardConfig.save(); }));
        y += 22;

        this.addDrawableChild(new ToggleSwitch(x, y, w, "Точный сбор (не промахиваться)",
                () -> HungerGuardConfig.get().farmerStrict,
                v -> { HungerGuardConfig.get().farmerStrict = v; HungerGuardConfig.save(); }));
        y += 24;

        int n = HungerGuardConfig.get().farmerDepositItemIds == null ? 0
                : HungerGuardConfig.get().farmerDepositItemIds.size();
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§7📦 Предметы в сундук (" + n + ")"), b -> {
                    if (this.client != null) this.client.setScreen(new FarmerDepositScreen(this));
                }).dimensions(x, y, w, 18).build());
        y += 24;

        int btnW = (w - 8) / 3;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§a▶ Старт"), b -> FarmerBot.INSTANCE.start())
                .dimensions(x, y, btnW, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§c■ Стоп"), b -> FarmerBot.INSTANCE.stop())
                .dimensions(x + btnW + 4, y, btnW, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), b -> close())
                .dimensions(x + 2 * (btnW + 4), y, btnW, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        GuiUtil.fillRoundRect(context, winX, winY, winW, winH, 12, GuiUtil.COLOR_WINDOW_BG);

        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§a§l🌾 Авто-ферма"),
                winX + winW / 2, winY + 10, 0xFFFFFF);

        String status = FarmerBot.INSTANCE.isRunning()
                ? "§a● Работает (собрано: " + FarmerBot.INSTANCE.getHarvested() + ")"
                : "§7○ Остановлен";
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(status),
                winX + winW / 2, winY + winH - 42, 0xFFFFFF);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§8Шифт каждые N сек — триггер «головы фермера»"),
                winX + winW / 2, winY + winH - 24, GuiUtil.COLOR_TEXT_MUTED);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static class RangeSlider extends SliderWidget {
        RangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (HungerGuardConfig.get().farmerRange - 3) / 12.0);
            updateMessage();
        }
        @Override protected void updateMessage() {
            int v = 3 + (int) Math.round(this.value * 12);
            setMessage(Text.literal("Дальность сканирования: " + v + " блоков"));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().farmerRange = 3 + (int) Math.round(this.value * 12);
            HungerGuardConfig.save();
        }
    }

    private static class ChestRadiusSlider extends SliderWidget {
        ChestRadiusSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (HungerGuardConfig.get().farmerChestRadius - 2) / 14.0);
            updateMessage();
        }
        @Override protected void updateMessage() {
            int v = 2 + (int) Math.round(this.value * 14);
            setMessage(Text.literal("Радиус поиска сундука: " + v + " блоков"));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().farmerChestRadius = 2 + (int) Math.round(this.value * 14);
            HungerGuardConfig.save();
        }
    }

    private static class ShiftSlider extends SliderWidget {
        ShiftSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (HungerGuardConfig.get().farmerShiftIntervalTicks / 20.0 - 2) / 58.0);
            updateMessage();
        }
        @Override protected void updateMessage() {
            int sec = 2 + (int) Math.round(this.value * 58);
            setMessage(Text.literal("Интервал шифта: " + sec + " сек"));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().farmerShiftIntervalTicks = (2 + (int) Math.round(this.value * 58)) * 20;
            HungerGuardConfig.save();
        }
    }

    private static class SpeedSlider extends SliderWidget {
        SpeedSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (HungerGuardConfig.get().farmerMoveSpeed - 0.2f) / 2.8f);
            updateMessage();
        }
        @Override protected void updateMessage() {
            float s = 0.2f + (float) (this.value * 2.8f);
            setMessage(Text.literal(String.format("Скорость бота: %.1fx", s)));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().farmerMoveSpeed = 0.2f + (float) (this.value * 2.8f);
            HungerGuardConfig.save();
        }
    }

    private static class SharpnessSlider extends SliderWidget {
        SharpnessSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), HungerGuardConfig.get().farmerSharpness);
            updateMessage();
        }
        @Override protected void updateMessage() {
            setMessage(Text.literal(String.format("Резкость камеры: %.2f", this.value)));
        }
        @Override protected void applyValue() {
            HungerGuardConfig.get().farmerSharpness = (float) this.value;
            HungerGuardConfig.save();
        }
    }
}
