package com.example.hungerguard;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Авто-ферма v2 — полностью переписан на новый формат.
 * <p>
 * Принципы нового формата:
 * - Чёткий конечный автомат: одно действие за тик, без одновременного ломания+посадки.
 * - Фаза сбора и фаза посадки разделены паузой (дроп должен упасть).
 * - Один вызов камеры за тик, с гистерезисом чтобы не дёргаться.
 * - Движение и прицел не конфликтуют: пока идём — смотрим мягко, пока бьём — держим цель.
 * - Честное ломание через attackBlock / updateBlockBreakingProgress.
 */
public class FarmerBot {

    public static final FarmerBot INSTANCE = new FarmerBot();

    private static final Set<Block> CROPS = Set.of(
            Blocks.WHEAT, Blocks.CARROTS, Blocks.POTATOES, Blocks.BEETROOTS, Blocks.NETHER_WART);

    // ===== Состояние автомата =====
    private enum Phase {
        IDLE,
        SEARCH,
        MOVE_TO_CROP,
        HARVEST,
        WAIT_DROP,
        MOVE_TO_SOIL,
        PLANT,
        VERIFY_PLANT,
        DEPOSIT
    }

    private boolean running = false;
    private Phase phase = Phase.IDLE;
    private int harvested = 0;
    private int ticks = 0;

    // Цель сбора
    private BlockPos targetCrop = null;
    private Item pendingSeed = null;

    // Ломание
    private BlockPos breakingPos = null;
    private int breakingTicks = 0;

    // Посадка
    private BlockPos targetSoil = null;
    private Item plantSeed = null;
    private int plantCooldown = 0; // тики до попытки посадки
    private int plantRetries = 0;
    private int verifyWait = 0; // тики до проверки что посадка реально применилась

    // Депозит
    private int depositStep = 0;
    private int depositWait = 0;
    private BlockPos depositChest = null;
    private long depositCooldown = 0;
    private long lastNoChestWarn = 0;

    // Шифт
    private int shiftReleaseIn = -1;

    // Камера
    private float smoothYaw = 0f, smoothPitch = 0f;
    private boolean lookInit = false;

    // Анти-застревание
    private Vec3d stuckRef = null;
    private int stuckTicks = 0;
    private final Map<BlockPos, Integer> skipUntil = new HashMap<>();

    // Инструмент
    private Item lastHeld = Items.AIR;

    // Пауза между действиями чтобы не спамить
    private int actionDelay = 0;

    private FarmerBot() {}

    public boolean isRunning() { return running; }
    public int getHarvested() { return harvested; }

    public void start() {
        running = true;
        phase = Phase.SEARCH;
        harvested = 0;
        ticks = 0;
        targetCrop = null;
        targetSoil = null;
        pendingSeed = null;
        breakingPos = null;
        breakingTicks = 0;
        plantSeed = null;
        plantCooldown = 0;
        plantRetries = 0;
        verifyWait = 0;
        depositStep = 0;
        depositChest = null;
        depositWait = 0;
        lookInit = false;
        stuckRef = null;
        stuckTicks = 0;
        skipUntil.clear();
        actionDelay = 0;
        shiftReleaseIn = -1;
        lastHeld = Items.AIR;
        notify("§a[Фермер] Запущен (v2)");
    }

    public void stop() {
        if (!running) return;
        running = false;
        phase = Phase.IDLE;
        releaseKeys();
        notify("§c[Фермер] Остановлен (собрано: " + harvested + ")");
    }

    public void tick(MinecraftClient client) {
        if (!running) return;
        if (client.player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null && depositStep == 0) return;

        ticks++;
        HungerGuardConfig cfg = HungerGuardConfig.get();

        // --- шифт ---
        if (cfg.farmerShiftIntervalTicks > 0 && ticks % cfg.farmerShiftIntervalTicks == 0) {
            client.options.sneakKey.setPressed(true);
            shiftReleaseIn = 3;
        }
        if (shiftReleaseIn >= 0) {
            shiftReleaseIn--;
            if (shiftReleaseIn <= 0) {
                client.options.sneakKey.setPressed(false);
                shiftReleaseIn = -1;
            }
        }

        // --- депозит имеет приоритет ---
        if (cfg.farmerDeposit && depositStep != 0) {
            tickDeposit(client);
            return;
        }
        if (cfg.farmerDeposit && isInventoryFull(client) && ticks > depositCooldown) {
            depositStep = 1;
            depositChest = null;
            tickDeposit(client);
            return;
        }

        // --- автосмена инструмента ---
        autoToolSwitch(client);

        // --- задержка между действиями ---
        if (actionDelay > 0) {
            actionDelay--;
            // во время задержки держим прицел на текущей цели чтобы не дёргаться
            if (phase == Phase.HARVEST && breakingPos != null) {
                lookAtSmooth(client, aimPoint(breakingPos), 0.35f);
                client.interactionManager.updateBlockBreakingProgress(breakingPos, Direction.UP);
            }
            return;
        }

        switch (phase) {
            case SEARCH -> doSearch(client);
            case MOVE_TO_CROP -> doMoveToCrop(client);
            case HARVEST -> doHarvest(client);
            case WAIT_DROP -> doWaitDrop(client);
            case MOVE_TO_SOIL -> doMoveToSoil(client);
            case PLANT -> doPlant(client);
            case VERIFY_PLANT -> doVerifyPlant(client);
            case DEPOSIT -> tickDeposit(client);
            default -> phase = Phase.SEARCH;
        }
    }

    // ===== ФАЗЫ =====

    private void doSearch(MinecraftClient client) {
        // троттлинг поиска
        if (ticks % 4 != 0) return;
        BlockPos crop = findMatureCrop(client);
        if (crop == null) {
            releaseKeys();
            return;
        }
        targetCrop = crop;
        pendingSeed = seedFor(client.world.getBlockState(crop).getBlock());
        phase = Phase.MOVE_TO_CROP;
    }

    private void doMoveToCrop(MinecraftClient client) {
        if (targetCrop == null || !stillValid(client, targetCrop)) {
            phase = Phase.SEARCH;
            targetCrop = null;
            return;
        }
        // ИСПРАВЛЕНО: заставляем реально ХОДИТЬ — урожай собираем только вблизи (2.6 блока), а не с 4.5
        // игрок просил «интеллект чтобы он мог ходить, а то на месте стоит и дергается»
        double dist = distTo(client, targetCrop);
        if (dist > 2.6) {
            // идём к культуре, быстро поворачиваем (0.55) чтобы не делать дугу
            Vec3d aim = Vec3d.ofCenter(targetCrop).add(0, -0.1, 0);
            // сначала довернуть, потом идти — убирает дёргание на месте
            float yawTo = (float)Math.toDegrees(Math.atan2(-(aim.x - client.player.getEyePos().x), aim.z - client.player.getEyePos().z));
            float diff = Math.abs(MathHelper.wrapDegrees(yawTo - client.player.getYaw()));
            if (diff > 35) {
                lookAtSmooth(client, aim, 0.55f);
                // пока разворачивается — не идём, чтобы не кружить
                return;
            }
            moveTowardSmart(client, targetCrop);
            lookAtSmooth(client, aim, 0.38f);
            checkStuck(client, targetCrop);
            return;
        }
        // подошли — фиксируем взгляд
        if (HungerGuardConfig.get().farmerStrict) {
            // строгий режим: не начинаем ломать, пока рейкаст не подтвердит именно этот блок
            // (защита от того, что прицел зацепит соседнюю грядку/блок)
            BlockHitResult hit = raycastTo(client, targetCrop);
            if (hit == null || !hit.getBlockPos().equals(targetCrop)) {
                lookAtSmooth(client, aimPoint(targetCrop), 0.9f);
                return;
            }
        }
        releaseKeys();
        lookAtSmooth(client, aimPoint(targetCrop), 0.9f);
        actionDelay = 2;
        phase = Phase.HARVEST;
        breakingPos = targetCrop;
        breakingTicks = 0;
        client.interactionManager.attackBlock(breakingPos, Direction.UP);
    }

    private void doHarvest(MinecraftClient client) {
        if (breakingPos == null) {
            phase = Phase.SEARCH;
            return;
        }
        // проверяем что блок всё ещё есть
        if (client.world.getBlockState(breakingPos).isAir()) {
            // сломали
            BlockPos done = breakingPos;
            Item seed = pendingSeed;
            breakingPos = null;
            harvested++;
            targetCrop = null;
            pendingSeed = null;
            // переход к ожиданию дропа, потом к посадке
            if (HungerGuardConfig.get().farmerReplant && seed != null) {
                // грядка под сломанным блоком — обычные культуры растут прямо на ней
                targetSoil = done.down();
                plantSeed = seed;
                plantCooldown = 8; // дать дропу упасть и подобраться
                plantRetries = 0;
                phase = Phase.WAIT_DROP;
            } else {
                actionDelay = 4;
                phase = Phase.SEARCH;
            }
            return;
        }
        if (breakingTicks > 110) {
            // не ломается — пропускаем
            skipUntil.put(breakingPos, ticks + 200);
            breakingPos = null;
            targetCrop = null;
            phase = Phase.SEARCH;
            return;
        }
        // продолжаем ломать, держим прицел мягко
        lookAtSmooth(client, aimPoint(breakingPos), 0.45f);
        client.interactionManager.updateBlockBreakingProgress(breakingPos, Direction.UP);
        breakingTicks++;
    }

    private void doWaitDrop(MinecraftClient client) {
        if (plantCooldown > 0) {
            plantCooldown--;
            // слегка смотрим на грядку, без движения
            if (targetSoil != null) lookAtSmooth(client, Vec3d.ofCenter(targetSoil).add(0, 0.1, 0), 0.25f);
            return;
        }
        phase = Phase.MOVE_TO_SOIL;
    }

    private void doMoveToSoil(MinecraftClient client) {
        if (targetSoil == null) {
            phase = Phase.SEARCH;
            return;
        }
        if (!isPlantableGround(client, targetSoil)) {
            targetSoil = null;
            plantSeed = null;
            phase = Phase.SEARCH;
            actionDelay = 3;
            return;
        }
        double dist = distTo(client, targetSoil);
        if (dist > 2.2) {
            Vec3d aim = Vec3d.ofCenter(targetSoil).add(0, 0.2, 0);
            float yawTo = (float)Math.toDegrees(Math.atan2(-(aim.x - client.player.getEyePos().x), aim.z - client.player.getEyePos().z));
            float diff = Math.abs(MathHelper.wrapDegrees(yawTo - client.player.getYaw()));
            if (diff > 30) { lookAtSmooth(client, aim, 0.5f); return; }
            moveTowardSmart(client, targetSoil);
            lookAtSmooth(client, aim, 0.35f);
            checkStuck(client, targetSoil, () -> {
                phase = Phase.SEARCH;
                targetSoil = null;
                plantSeed = null;
            });
            return;
        }
        releaseKeys();
        lookAtSmooth(client, Vec3d.ofCenter(targetSoil).add(0, 0.15, 0), 0.6f);
        actionDelay = 2;
        phase = Phase.PLANT;
    }

    private void doPlant(MinecraftClient client) {
        if (targetSoil == null || plantSeed == null) {
            phase = Phase.SEARCH;
            return;
        }
        // ищем семена в инвентаре
        int slot = findItemSlot(client, plantSeed);
        if (slot == -1) {
            if (plantRetries < 10) {
                plantRetries++;
                plantCooldown = 6;
                phase = Phase.WAIT_DROP;
                return;
            }
            // семян нет — пропускаем
            targetSoil = null;
            plantSeed = null;
            phase = Phase.SEARCH;
            actionDelay = 3;
            return;
        }
        selectSlot(client, slot);
        // рейкаст на грядку сверху
        BlockHitResult hit = raycastTo(client, targetSoil);
        if (hit == null || !hit.getBlockPos().equals(targetSoil)) {
            // не навелись — ещё чуть довернем
            lookAtSmooth(client, Vec3d.ofCenter(targetSoil).add(0, 0.2, 0), 0.7f);
            if (plantRetries < 6) {
                plantRetries++;
                actionDelay = 3;
                return;
            }
            targetSoil = null;
            plantSeed = null;
            phase = Phase.SEARCH;
            return;
        }
        // сажаем один раз, без спама
        client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
        // не считаем посадку успешной вслепую — идём проверять реальный блок на грядке
        verifyWait = 4; // дать серверу/клиенту время применить блок
        phase = Phase.VERIFY_PLANT;
    }

    /** Проверяем, что на targetSoil реально появилась культура, а не просто кликнули в пустоту. */
    private void doVerifyPlant(MinecraftClient client) {
        if (targetSoil == null) {
            phase = Phase.SEARCH;
            return;
        }
        if (verifyWait > 0) {
            verifyWait--;
            lookAtSmooth(client, Vec3d.ofCenter(targetSoil).add(0, 0.15, 0), 0.3f);
            return;
        }
        Block above = client.world.getBlockState(targetSoil.up()).getBlock();
        boolean planted = CROPS.contains(above);
        if (planted) {
            targetSoil = null;
            plantSeed = null;
            plantRetries = 0;
            actionDelay = 5; // пауза чтобы не дёргаться к следующему блоку
            phase = Phase.SEARCH;
            return;
        }
        // не посадилось (промахнулись, семена не выбрались, сервер отклонил) — пробуем ещё раз
        if (plantRetries < 5) {
            plantRetries++;
            actionDelay = 3;
            phase = Phase.PLANT;
            return;
        }
        // сдаёмся по этой грядке, чтобы не зациклиться навсегда
        skipUntil.put(targetSoil, ticks + 200);
        targetSoil = null;
        plantSeed = null;
        plantRetries = 0;
        actionDelay = 5;
        phase = Phase.SEARCH;
    }

    // ===== ДЕПОЗИТ =====
    private void tickDeposit(MinecraftClient client) {
        if (depositStep == 1) {
            if (depositChest == null) {
                depositChest = findNearestChest(client);
                if (depositChest == null) {
                    if (ticks - lastNoChestWarn > 200) {
                        lastNoChestWarn = ticks;
                        notify("§e[Фермер] Сундук не найден в радиусе " + HungerGuardConfig.get().farmerChestRadius);
                    }
                    depositStep = 0;
                    depositCooldown = ticks + 200;
                    return;
                }
            }
            if (distTo(client, depositChest) > 3.8) {
                moveToward(client, depositChest, false);
                lookAtSmooth(client, Vec3d.ofCenter(depositChest), 0.30f);
                BlockPos chestRef = depositChest;
                checkStuck(client, chestRef, () -> {
                    // не смогли дойти до этого сундука — забываем его и попробуем другой позже
                    depositStep = 0;
                    depositChest = null;
                    depositCooldown = ticks + 200;
                });
                return;
            }
            releaseKeys();
            lookAtSmooth(client, Vec3d.ofCenter(depositChest), 0.6f);
            BlockHitResult hit = raycastTo(client, depositChest);
            if (hit == null) {
                depositStep = 0;
                depositChest = null;
                return;
            }
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
            depositStep = 2;
            depositWait = 10;
            return;
        }
        if (depositStep == 2) {
            if (depositWait > 0) {
                depositWait--;
                return;
            }
            ScreenHandler sh = client.player.currentScreenHandler;
            if (sh == null || sh == client.player.playerScreenHandler) {
                depositStep = 0;
                depositChest = null;
                depositCooldown = ticks + 80;
                return;
            }
            int playerStart = sh.slots.size() - 36;
            for (int i = playerStart; i < sh.slots.size(); i++) {
                ItemStack st = sh.getSlot(i).getStack();
                if (!st.isEmpty() && shouldDeposit(st.getItem())) {
                    client.interactionManager.clickSlot(sh.syncId, i, 0, SlotActionType.QUICK_MOVE, client.player);
                }
            }
            client.setScreen(null);
            depositStep = 0;
            depositChest = null;
            depositCooldown = ticks + 120;
        }
    }

    // ===== ПОИСК ЦЕЛЕЙ =====
    private BlockPos findMatureCrop(MinecraftClient client) {
        int r = HungerGuardConfig.get().farmerRange;
        BlockPos center = client.player.getBlockPos();
        List<BlockPos> found = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -2; dy <= 2; dy++) {
                    BlockPos pos = center.add(dx, dy, dz);
                    Integer until = skipUntil.get(pos);
                    if (until != null && until > ticks) continue;
                    BlockState st = client.world.getBlockState(pos);
                    if (isHarvestable(client, pos, st)) found.add(pos);
                }
            }
        }
        found.sort(Comparator.comparingDouble(p -> client.player.squaredDistanceTo(p.getX()+0.5, p.getY()+0.5, p.getZ()+0.5)));
        if (found.isEmpty()) return null;
        BlockPos top = found.get(0);
        Block b = client.world.getBlockState(top).getBlock();
        if (b == Blocks.SUGAR_CANE || b == Blocks.CACTUS) {
            BlockPos base = top;
            while (client.world.getBlockState(base.down()).isOf(b)) base = base.down();
            return base;
        }
        return top;
    }

    private boolean stillValid(MinecraftClient client, BlockPos pos) {
        BlockState st = client.world.getBlockState(pos);
        if (st.isAir()) return false;
        Block b = st.getBlock();
        if (b == Blocks.SUGAR_CANE || b == Blocks.CACTUS) return true;
        return isHarvestable(client, pos, st);
    }

    private boolean isHarvestable(MinecraftClient client, BlockPos pos, BlockState st) {
        Block b = st.getBlock();
        if (b == Blocks.SUGAR_CANE) {
            return client.world.getBlockState(pos.down()).isOf(Blocks.SUGAR_CANE) && client.world.getBlockState(pos.up()).isAir();
        }
        if (b == Blocks.CACTUS) {
            return client.world.getBlockState(pos.down()).isOf(Blocks.CACTUS) && client.world.getBlockState(pos.up()).isAir();
        }
        if (b == Blocks.PUMPKIN || b == Blocks.MELON) return true;
        if (CROPS.contains(b)) return isMaxAge(st);
        return false;
    }

    private static boolean isMaxAge(BlockState st) {
        for (Property<?> p : st.getProperties()) {
            if (p.getName().equals("age") && p instanceof IntProperty ip) {
                int max = -1;
                for (Integer v : ip.getValues()) if (v > max) max = v;
                return st.get(ip) == max;
            }
        }
        return false;
    }

    private Item seedFor(Block b) {
        if (b == Blocks.WHEAT) return Items.WHEAT_SEEDS;
        if (b == Blocks.CARROTS) return Items.CARROT;
        if (b == Blocks.POTATOES) return Items.POTATO;
        if (b == Blocks.BEETROOTS) return Items.BEETROOT_SEEDS;
        if (b == Blocks.NETHER_WART) return Items.NETHER_WART;
        return null;
    }

    private boolean isPlantableGround(MinecraftClient client, BlockPos pos) {
        Block b = client.world.getBlockState(pos).getBlock();
        return b == Blocks.FARMLAND || b == Blocks.SOUL_SAND;
    }

    private BlockPos findNearestChest(MinecraftClient client) {
        int r = HungerGuardConfig.get().farmerChestRadius;
        BlockPos center = client.player.getBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx=-r; dx<=r; dx++) for(int dz=-r; dz<=r; dz++) for(int dy=-3; dy<=3; dy++){
            BlockPos p = center.add(dx,dy,dz);
            Block b = client.world.getBlockState(p).getBlock();
            if (b==Blocks.CHEST || b==Blocks.TRAPPED_CHEST || b==Blocks.BARREL){
                double d = client.player.squaredDistanceTo(p.getX()+0.5,p.getY()+0.5,p.getZ()+0.5);
                if(d<bestD){bestD=d; best=p;}
            }
        }
        return best;
    }

    // ===== ИНВЕНТАРЬ / ИНСТРУМЕНТ =====
    private void autoToolSwitch(MinecraftClient client){
        if(!HungerGuardConfig.get().farmerToolSwitch) return;
        PlayerInventory inv = client.player.getInventory();
        int sel = inv.getSelectedSlot();
        ItemStack held = inv.getStack(sel);
        if(!held.isEmpty() && held.isDamageable() && held.getDamage() >= held.getMaxDamage()-2){
            int fresh = findHotbarSlot(client, held.getItem(), sel);
            if(fresh!=-1){ inv.setSelectedSlot(fresh); lastHeld = inv.getStack(fresh).getItem(); notify("§e[Фермер] Инструмент почти сломан — беру следующий"); return; }
        }
        if(held.isEmpty() && lastHeld!=Items.AIR){
            int nxt = findHotbarSlot(client, lastHeld, sel);
            if(nxt!=-1){ inv.setSelectedSlot(nxt); notify("§e[Фермер] Инструмент сломался — беру следующий");}
            lastHeld = Items.AIR; return;
        }
        if(!held.isEmpty()) lastHeld = held.getItem();
    }
    private int findHotbarSlot(MinecraftClient client, Item item, int skip){
        PlayerInventory inv = client.player.getInventory();
        for(int i=0;i<9;i++){ if(i==skip) continue; ItemStack st=inv.getStack(i); if(!st.isEmpty()&&st.getItem()==item) return i; }
        return -1;
    }
    private boolean isInventoryFull(MinecraftClient client){
        PlayerInventory inv=client.player.getInventory();
        for(int i=0;i<36;i++) if(inv.getStack(i).isEmpty()) return false;
        return true;
    }
    private int findItemSlot(MinecraftClient client, Item item){
        PlayerInventory inv=client.player.getInventory();
        for(int i=0;i<36;i++){ ItemStack st=inv.getStack(i); if(!st.isEmpty()&&st.getItem()==item) return i; }
        return -1;
    }
    private void selectSlot(MinecraftClient client, int slot){
        PlayerInventory inv=client.player.getInventory();
        if(slot<9){ inv.setSelectedSlot(slot); return; }
        try{
            int syncId=client.player.playerScreenHandler.syncId;
            client.interactionManager.clickSlot(syncId, slot, 0, SlotActionType.PICKUP, client.player);
            client.interactionManager.clickSlot(syncId, 36, 0, SlotActionType.PICKUP, client.player);
            inv.setSelectedSlot(0);
        }catch(Exception ignored){}
    }
    private boolean shouldDeposit(Item item){
        var ids=HungerGuardConfig.get().farmerDepositItemIds;
        if(ids==null||ids.isEmpty()) return false;
        return ids.contains(Registries.ITEM.getId(item).toString());
    }

    // ===== КАМЕРА / ДВИЖЕНИЕ =====
    private BlockHitResult raycastTo(MinecraftClient client, BlockPos pos){
        return raycastToPoint(client, Vec3d.ofCenter(pos));
    }
    private BlockHitResult raycastToPoint(MinecraftClient client, Vec3d target){
        Vec3d eye=client.player.getEyePos();
        try{ return client.world.raycast(new RaycastContext(eye,target, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, client.player)); }catch(Exception e){return null;}
    }
    private Vec3d aimPoint(BlockPos pos){
        Vec3d c=Vec3d.ofCenter(pos);
        return new Vec3d(c.x, c.y-0.05, c.z);
    }
    private double distTo(MinecraftClient client, BlockPos pos){
        return client.player.getEyePos().distanceTo(Vec3d.ofCenter(pos));
    }
    private void moveToward(MinecraftClient client, BlockPos pos, boolean planting){
        moveTowardSmart(client, pos);
    }
    /** Умная ходьба: идёт, поворачивает, жмёт спринт, прыгает если застрял, не дёргается на месте. */
    private void moveTowardSmart(MinecraftClient client, BlockPos pos){
        HungerGuardConfig cfg=HungerGuardConfig.get();
        float speed=cfg.farmerMoveSpeed;
        Vec3d target=Vec3d.ofCenter(pos);
        if(client.player.isCreative()){
            Vec3d eye=client.player.getEyePos();
            double eyeOff=eye.y-client.player.getY();
            Vec3d to=target.subtract(eye);
            double len=to.length();
            if(len<0.05) return;
            Vec3d dir=to.normalize();
            double step=Math.min(0.42*speed, Math.max(0.10, len-1.6));
            Vec3d ne=eye.add(dir.multiply(step));
            client.player.setPosition(ne.x, ne.y-eyeOff, ne.z);
            client.player.setVelocity(Vec3d.ZERO);
            return;
        }
        // Выживание — умная ходьба
        // Спринт если далеко и дорога прямая
        double dist = client.player.getPos().distanceTo(target);
        boolean sprint = dist > 3.5 && !client.player.horizontalCollision;
        client.options.sprintKey.setPressed(sprint);
        client.options.forwardKey.setPressed(true);
        // Стрейф если цель сбоку (помогает обойти грядки)
        Vec3d eye = client.player.getEyePos();
        double dx = target.x - eye.x, dz = target.z - eye.z;
        float yawTo = (float)Math.toDegrees(Math.atan2(-dx, dz));
        float diff = MathHelper.wrapDegrees(yawTo - client.player.getYaw());
        if (Math.abs(diff) > 18) {
            if (diff > 0) client.options.rightKey.setPressed(true);
            else client.options.leftKey.setPressed(true);
        } else {
            client.options.leftKey.setPressed(false);
            client.options.rightKey.setPressed(false);
        }
        boolean shouldJump = client.player.horizontalCollision && client.player.isOnGround();
        // прыжок через грядки/ступеньки
        if (shouldJump || (client.player.isOnGround() && dist > 2 && client.player.horizontalCollision)) {
            client.options.jumpKey.setPressed(true);
        } else if (!client.player.horizontalCollision) {
            // не держим прыжок постоянно
            if (ticks % 6 == 0) client.options.jumpKey.setPressed(false);
        }
    }
    private void checkStuck(MinecraftClient client, BlockPos pos){
        checkStuck(client, pos, () -> { phase = Phase.SEARCH; targetCrop = null; });
    }
    /** Обобщённая проверка застревания: onStuck сам решает, что сбросить (цель урожая/грядки/сундука). */
    private void checkStuck(MinecraftClient client, BlockPos pos, Runnable onStuck){
        if(ticks%20!=0) return;
        Vec3d p=client.player.getPos();
        if(stuckRef!=null && p.squaredDistanceTo(stuckRef)<0.04){
            stuckTicks+=20;
        } else { stuckRef=p; stuckTicks=0; }
        if(stuckTicks>=80){
            if (pos != null) skipUntil.put(pos, ticks+200);
            stuckTicks=0; stuckRef=null;
            releaseKeys();
            onStuck.run();
        }
    }
    private void lookAtSmooth(MinecraftClient client, Vec3d point, float factor){
        Vec3d eye=client.player.getEyePos();
        double dx=point.x-eye.x, dy=point.y-eye.y, dz=point.z-eye.z;
        double horiz=Math.sqrt(dx*dx+dz*dz);
        float yaw=(float)Math.toDegrees(Math.atan2(-dx, dz));
        float pitch=(float)-Math.toDegrees(Math.atan2(dy, horiz));
        setLookSmooth(client,yaw,pitch,applySharpness(factor));
    }
    /** Применяет настройку "резкость камеры" (farmerSharpness, 0..1) ко всем поворотам взгляда.
     *  0.6 — базовое значение, на котором были откалиброваны факторы поворотов выше по файлу. */
    private float applySharpness(float baseFactor){
        float s = HungerGuardConfig.get().farmerSharpness;
        float mult = MathHelper.clamp(s / 0.6f, 0.3f, 1.8f);
        return MathHelper.clamp(baseFactor * mult, 0.03f, 1f);
    }
    private void setLookSmooth(MinecraftClient client, float ty, float tp, float f){
        if(!lookInit){ smoothYaw=client.player.getYaw(); smoothPitch=client.player.getPitch(); lookInit=true; }
        float dy=Math.abs(MathHelper.wrapDegrees(ty-smoothYaw));
        float dp=Math.abs(tp-smoothPitch);
        if(dy<0.7f && dp<0.7f) return;
        f=MathHelper.clamp(f,0.05f,1f);
        if(dy<4f) f*=0.55f;
        if(f>=0.95f){ smoothYaw=ty; smoothPitch=tp; }
        else { smoothYaw+=MathHelper.wrapDegrees(ty-smoothYaw)*f; smoothPitch+=(tp-smoothPitch)*f; }
        client.player.setYaw(smoothYaw); client.player.setPitch(smoothPitch);
        client.player.headYaw=smoothYaw; client.player.bodyYaw=smoothYaw;
    }
    private void releaseKeys(){
        var o=MinecraftClient.getInstance().options;
        o.forwardKey.setPressed(false); o.backKey.setPressed(false);
        o.leftKey.setPressed(false); o.rightKey.setPressed(false);
        o.jumpKey.setPressed(false); o.sprintKey.setPressed(false);
    }
    private void notify(String msg){
        var c=MinecraftClient.getInstance();
        if(c.player!=null) c.player.sendMessage(Text.literal(msg), false);
    }
}
