# HungerGuard Farmer v3 — build status

- Minecraft: 1.21.8
- Fabric Loader: 0.19.5
- Fabric API: 0.136.1+1.21.8
- Java: 21
- Farmer planting verification fixed: checks `planting.up()` (the planted crop block), not the farmland block.
- Source-only archive; stale prebuilt JARs removed.
- Static Java brace/signature checks completed.
- Full Gradle compilation was not run in this environment because the project has no Gradle wrapper and Gradle/dependency downloads are unavailable here.
- No anti-cheat bypass or packet-spoofing logic is included.
